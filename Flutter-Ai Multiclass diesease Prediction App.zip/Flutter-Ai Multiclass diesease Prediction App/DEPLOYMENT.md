# Eye Disease Prediction Deployment Guide

This setup includes:
- Python FastAPI backend for model inference
- User authentication (register/login)
- Prediction history persistence per user
- Flutter app with gallery and camera image capture

## 1. Run backend locally

From project root:

```powershell
python -m pip install -r requirements_api.txt
uvicorn api_server:app --host 0.0.0.0 --port 8000
```

Quick checks:
- Health: `http://127.0.0.1:8000/health`
- API docs: `http://127.0.0.1:8000/docs`

Main endpoints:
- `POST /auth/register`
- `POST /auth/login`
- `GET /me`
- `POST /predict` (Bearer token required)
- `GET /history` (Bearer token required)

## 2. Run Flutter app

```powershell
cd flutter_eye_disease_app
flutter pub get
flutter run
```

Set API URL in app:
- Android emulator: `http://10.0.2.2:8000`
- iOS simulator: `http://127.0.0.1:8000`
- Physical device: `http://<your-lan-ip>:8000`

## 3. Build release APK

```powershell
cd flutter_eye_disease_app
flutter build apk --release
```

APK output:
- `flutter_eye_disease_app/build/app/outputs/flutter-apk/app-release.apk`

## 4. Deploy backend with HTTPS

### Render

Files already included:
- `Dockerfile`
- `render.yaml`
- `.dockerignore`

Steps:
1. Push this repository to GitHub.
2. In Render, create a new Blueprint service from the repo.
3. Confirm env vars (`TOKEN_SECRET`, `DB_PATH`) and deploy.
4. Use the generated HTTPS URL in Flutter app API URL field.

Note:
- `render.yaml` mounts a persistent disk at `/var/data` for SQLite history data.

### Railway

Files already included:
- `Dockerfile`
- `railway.json`

Steps:
1. Create a new Railway project from your GitHub repo.
2. Set env vars:
	- `TOKEN_SECRET` (strong random value)
	- `DB_PATH=/data/retina_app.db`
3. Add a persistent volume mounted to `/data`.
4. Deploy and use Railway HTTPS domain in app.

### Azure App Service (container)

1. Build and push Docker image to Azure Container Registry.
2. Create App Service (Linux, container).
3. Set startup container from ACR image.
4. Configure app settings:
	- `TOKEN_SECRET`
	- `DB_PATH=/home/data/retina_app.db`
5. Add mounted storage path for persistence.

## Important medical note

Predictions and suggestions are informational only and do not replace diagnosis by a qualified ophthalmologist.
