# WALL-E Conversational AI Chatbot Guide

## Overview
The WALL-E chatbot is a fully integrated conversational AI assistant in your Flutter mobile app that provides medical information about eye diseases with an interactive 3D avatar.

## Features Implemented

### 1. **Text-Based AI Conversation**
- Type messages in the input field to chat with WALL-E
- Real-time responses powered by Grok API with medical knowledge base fallback
- Long-press messages to copy or read aloud

### 2. **Speech-to-Text (Listening)**
- Click the microphone button to start listening
- Speak your question naturally (supports English)
- Speech is automatically converted to text and sent to WALL-E
- Auto-stops after 5 seconds of recording

### 3. **Text-to-Speech (Speaking)**
- WALL-E automatically reads responses aloud
- Adjustable speech rate (0.5x normal speed for clarity)
- Full English language support with natural pronunciation

### 4. **Interactive 3D Avatar**
- Dynamic animations based on conversation state:
  - **Idle**: Gentle bobbing and swaying
  - **Listening**: Focused posture with faster movements
  - **Thinking**: Contemplative stance
  - **Speaking**: Animated with mouth movements
- Eye blinking synchronized to conversation state
- Glowing effects that change color per state
- VRM model support for custom avatars
- Fallback animated avatar if no VRM source is configured

### 5. **Medical Knowledge Integration**
- Specializes in eye disease education:
  - CNV (Choroidal Neovascularization)
  - DME (Diabetic Macular Edema)
  - DRUSEN (Age-related Macular Degeneration)
  - General eye health and care
- Grok AI integration for intelligent, context-aware responses
- Fallback knowledge base ensures responses even without internet

### 6. **Enhanced UI Features**
- **Message Timestamps**: See exactly when each message was sent
- **Clear Conversation**: Delete all messages with confirmation dialog
- **Status Indicator**: Real-time display of chatbot state (Listening, Thinking, Speaking, Idle)
- **Message Actions**: Long-press to copy or read aloud
- **Error Handling**: Graceful error messages with retry options
- **Responsive Design**: Works on tablets and phones in portrait and landscape

## How to Use

### Text Chat
1. Navigate to the "Ask VisDect" tab in the app
2. Type your question about eye diseases in the input field
3. Press the send button (paper plane icon) or press Enter
4. WALL-E will respond with information and read it aloud

### Voice Chat
1. Click the microphone button
2. Speak your question clearly
3. Your speech will be recognized and converted to text
4. WALL-E will respond with the answer (both text and audio)

### Clear Conversation
1. Click the delete icon in the header
2. Confirm you want to clear all messages
3. Chat will restart with the welcome message

### Copy or Replay Messages
1. Long-press any message bubble
2. Select "Copy" to copy to clipboard
3. Select "Read Aloud" (AI messages only) to hear the message again

## Backend Integration

### API Endpoint
- **POST** `/api/chat`
- **Requires**: Bearer token authentication
- **Request Body**:
  ```json
  {
    "message": "Your question about eye diseases"
  }
  ```
- **Response**:
  ```json
  {
    "user_message": "Your question",
    "ai_response": "WALL-E's answer",
    "timestamp": "2024-01-01T12:00:00Z",
    "source": "grok" or "fallback"
  }
  ```

### Environment Setup
1. Set `GROK_API_KEY` environment variable with your Grok API key
2. Backend will automatically fall back to knowledge base if API fails
3. Ensure FastAPI server is running on configured port

## Configuration

### API Server (Python)
```python
# api_server.py settings
GROK_API_KEY = os.getenv("GROK_API_KEY", "").strip()
GROK_API_URL = "https://api.x.ai/v1/chat/completions"
```

### Flutter App (Dart)
```dart
// SharedPreferences stores:
- 'api_base_url': Backend API URL
- 'auth_token': User authentication token
- 'walle_vrm_source': Path to VRM model file
```

### Dependencies
- `speech_to_text`: ^7.1.0 - Speech recognition
- `flutter_tts`: ^4.2.5 - Text-to-speech
- `webview_flutter`: ^4.9.0 - 3D model rendering
- `http`: ^1.5.0 - API communication
- `google_fonts`: ^6.3.2 - Typography

## Troubleshooting

### Speech Recognition Not Working
- Check microphone permissions in Android settings
- Ensure "Google Recorder" or similar service is installed
- Try restarting the app

### Text-to-Speech Not Working
- Check volume is not muted
- Verify English language pack is installed
- Check app audio permissions

### Chat Not Connecting
- Verify API server is running
- Check internet connection
- Verify API base URL in Settings
- Check GROK_API_KEY is set in environment

### Avatar Not Showing
- Ensure 3D model file path is correctly configured in Settings
- Check file exists at specified location
- Fallback avatar will display if VRM is not available

## Performance Tips

1. **First Response**: May take 2-5 seconds (API initialization)
2. **Subsequent Responses**: Usually 1-2 seconds
3. **Clear History**: App runs faster with fewer messages in history
4. **Network**: Use stable WiFi for best experience

## Privacy & Security

- All conversations are sent securely via HTTPS/Bearer tokens
- No conversation history is stored permanently
- Clear conversation feature removes all local messages
- User tokens are stored securely in SharedPreferences

## Future Enhancements

- [ ] Conversation history persistence
- [ ] Export chat as PDF
- [ ] Custom avatar training
- [ ] Multi-language support
- [ ] Conversation search
- [ ] Voice customization options

## Support & Contact

For issues or suggestions regarding the WALL-E chatbot:
1. Check the troubleshooting section above
2. Verify all dependencies are properly installed
3. Check API server logs for errors
4. Contact support with error messages and device info

---

**Last Updated**: May 2, 2026
**Version**: 1.0.0 (Full Implementation)
