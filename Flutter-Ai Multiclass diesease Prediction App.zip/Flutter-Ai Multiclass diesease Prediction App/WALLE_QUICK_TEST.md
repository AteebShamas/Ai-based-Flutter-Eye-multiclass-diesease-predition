# WALL-E Chatbot - Quick Test Reference

## Installation
```bash
adb install app-release.apk
```

## Quick Test Checklist

| Test | Steps | Expected Result |
|------|-------|-----------------|
| **Basic Chat** | Type: "What is CNV?" → Send | Message displays, AI responds |
| **Speech Input** | Click mic → Speak "Tell me about DME" | Text auto-populates, message sends |
| **TTS Playback** | Send message → Listen | Audio plays through speaker |
| **Animation** | Observe character during chat | Bobbing/rotation changes with state |
| **Error Handling** | Disable WiFi → Send message | Falls back to knowledge base |

## Status Indicators

| Status | Color | When | Icon |
|--------|-------|------|------|
| Idle | 🟦 Teal | Ready to chat | Android |
| Listening | 🟦 Blue | Microphone active | Mic icon |
| Thinking | 🟦 Purple | Processing API | Loading spinner |
| Speaking | 🟦 Orange | Playing audio | Speaker icon |

## Button Controls

| Button | Location | Effect |
|--------|----------|--------|
| 🎤 Microphone | Bottom left | Start/stop speech recognition (5 sec timeout) |
| ➤ Send | Bottom right | Send message to AI |
| 📻 Speaker icon | Right panel | Visual indicator of TTS playback |

## Keyboard Shortcuts
- Enter: Send message
- Long press mic: Extend recording time
- Tap character: N/A (placeholder, will be 3D model)

## Performance Notes
- First TTS init: ~2 seconds
- Speech recognition: ~1 second
- API response: ~2-3 seconds (Grok)
- Animation latency: <100ms

## Common Issues & Quick Fixes

```
No sound?
→ Check device volume is not muted
→ Check device sound settings
→ Restart app

Mic not working?
→ Grant microphone permission
→ Restart app
→ Use physical device (not emulator)

API failing?
→ Check internet connection
→ Verify backend is running
→ Check API key in code
→ App will fallback to knowledge base

Animations lagging?
→ Close background apps
→ Reduce device brightness
→ Restart phone
```

## Important URLs

**Backend:** `http://192.168.1.6:5000`  
**API Chat:** `POST /api/chat`  
**Grok API:** `https://api.x.ai/v1/chat/completions`

## Sample Messages to Try

1. "What is normal retina health?"
2. "Tell me about CNV treatment options"
3. "How often should I get eye exams?"
4. "What diet helps eye health?"
5. "Explain diabetic macular edema"

## Success Indicators

✅ Messages display in bubbles  
✅ AI responds within 5 seconds  
✅ Audio plays for responses  
✅ Character animates with states  
✅ Speech input populates text field  
✅ Status badge updates  
✅ No crashes during testing  

## File Locations

**APK:** `flutter_eye_disease_app/build/app/outputs/flutter-apk/app-release.apk`  
**Docs:** `WALLE_BUILD_COMPLETE.md`, `WALL-E_INTEGRATION_GUIDE.md`  
**Source:** `flutter_eye_disease_app/lib/advanced_walle_chatbot.dart`  
**Backend:** `api_server.py`

---

**Ready to test!** 🚀
