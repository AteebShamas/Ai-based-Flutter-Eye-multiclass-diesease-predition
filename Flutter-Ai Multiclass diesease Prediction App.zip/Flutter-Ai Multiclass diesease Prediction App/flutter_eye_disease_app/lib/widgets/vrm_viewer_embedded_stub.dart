import 'package:flutter/widgets.dart';

class EmbeddedVrmView extends StatelessWidget {
  final String url;
  const EmbeddedVrmView({super.key, required this.url});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
