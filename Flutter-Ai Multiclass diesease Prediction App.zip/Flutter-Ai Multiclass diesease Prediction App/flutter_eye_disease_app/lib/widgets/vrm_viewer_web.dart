// Web implementation using `dart:html` to open a URL in a new tab.
import 'dart:html' as html;

void openVrmPreview(String url) {
  try {
    html.window.open(url, '_blank');
  } catch (e) {
    // noop
    print('Failed to open url: $e');
  }
}
