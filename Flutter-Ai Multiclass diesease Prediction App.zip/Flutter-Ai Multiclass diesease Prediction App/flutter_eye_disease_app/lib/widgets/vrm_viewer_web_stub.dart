// Stub implementation for non-web platforms. Keeps API stable.
void openVrmPreview(String url) {
  // No-op on non-web platforms.
}
