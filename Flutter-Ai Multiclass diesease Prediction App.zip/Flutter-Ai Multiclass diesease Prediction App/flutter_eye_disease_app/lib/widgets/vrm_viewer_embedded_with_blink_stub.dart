import 'package:flutter/widgets.dart';

class EmbeddedVrmViewWithBlink extends StatelessWidget {
  final String url;

  const EmbeddedVrmViewWithBlink({super.key, required this.url});

  static void sendBlinkCommand(
    BuildContext context, {
    required double intensity,
    required String pattern,
    int duration = 150,
  }) {}

  static void sendConversationStateCommand(
    BuildContext context, {
    required bool active,
    double intensity = 0.35,
    String pattern = 'conversing',
  }) {}

  static void sendVrmCommand(
    BuildContext context, {
    required Map<String, dynamic> command,
  }) {}

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
