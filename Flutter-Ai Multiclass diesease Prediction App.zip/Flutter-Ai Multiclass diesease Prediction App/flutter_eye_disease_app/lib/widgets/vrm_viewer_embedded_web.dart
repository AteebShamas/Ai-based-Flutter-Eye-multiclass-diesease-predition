// Web-only embedded VRM preview using an iframe built with HtmlElementView.fromTagName.
import 'dart:html' as html;
import 'package:flutter/widgets.dart';

class EmbeddedVrmView extends StatelessWidget {
  final String url;
  const EmbeddedVrmView({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return HtmlElementView.fromTagName(
      tagName: 'iframe',
      onElementCreated: (Object element) {
        final iframe = element as html.IFrameElement;
        iframe
          ..src = url
          ..style.border = '0'
          ..style.width = '100%'
          ..style.height = '100%'
          ..allow = 'camera; microphone; autoplay; clipboard-read; clipboard-write';
      },
    );
  }
}
