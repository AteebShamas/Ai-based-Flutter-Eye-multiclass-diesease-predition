import 'dart:async';
import 'dart:convert' show utf8, jsonEncode;
import 'dart:io'
    show
        ContentType,
        HttpHeaders,
        HttpRequest,
        HttpServer,
        HttpStatus,
        InternetAddress;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_windows/webview_windows.dart' as win_webview;
import 'vrm_viewer_embedded_stub.dart'
    if (dart.library.html) 'vrm_viewer_embedded_web.dart';

// Note: For web, we provide instructions to open the standalone viewer.

class VRMViewerWidget extends StatefulWidget {
  static const String wallEBridgeGroup = 'wall_e';
  static const String eyeBridgeGroup = 'eye';

  static final Map<String, WebViewController> _mobileControllers = {};
  static final Map<String, win_webview.WebviewController> _windowsControllers =
      {};

  static const String _defaultModelPath =
      '/3d%20model/sci-fi_humanoid_robot.glb';

  final String
  assetPath; // relative path inside assets, e.g. 'assets/web/vrm_viewer.html'
  final String bridgeGroup;

  const VRMViewerWidget({
    super.key,
    this.assetPath = 'assets/web/vrm_viewer_clean.html',
    this.bridgeGroup = wallEBridgeGroup,
  });

  static Future<bool> _executeWindowsJs(
    String js, {
    String bridgeGroup = wallEBridgeGroup,
  }) async {
    final controller = _windowsControllers[bridgeGroup];
    if (controller == null) {
      return false;
    }

    for (var attempt = 0; attempt < 4; attempt++) {
      try {
        await controller.executeScript(js);
        return true;
      } catch (_) {
        await Future.delayed(Duration(milliseconds: 120 * (attempt + 1)));
      }
    }
    return false;
  }

  static Future<bool> _executeMobileJs(
    String js, {
    String bridgeGroup = wallEBridgeGroup,
  }) async {
    final controller = _mobileControllers[bridgeGroup];
    if (controller == null) {
      return false;
    }

    for (var attempt = 0; attempt < 4; attempt++) {
      try {
        await controller.runJavaScript(js);
        return true;
      } catch (_) {
        await Future.delayed(Duration(milliseconds: 120 * (attempt + 1)));
      }
    }
    return false;
  }

  static Future<void> _dispatchBridgeJs(String js) async {
    if (await _executeMobileJs(js)) {
      return;
    }
    await _executeWindowsJs(js);
  }

  static Future<void> sendBlinkCommand({
    required double intensity,
    required String pattern,
    int duration = 150,
  }) async {
    final clamped = intensity.clamp(0.0, 1.0);
    final safePattern = pattern.replaceAll("'", "");
    final safeDuration = duration.clamp(50, 1000);

    final js =
        "(function(){try{if(window.triggerBlinkFromFlutter){window.triggerBlinkFromFlutter($clamped,'$safePattern',$safeDuration);}else{window.postMessage({action:'blink',intensity:$clamped,pattern:'$safePattern',duration:$safeDuration}, '*');}}catch(e){console.warn('blink bridge failed',e);}})();";
    try {
      await _dispatchBridgeJs(js);
    } catch (_) {
      // Ignore bridge errors to avoid affecting chat flow.
    }
  }

  static Future<void> sendConversationStateCommand({
    required bool active,
    double intensity = 0.35,
    String pattern = 'conversing',
  }) async {
    final clamped = intensity.clamp(0.0, 1.0);
    final safePattern = pattern.replaceAll("'", "");
    final js =
        "(function(){try{if(window.triggerConversationFromFlutter){window.triggerConversationFromFlutter(${active ? 'true' : 'false'},$clamped,'$safePattern');}else{window.postMessage({action:'conversation',active:${active ? 'true' : 'false'},intensity:$clamped,pattern:'$safePattern'}, '*');}}catch(e){console.warn('conversation bridge failed',e);}})();";
    try {
      print(
        '[VRM Bridge] conversation active:$active intensity:$clamped pattern:$safePattern',
      );
      await _dispatchBridgeJs(js);
    } catch (_) {
      // Ignore bridge errors to avoid affecting chat flow.
    }
  }

  static Future<void> sendVrmCommand({
    required Map<String, dynamic> command,
  }) async {
    final safeJson = jsonEncode(command);
    final js =
        "(function(){try{if(window.triggerVrmCommand){window.triggerVrmCommand(" +
        safeJson +
        ");}else{window.postMessage({action:'vrm_command',command:" +
        safeJson +
        "}, '*');}}catch(e){console.warn('vrm_command bridge failed',e);}})();";

    try {
      print('[VRM Bridge] sending vrm_command: $safeJson');
      await _dispatchBridgeJs(js);
    } catch (_) {
      // Ignore bridge errors
    }
  }

  /// Notify the viewer that an LLM generation has started or stopped.
  /// Call with `active=true` when generation begins, and `false` when it ends.
  static Future<void> sendLLMGenerationCommand({required bool active}) async {
    final js =
        "(function(){try{if(window.triggerLLMFromFlutter){window.triggerLLMFromFlutter(${active ? 'true' : 'false'});}else{window.postMessage({action:'llm_generation',active:${active ? 'true' : 'false'}}, '*');}}catch(e){console.warn('llm bridge failed',e);}})();";

    try {
      await _dispatchBridgeJs(js);
    } catch (_) {
      // ignore
    }
  }

  /// Maps a Flutter asset path (e.g. `wall evoices/1.mpeg`) to a proxy URL.
  static String voiceAssetToProxyUrl(String assetPath) {
    final trimmed = assetPath.trim();
    if (trimmed.isEmpty) {
      return '/Voice%20tts.aac';
    }
    if (trimmed.startsWith('/')) {
      return trimmed;
    }
    final encoded = trimmed
        .split('/')
        .map((segment) => Uri.encodeComponent(segment))
        .join('/');
    return '/$encoded';
  }

  static Future<void> sendConversationVoiceCommand({
    required bool active,
    String? voiceAsset,
  }) async {
    final voiceArg = voiceAsset == null || voiceAsset.trim().isEmpty
        ? ''
        : ", '${voiceAssetToProxyUrl(voiceAsset).replaceAll("'", r"\'")}'";
    final js =
        "(function(){try{if(window.triggerConversationVoiceFromFlutter){window.triggerConversationVoiceFromFlutter(${active ? 'true' : 'false'}$voiceArg);}else{window.postMessage({action:'conversation_voice',active:${active ? 'true' : 'false'},voice_url:'${voiceAsset == null ? '' : voiceAssetToProxyUrl(voiceAsset).replaceAll("'", r"\'")}'}, '*');}}catch(e){console.warn('voice bridge failed',e);}})();";

    try {
      await _dispatchBridgeJs(js);
    } catch (_) {
      // ignore
    }
  }

  static Future<void> prepareConversationVoice({String? voiceAsset}) async {
    const defaultAsset = 'Voice tts.aac';
    final asset = (voiceAsset ?? '').trim().isEmpty ? defaultAsset : voiceAsset!.trim();
    final proxyUrl = voiceAssetToProxyUrl(asset).replaceAll("'", r"\'");
    final js =
        "(function(){try{if(window.prepareConversationVoiceFromFlutter){window.prepareConversationVoiceFromFlutter('$proxyUrl');}else{window.postMessage({action:'prepare_conversation_voice',voice_url:'$proxyUrl'}, '*');}}catch(e){console.warn('voice prepare bridge failed',e);}})();";

    try {
      await _dispatchBridgeJs(js);
    } catch (_) {
      // ignore
    }
  }

  @override
  State<VRMViewerWidget> createState() => _VRMViewerWidgetState();
}

class _VRMViewerWidgetState extends State<VRMViewerWidget> {
  HttpServer? _proxy;
  WebViewController? _controller;
  win_webview.WebviewController? _windowsController;
  Timer? _statusPoller;
  String? _proxyUrl;

  bool get _isWindowsDesktop =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.windows;

  bool get _isSupportedMobilePlatform =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      if (_isWindowsDesktop) {
        unawaited(_initWindowsController());
      } else if (_isSupportedMobilePlatform) {
        unawaited(_initMobileController());
      }
    }
  }

  Future<void> _initMobileController() async {
    try {
      _proxy = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      _proxyUrl = 'http://${_proxy!.address.address}:${_proxy!.port}/';
      // Debug: announce proxy URL for easier troubleshooting on device logs
      print('[VRM Proxy] listening at $_proxyUrl');

      _proxy!.listen((request) async {
        // Log incoming requests for visibility in adb logcat
        try {
          print(
            '[VRM Proxy] incoming request: ${request.method} ${request.uri}',
          );
        } catch (_) {}
        await _handleRequest(request);
      });

      final controller =
          WebViewController.fromPlatformCreationParams(
              AndroidWebViewControllerCreationParams(),
            )
            ..setJavaScriptMode(JavaScriptMode.unrestricted)
            ..setBackgroundColor(const Color(0x00000000));

      final platformController = controller.platform;
      if (platformController is AndroidWebViewController) {
        await platformController.setMediaPlaybackRequiresUserGesture(false);
      }

      VRMViewerWidget._mobileControllers[widget.bridgeGroup] = controller;

      if (!mounted) {
        return;
      }

      setState(() {
        _controller = controller;
      });

      final cb = DateTime.now().millisecondsSinceEpoch;
      final urlWithCb = '$_proxyUrl?_cb=$cb';
      await controller.loadRequest(Uri.parse(urlWithCb));
      // Diagnostic: test whether the mobile WebView bridge is reachable.
      // This forces a short visible motion so Android logs/ADB can confirm bridge wiring.
      // Wait for viewer ready flag before running the mobile diagnostic test
      try {
        var ready = false;
        for (var attempt = 0; attempt < 12 && !ready; attempt++) {
          try {
            final r = await controller.runJavaScriptReturningResult(
              "(function(){return window.__viewer_ready? 'yes':'no';})()",
            );
            final s = r.toString();
            if (s.contains('yes')) {
              ready = true;
              break;
            }
          } catch (_) {}
          await Future.delayed(const Duration(milliseconds: 250));
        }
        if (ready) {
          final testRes = await controller.runJavaScriptReturningResult(
            "(function(){try{if(window.triggerConversationFromFlutter){window.triggerConversationFromFlutter(true,0.8,'mobile_diag'); setTimeout(()=>window.triggerConversationFromFlutter(false,0.8,'mobile_diag'),1200);} if(window.triggerBlinkFromFlutter){window.triggerBlinkFromFlutter(0.95,'mobile_diag_blink',160);} return 'bridge-invoked';}catch(e){return 'err:'+e.toString();}})();",
          );
          print(
            '[VRM Proxy] mobile bridge test result: ${testRes.toString()} (viewer ready)',
          );
        } else {
          print('[VRM Proxy] mobile bridge test skipped: viewer not ready');
        }
      } catch (e) {
        print('[VRM Proxy] mobile bridge test failed: $e');
      }
    } catch (e, st) {
      print('[VRM Proxy] init error: $e');
      print(st);
      rethrow;
    }

    // Start polling the page `#status` element so we can surface page status in logcat.
    _statusPoller = Timer.periodic(const Duration(seconds: 2), (_) async {
      try {
        final res = await _controller!.runJavaScriptReturningResult(
          "(function(){const el=document.getElementById('status');return el?el.textContent||el.innerText:'<no-status-element>'})()",
        );
        // runJavaScriptReturningResult may return a JS-serialized value; coerce to string
        final text = res.toString();
        print('[VRM Viewer status] $text');
      } catch (e) {
        // Don't spam logs if JS bridge isn't available yet.
      }
    });
  }

  Future<void> _initWindowsController() async {
    try {
      _proxy = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      _proxyUrl = 'http://${_proxy!.address.address}:${_proxy!.port}/';
      print('[VRM Proxy] listening at $_proxyUrl');

      _proxy!.listen((request) async {
        try {
          print(
            '[VRM Proxy] incoming request: ${request.method} ${request.uri}',
          );
        } catch (_) {}
        await _handleRequest(request);
      });

      final controller = win_webview.WebviewController();
      await controller.initialize();
      // Add cache-busting query so Windows WebView always loads the latest asset bundle
      final cb = DateTime.now().millisecondsSinceEpoch;
      final urlWithCb = '${_proxyUrl!}?_cb=$cb';
      await controller.loadUrl(urlWithCb);
      VRMViewerWidget._windowsControllers[widget.bridgeGroup] = controller;
      try {
        var ready = false;
        for (var attempt = 0; attempt < 12 && !ready; attempt++) {
          try {
            final r = await controller.executeScript(
              "(function(){return window.__viewer_ready? 'yes':'no';})()",
            );
            final s = r?.toString() ?? 'no';
            if (s.contains('yes')) {
              ready = true;
              break;
            }
          } catch (_) {}
          await Future.delayed(const Duration(milliseconds: 250));
        }
        if (ready) {
          final testRes = await controller.executeScript(
            "(function(){try{if(window.triggerConversationFromFlutter){window.triggerConversationFromFlutter(true,0.6,'diagnostic_test'); setTimeout(()=>window.triggerConversationFromFlutter(false,0.6,'diagnostic_test'),2000);} if(window.triggerBlinkFromFlutter){window.triggerBlinkFromFlutter(0.95,'diag_blink',160);} return 'bridge-invoked';}catch(e){return 'err:'+e.toString();}})();",
          );
          print(
            '[VRM Proxy] windows bridge test result: $testRes (viewer ready)',
          );
        } else {
          print('[VRM Proxy] windows bridge test skipped: viewer not ready');
        }
      } catch (e) {
        print('[VRM Proxy] windows bridge test failed: $e');
      }

      if (widget.bridgeGroup == VRMViewerWidget.wallEBridgeGroup) {
        // Start polling the page `#status` element so we can surface page status in logs for Windows as well.
        _statusPoller = Timer.periodic(const Duration(seconds: 2), (_) async {
          try {
            final res = await controller.executeScript(
              "(function(){const el=document.getElementById('status');return el?el.textContent||el.innerText:'<no-status-element>'})()",
            );
            final text = res?.toString() ?? '<no-result>';
            print('[VRM Viewer status] $text');
          } catch (e) {
            // Ignore until the page is ready
          }
        });
      }

      if (!mounted) {
        return;
      }

      setState(() {
        _windowsController = controller;
      });
    } catch (e, st) {
      print('[VRM Proxy] windows init error: $e');
      print(st);
      rethrow;
    }
  }

  Future<void> _handleRequest(HttpRequest request) async {
    final response = request.response;
    final path = Uri.decodeFull(request.uri.path);

    if (path == '/' || path == '/index.html') {
      final html = await rootBundle.loadString(widget.assetPath);
      final bytes = utf8.encode(html);
      print(
        '[VRM Proxy] serving index ${widget.assetPath} (${bytes.length} bytes)',
      );
      response
        ..statusCode = HttpStatus.ok
        ..headers.contentType = ContentType('text', 'html', charset: 'UTF-8')
        ..headers.contentLength = bytes.length
        ..add(bytes);
      await response.close();
      return;
    }

    final assetKey = _resolveAssetKey(path);
    print('[VRM Proxy] resolveAssetKey: path=$path -> assetKey=$assetKey');
    if (assetKey != null) {
      final data = await rootBundle.load(assetKey);
      final bytes = data.buffer.asUint8List(
        data.offsetInBytes,
        data.lengthInBytes,
      );
      print('[VRM Proxy] serving asset: $assetKey (${bytes.length} bytes)');
      response
        ..statusCode = HttpStatus.ok
        ..headers.add(
          HttpHeaders.contentTypeHeader,
          _contentTypeForAsset(assetKey),
        )
        ..headers.add(HttpHeaders.accessControlAllowOriginHeader, '*')
        ..headers.contentLength = bytes.length
        ..add(bytes);
      await response.close();
      return;
    }

    response
      ..statusCode = HttpStatus.notFound
      ..headers.contentType = ContentType.text
      ..write("Resource '${request.uri.path}' not found");
    await response.close();
  }

  String? _resolveAssetKey(String path) {
    if (path.startsWith('/3d%20model/') || path.startsWith('/3d model/')) {
      final decoded = path.startsWith('/') ? path.substring(1) : path;
      return Uri.decodeFull(decoded);
    }

    if (path.startsWith('/models/')) {
      return 'assets/web$path';
    }

    if (path.startsWith('/lib/')) {
      return 'assets/web$path';
    }

    if (path.startsWith('/utils/')) {
      return 'assets/web/lib/utils/${path.substring('/utils/'.length)}';
    }

    if (path.startsWith('/assets/web/utils/')) {
      return 'assets/web/lib/utils/${path.substring('/assets/web/utils/'.length)}';
    }

    if (path == '/three.module.js') {
      return 'assets/web/lib/three.module.js';
    }

    if (path == '/assets/web/three.module.js') {
      return 'assets/web/lib/three.module.js';
    }

    if (path.startsWith('/assets/')) {
      final assetPath = path.substring('/assets/'.length);
      if (assetPath.startsWith('web/')) {
        return 'assets/$assetPath';
      }
      return assetPath;
    }

    final normalized = path.startsWith('/') ? path.substring(1) : path;
    if (normalized == 'models/walle.glb' ||
        normalized == '3d model/sci-fi_humanoid_robot.glb' ||
        normalized == 'robot voice.aac' ||
        normalized == 'Voice tts.aac' ||
        normalized == 'robot%20voice.aac' ||
        normalized == 'Voice%20tts.aac' ||
        normalized.startsWith('wall evoices/') ||
        normalized.startsWith('wall%20evoices/')) {
      if (normalized.startsWith('wall%20evoices/')) {
        return Uri.decodeFull(normalized);
      }
      if (normalized == 'Voice%20tts.aac' ||
          normalized == 'robot%20voice.aac') {
        return Uri.decodeFull(normalized);
      }
      return normalized;
    }

    return null;
  }

  String _contentTypeForAsset(String assetKey) {
    if (assetKey.endsWith('.js')) {
      return 'application/javascript; charset=UTF-8';
    }
    if (assetKey.endsWith('.html')) {
      return 'text/html; charset=UTF-8';
    }
    if (assetKey.endsWith('.glb')) {
      return 'model/gltf-binary';
    }
    if (assetKey.endsWith('.gltf')) {
      return 'model/gltf+json';
    }
    if (assetKey.endsWith('.bin')) {
      return 'application/octet-stream';
    }
    if (assetKey.endsWith('.png')) {
      return 'image/png';
    }
    if (assetKey.endsWith('.jpg') || assetKey.endsWith('.jpeg')) {
      return 'image/jpeg';
    }
    if (assetKey.endsWith('.vrm')) {
      return 'model/gltf-binary';
    }
    if (assetKey.endsWith('.aac')) {
      return 'audio/aac';
    }
    if (assetKey.endsWith('.mpeg') || assetKey.endsWith('.mp3')) {
      return 'audio/mpeg';
    }
    return 'application/octet-stream';
  }

  @override
  void dispose() {
    VRMViewerWidget._mobileControllers.remove(widget.bridgeGroup);
    VRMViewerWidget._windowsControllers.remove(widget.bridgeGroup);
    _statusPoller?.cancel();
    unawaited(_proxy?.close(force: true));
    unawaited(_windowsController?.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (kIsWeb) {
      // Point the web viewer at the standalone HTML and prefer the new robot model.
      final url =
          'http://localhost:8080/assets/web/vrm_viewer.html?model=${VRMViewerWidget._defaultModelPath}';
      return SizedBox.expand(child: EmbeddedVrmView(url: url));
    }

    if (_isWindowsDesktop) {
      final controller = _windowsController;
      if (controller == null) {
        return const Center(
          child: CircularProgressIndicator(
            semanticsLabel: 'Loading robot viewer',
          ),
        );
      }

      return win_webview.Webview(controller);
    }

    final controller = _controller;
    if (controller == null) {
      return const Center(
        child: CircularProgressIndicator(
          semanticsLabel: 'Loading robot viewer',
        ),
      );
    }

    return WebViewWidget(controller: controller);
  }
}
