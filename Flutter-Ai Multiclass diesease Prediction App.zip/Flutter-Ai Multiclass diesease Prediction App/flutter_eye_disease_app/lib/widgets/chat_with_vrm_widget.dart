import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'vrm_viewer_embedded_with_blink_stub.dart'
    if (dart.library.html) 'vrm_viewer_embedded_with_blink.dart';
import 'vrm_viewer_widget.dart';

// Lightweight chat message model (keeps optional emotion fields for compatibility)
class ChatMessage {
  final String id;
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final String? emotion;
  final double? emotionIntensity;

  ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    DateTime? timestamp,
    this.emotion,
    this.emotionIntensity,
  }) : timestamp = timestamp ?? DateTime.now();

  ChatMessage copyWith({
    String? id,
    String? text,
    bool? isUser,
    DateTime? timestamp,
    String? emotion,
    double? emotionIntensity,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      text: text ?? this.text,
      isUser: isUser ?? this.isUser,
      timestamp: timestamp ?? this.timestamp,
      emotion: emotion ?? this.emotion,
      emotionIntensity: emotionIntensity ?? this.emotionIntensity,
    );
  }
}

// ChatWithVrmWidget matching the constructor used in main.dart.
class ChatWithVrmWidget extends StatefulWidget {
  final String apiBaseUrl;
  final String? userToken;
  final String? diseaseContext;

  const ChatWithVrmWidget({
    Key? key,
    this.apiBaseUrl = 'http://localhost:8000',
    this.userToken,
    this.diseaseContext,
  }) : super(key: key);

  @override
  _ChatWithVrmWidgetState createState() => _ChatWithVrmWidgetState();
}

class _ChatWithVrmWidgetState extends State<ChatWithVrmWidget> {
  final List<ChatMessage> _messages = [];
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool _isSending = false;
  String _statusText = 'Ready to chat';
  String? _activeVoiceLabel;

  static const List<String> _rotatingVoiceAssets = <String>['Voice tts.aac'];
  static const String _angryVoiceAsset = 'Voice tts.aac';
  static const Map<String, String> _voiceLabels = <String, String>{
    'Voice tts.aac': 'Voice',
  };
  int _replyVoiceCycle = 0;

  Uri get _chatUri => _resolveEndpoint('/api/chat');

  Uri _resolveEndpoint(String path) {
    final base = widget.apiBaseUrl.trim().replaceFirst(RegExp(r'/$'), '');
    return Uri.parse('$base$path');
  }

  @override
  void initState() {
    super.initState();
    unawaited(
      VRMViewerWidget.prepareConversationVoice(
        voiceAsset: _rotatingVoiceAssets.first,
      ),
    );
    // FIX 3: Use 'idle' pattern and lower intensity to prevent blink spam on init.
    unawaited(
      VRMViewerWidget.sendConversationStateCommand(
        active: true,
        intensity: 0.08, // was 0.12
        pattern: 'idle', // was 'chat_panel'
      ),
    );
  }

  @override
  void dispose() {
    unawaited(_stopTextGenerationMotion());
    unawaited(
      VRMViewerWidget.sendConversationStateCommand(
        active: false,
        intensity: 0.2,
        pattern: 'chat_panel',
      ),
    );
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _confirmAndClearChat() async {
    if (_messages.isEmpty) {
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete chat?'),
          content: const Text(
            'This will remove all messages from this conversation.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) {
      return;
    }

    await _stopTextGenerationMotion();
    setState(() {
      _messages.clear();
      _statusText = 'Ready to chat';
      _activeVoiceLabel = null;
      _replyVoiceCycle = 0;
    });
  }

  bool _textGenerationMotionActive = false;
  bool _generationVoiceActive = false;
  String? _currentVoiceAsset;

  bool _isAggressiveChat({
    required String userMessage,
    required String emotion,
  }) {
    final normalizedEmotion = emotion.toLowerCase();
    if (normalizedEmotion == 'angry' ||
        normalizedEmotion == 'aggressive' ||
        normalizedEmotion == 'frustrated') {
      return true;
    }

    final lower = userMessage.toLowerCase();
    const keywords = <String>[
      'angry',
      'aggressive',
      'aggression',
      'hate',
      'stupid',
      'idiot',
      'shut up',
      'annoying',
      'rude',
      'worst',
      'useless',
      'garbage',
      'trash',
      'furious',
      'mad at',
      'pissed',
    ];
    return keywords.any(lower.contains);
  }

  String _pickVoiceAsset({
    required String userMessage,
    required String emotion,
  }) {
    if (_isAggressiveChat(userMessage: userMessage, emotion: emotion)) {
      return _angryVoiceAsset;
    }

    final asset =
        _rotatingVoiceAssets[_replyVoiceCycle % _rotatingVoiceAssets.length];
    _replyVoiceCycle++;
    return asset;
  }

  String _labelForVoiceAsset(String asset) {
    return _voiceLabels[asset] ?? 'WALL-E voice';
  }

  Future<void> _startGenerationVoice(String voiceAsset) async {
    if (_generationVoiceActive && _currentVoiceAsset == voiceAsset) {
      return;
    }
    _generationVoiceActive = true;
    _currentVoiceAsset = voiceAsset;

    unawaited(
      VRMViewerWidget.sendConversationVoiceCommand(
        active: true,
        voiceAsset: voiceAsset,
      ),
    );
  }

  Future<void> _stopGenerationVoice() async {
    if (!_generationVoiceActive) {
      return;
    }
    _generationVoiceActive = false;
    _currentVoiceAsset = null;

    unawaited(VRMViewerWidget.sendConversationVoiceCommand(active: false));
  }

  int _delayForStreamToken(String token, {required bool isLast}) {
    final base = 14 + token.length * 9;
    return base.clamp(18, isLast ? 56 : 44);
  }

  int _estimateStreamDurationMs(List<String> tokens) {
    var total = 0;
    for (var index = 0; index < tokens.length; index++) {
      total += _delayForStreamToken(
        tokens[index],
        isLast: index >= tokens.length - 1,
      );
    }
    return total;
  }

  /// Total voice + nod duration scaled to answer length (stream time + read tail).
  int _estimateReplyPlaybackMs(String reply, List<String> tokens) {
    final streamMs = _estimateStreamDurationMs(tokens);
    final tailMs = (600 + reply.length * 28 + tokens.length * 35).clamp(
      900,
      8000,
    );
    return streamMs + tailMs;
  }

  List<String> _tokenizeForStreaming(String text) {
    final cleaned = text.trim();
    if (cleaned.isEmpty) {
      return <String>[];
    }

    final words = cleaned.split(RegExp(r'\s+'));
    if (words.isEmpty) {
      return <String>[cleaned];
    }

    return words;
  }

  // FIX 2: Boosted nod intensity (1.6x multiplier) + increased nod speed via
  // shorter expected_duration_ms so the JS side cycles nod animations faster.
  void _startTextGenerationMotion(
    double intensity, {
    required int expectedDurationMs,
    required String voiceAsset,
  }) {
    _textGenerationMotionActive = true;
    unawaited(_startGenerationVoice(voiceAsset));
    // No blink on speaking start — blink only fires once post-reply.
    unawaited(VRMViewerWidget.sendLLMGenerationCommand(active: true));
    unawaited(
      VRMViewerWidget.sendConversationStateCommand(
        active: true,
        intensity: (intensity * 3.0).clamp(0.85, 1.0),
        pattern: 'speaking',
      ),
    );
    unawaited(
      VRMViewerWidget.sendVrmCommand(
        command: <String, dynamic>{
          'animation_state': 'speaking',
          'motion_role': 'generation',
          'motion_phase': 'nod_start',
          'intensity': (intensity * 3.0).clamp(0.85, 1.0),
          // 50% of original — nod cycle runs twice as fast.
          'expected_duration_ms': (expectedDurationMs * 0.25).round(),
          'nod_speed_multiplier': 3.4,
        },
      ),
    );
  }

  // FIX 2 continued: same boosted intensity + speed hint for chunk sync.
  Future<void> _syncTextChunkMotion({
    required double intensity,
    required int chunkIndex,
    required int totalChunks,
    required int expectedDurationMs,
  }) async {
    if (!_textGenerationMotionActive) {
      return;
    }

    await VRMViewerWidget.sendVrmCommand(
      command: <String, dynamic>{
        'animation_state': 'speaking',
        'motion_role': 'generation',
        'motion_phase': 'nod',
        'intensity': (intensity * 3.0).clamp(0.85, 1.0),
        'chunk_index': chunkIndex,
        'chunk_total': totalChunks,
        'expected_duration_ms': (expectedDurationMs * 0.25).round(),
        'nod_speed_multiplier': 3.4,
      },
    );
  }

  Future<void> _stopTextGenerationMotion() async {
    if (!_textGenerationMotionActive) {
      return;
    }
    _textGenerationMotionActive = false;
    await _stopGenerationVoice();
    if (mounted) {
      setState(() {
        _activeVoiceLabel = null;
      });
    }
    await VRMViewerWidget.sendLLMGenerationCommand(active: false);
    await VRMViewerWidget.sendConversationStateCommand(
      active: false,
      intensity: 0.2,
      pattern: 'relaxed',
    );
  }

  Future<void> _animateAssistantReply({
    required String reply,
    required String emotion,
    required double emotionIntensity,
    required String userMessage,
  }) async {
    final tokens = _tokenizeForStreaming(reply);
    if (tokens.isEmpty) {
      return;
    }

    final assistantMessage = ChatMessage(
      id: DateTime.now().toIso8601String(),
      text: '',
      isUser: false,
      emotion: emotion,
      emotionIntensity: emotionIntensity,
    );

    final voiceAsset = _pickVoiceAsset(
      userMessage: userMessage,
      emotion: emotion,
    );
    final voiceLabel = _labelForVoiceAsset(voiceAsset);

    setState(() {
      _messages.add(assistantMessage);
      _statusText = 'Generating response...';
      _activeVoiceLabel = voiceLabel;
    });
    _scrollToBottom();

    final expectedPlaybackMs = _estimateReplyPlaybackMs(reply, tokens);
    final playbackClock = Stopwatch()..start();

    _startTextGenerationMotion(
      emotionIntensity,
      expectedDurationMs: expectedPlaybackMs,
      voiceAsset: voiceAsset,
    );

    var visibleText = '';
    for (var index = 0; index < tokens.length; index++) {
      if (!mounted) {
        playbackClock.stop();
        await _stopTextGenerationMotion();
        return;
      }

      final token = tokens[index];
      visibleText = visibleText.isEmpty ? token : '$visibleText $token';
      setState(() {
        _messages[_messages.length - 1] = assistantMessage.copyWith(
          text: visibleText,
        );
      });
      _scrollToBottom();

      if (index == 0 || index == tokens.length - 1 || index % 3 == 0) {
        unawaited(
          _syncTextChunkMotion(
            intensity: emotionIntensity,
            chunkIndex: index,
            totalChunks: tokens.length,
            expectedDurationMs: expectedPlaybackMs,
          ),
        );
      }

      // No blink during streaming — only post-reply blink fires in _sendMessage.

      await Future.delayed(
        Duration(
          milliseconds: _delayForStreamToken(
            token,
            isLast: index >= tokens.length - 1,
          ),
        ),
      );
    }

    if (mounted) {
      setState(() {
        _messages[_messages.length - 1] = assistantMessage.copyWith(
          text: reply,
        );
      });
      _scrollToBottom();
    }

    playbackClock.stop();
    final remainingPlaybackMs =
        expectedPlaybackMs - playbackClock.elapsedMilliseconds;
    if (remainingPlaybackMs > 0) {
      await Future.delayed(Duration(milliseconds: remainingPlaybackMs));
    }
    await _stopTextGenerationMotion();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) {
        return;
      }
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  String _blinkPatternForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'happy':
      case 'excited':
        return 'excited';
      case 'concerned':
      case 'sadness':
        return 'thinking';
      case 'confused':
        return 'attentive';
      default:
        return 'engaged';
    }
  }

  int _blinkDurationForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'happy':
      case 'excited':
        return 110;
      case 'concerned':
        return 180;
      case 'sadness':
        return 210;
      case 'confused':
        return 160;
      default:
        return 150;
    }
  }

  String? _buildMemoryContext() {
    if (_messages.isEmpty) {
      return null;
    }
    final recent = _messages.length > 10
        ? _messages.sublist(_messages.length - 10)
        : _messages;
    return recent
        .map(
          (message) =>
              '${message.isUser ? 'User' : 'Assistant'}: ${message.text.trim()}',
        )
        .where((line) => line.length > 12)
        .join('\n');
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;

    setState(() {
      _messages.add(
        ChatMessage(
          id: DateTime.now().toIso8601String(),
          text: text,
          isUser: true,
        ),
      );
      _messageController.clear();
      _isSending = true;
      _statusText = 'Thinking...';
    });
    _scrollToBottom();

    try {
      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if ((widget.userToken ?? '').trim().isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.userToken!.trim()}';
      }

      final response = await http.post(
        _chatUri,
        headers: headers,
        body: jsonEncode(<String, dynamic>{
          'message': text,
          if (widget.diseaseContext != null)
            'disease_context': widget.diseaseContext,
          if (_buildMemoryContext() != null)
            'memory_context': _buildMemoryContext(),
        }),
      );

      if (response.statusCode != 200) {
        throw StateError('Backend returned ${response.statusCode}');
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final reply = (data['ai_response'] ?? data['response'] ?? '')
          .toString()
          .trim();
      final emotion = (data['emotion'] ?? 'neutral').toString();
      final emotionIntensity =
          (data['emotion_intensity'] as num?)?.toDouble() ?? 0.35;
      final rawCommand = data['vrm_command'];

      if (!mounted) {
        return;
      }

      final finalReply = reply.isEmpty
          ? 'I am here, but I could not generate a reply.'
          : reply;

      await _animateAssistantReply(
        reply: finalReply,
        emotion: emotion,
        emotionIntensity: emotionIntensity,
        userMessage: text,
      );

      if (!mounted) {
        return;
      }

      setState(() {
        _statusText = 'Emotion: ${emotion.toUpperCase()}';
      });

      if (rawCommand is Map) {
        unawaited(
          VRMViewerWidget.sendVrmCommand(
            command: Map<String, dynamic>.from(rawCommand as Map),
          ),
        );
      }

      // FIX 4: Delay post-reply blink so it doesn't collide with motion cleanup.
      await Future.delayed(const Duration(milliseconds: 400));

      if (!mounted) return;

      unawaited(
        VRMViewerWidget.sendBlinkCommand(
          intensity: emotionIntensity.clamp(0.0, 1.0),
          pattern: _blinkPatternForEmotion(emotion),
          duration: _blinkDurationForEmotion(emotion),
        ),
      );
    } catch (_) {
      if (!mounted) {
        return;
      }

      setState(() {
        _messages.add(
          ChatMessage(
            id: DateTime.now().toIso8601String(),
            text:
                'I could not reach the chat backend right now. Please try again.',
            isUser: false,
            emotion: 'error',
            emotionIntensity: 0.1,
          ),
        );
        _statusText = 'Backend unavailable';
      });
      _scrollToBottom();
    } finally {
      await Future.delayed(const Duration(milliseconds: 180));

      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }

      await _stopTextGenerationMotion();
    }
  }

  Widget _buildMessageBubble(ChatMessage message, ColorScheme colorScheme) {
    final alignment = message.isUser
        ? Alignment.centerRight
        : Alignment.centerLeft;
    final bubbleColor = message.isUser
        ? colorScheme.primary
        : colorScheme.surfaceContainerHighest;
    final textColor = message.isUser
        ? colorScheme.onPrimary
        : colorScheme.onSurface;

    return Align(
      alignment: alignment,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 560),
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: bubbleColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(message.isUser ? 18 : 6),
            bottomRight: Radius.circular(message.isUser ? 6 : 18),
          ),
          border: Border.all(
            color: message.isUser
                ? colorScheme.primary.withValues(alpha: 0.2)
                : colorScheme.outlineVariant.withValues(alpha: 0.65),
          ),
        ),
        child: Column(
          crossAxisAlignment: message.isUser
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: [
            Text(
              message.text,
              style: Theme.of(
                context,
              ).textTheme.bodyLarge?.copyWith(color: textColor, height: 1.35),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  message.isUser
                      ? Icons.person_outline
                      : Icons.smart_toy_outlined,
                  size: 14,
                  color: textColor.withValues(alpha: 0.7),
                ),
                const SizedBox(width: 6),
                Text(
                  message.isUser ? 'You' : 'WALL-E',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: textColor.withValues(alpha: 0.72),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (message.emotion != null) ...[
                  const SizedBox(width: 10),
                  Text(
                    message.emotion!.toUpperCase(),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: textColor.withValues(alpha: 0.55),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatPanel(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [colorScheme.surface, colorScheme.surfaceContainerLowest],
        ),
      ),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
            decoration: BoxDecoration(
              color: colorScheme.surface.withValues(alpha: 0.88),
              border: Border(
                bottom: BorderSide(
                  color: colorScheme.outlineVariant.withValues(alpha: 0.5),
                ),
              ),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: colorScheme.primaryContainer,
                  child: Icon(
                    Icons.smart_toy_outlined,
                    color: colorScheme.onPrimaryContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'WALL-E Chat',
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _statusText,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      if (_activeVoiceLabel != null) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: _activeVoiceLabel == 'Intense tone'
                                ? colorScheme.errorContainer.withValues(
                                    alpha: 0.85,
                                  )
                                : colorScheme.primaryContainer.withValues(
                                    alpha: 0.85,
                                  ),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _activeVoiceLabel == 'Intense tone'
                                    ? Icons.bolt_rounded
                                    : Icons.graphic_eq_rounded,
                                size: 14,
                                color: _activeVoiceLabel == 'Intense tone'
                                    ? colorScheme.onErrorContainer
                                    : colorScheme.onPrimaryContainer,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _activeVoiceLabel!,
                                style: Theme.of(context).textTheme.labelSmall
                                    ?.copyWith(
                                      color: _activeVoiceLabel == 'Intense tone'
                                          ? colorScheme.onErrorContainer
                                          : colorScheme.onPrimaryContainer,
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Delete chat',
                  onPressed: _isSending ? null : _confirmAndClearChat,
                  icon: Icon(
                    Icons.delete_outline_rounded,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                if (_isSending)
                  SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: colorScheme.primary,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              itemCount: _messages.length + 1,
              itemBuilder: (context, index) {
                if (index == 0 && _messages.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: Center(
                      child: Text(
                        'Send a message to start the chat.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  );
                }

                if (index == _messages.length) {
                  return const SizedBox(height: 20);
                }

                return _buildMessageBubble(_messages[index], colorScheme);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    enabled: !_isSending,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                    decoration: const InputDecoration(
                      hintText: 'Type a message',
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 52,
                  height: 52,
                  child: FilledButton(
                    onPressed: _isSending ? null : _sendMessage,
                    child: const Icon(Icons.send),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth >= 980;
            final viewer = Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(
                      context,
                    ).colorScheme.shadow.withValues(alpha: 0.12),
                    blurRadius: 24,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: const VRMViewerWidget(
                  bridgeGroup: VRMViewerWidget.wallEBridgeGroup,
                ),
              ),
            );

            final chat = ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: _buildChatPanel(context),
            );

            return Padding(
              padding: const EdgeInsets.all(16),
              child: wide
                  ? Row(
                      children: [
                        Expanded(flex: 5, child: viewer),
                        const SizedBox(width: 16),
                        Expanded(flex: 4, child: chat),
                      ],
                    )
                  : Column(
                      children: [
                        SizedBox(
                          height: constraints.maxHeight * 0.42,
                          child: viewer,
                        ),
                        const SizedBox(height: 16),
                        Expanded(child: chat),
                      ],
                    ),
            );
          },
        ),
      ),
    );
  }
}
