import 'dart:html' as html;
import 'dart:ui_web' as ui;
import 'package:flutter/widgets.dart';

/// Web-only embedded VRM preview with blink command support
class EmbeddedVrmViewWithBlink extends StatefulWidget {
  final String url;

  const EmbeddedVrmViewWithBlink({super.key, required this.url});

  @override
  State<EmbeddedVrmViewWithBlink> createState() =>
      _EmbeddedVrmViewWithBlinkState();

  static void sendBlinkCommand(
    BuildContext context, {
    required double intensity,
    required String pattern,
    int duration = 150,
  }) {
    final state = context
        .findAncestorStateOfType<_EmbeddedVrmViewWithBlinkState>();
    state?.sendBlink(intensity, pattern, duration);
  }

  static void sendConversationStateCommand(
    BuildContext context, {
    required bool active,
    double intensity = 0.35,
    String pattern = 'conversing',
  }) {
    final state = context
        .findAncestorStateOfType<_EmbeddedVrmViewWithBlinkState>();
    state?.sendConversationState(active, intensity, pattern);
  }

  static void sendVrmCommand(
    BuildContext context, {
    required Map<String, dynamic> command,
  }) {
    final state = context
        .findAncestorStateOfType<_EmbeddedVrmViewWithBlinkState>();
    state?.sendVrmCommand(command);
  }
}

// Provide a convenience to call conversation state from widgets.
void sendConversationStateCommand(
  BuildContext context, {
  required bool active,
  double intensity = 0.35,
  String pattern = 'conversing',
}) {
  final state = context
      .findAncestorStateOfType<_EmbeddedVrmViewWithBlinkState>();
  state?.sendConversationState(active, intensity, pattern);
}

void sendVrmCommand(
  BuildContext context, {
  required Map<String, dynamic> command,
}) {
  final state = context
      .findAncestorStateOfType<_EmbeddedVrmViewWithBlinkState>();
  state?.sendVrmCommand(command);
}

class _EmbeddedVrmViewWithBlinkState extends State<EmbeddedVrmViewWithBlink> {
  html.IFrameElement? _iframeElement;
  String? _viewId;

  void sendBlink(double intensity, String pattern, int duration) {
    if (_iframeElement == null) {
      print('[VRM] Iframe not ready for blink command');
      return;
    }

    try {
      // Send blink command via postMessage to the iframe
      _iframeElement!.contentWindow?.postMessage(
        <String, dynamic>{
          'action': 'blink',
          'intensity': intensity.clamp(0.0, 1.0),
          'pattern': pattern,
          'duration': duration,
        },
        '*', // Allow any origin
      );
      print('[VRM] Blink command sent: intensity=$intensity, pattern=$pattern');
    } catch (e) {
      print('[VRM] Error sending blink command: $e');
    }
  }

  void sendConversationState(bool active, double intensity, String pattern) {
    if (_iframeElement == null) {
      print('[VRM] Iframe not ready for conversation command');
      return;
    }

    try {
      _iframeElement!.contentWindow?.postMessage(<String, dynamic>{
        'action': 'conversation',
        'active': active,
        'intensity': intensity.clamp(0.0, 1.0),
        'pattern': pattern,
      }, '*');
      print(
        '[VRM] Conversation state sent: active=$active, intensity=$intensity',
      );
    } catch (e) {
      print('[VRM] Error sending conversation state: $e');
    }
  }

  void sendVrmCommand(Map<String, dynamic> command) {
    if (_iframeElement == null) {
      print('[VRM] Iframe not ready for VRM command');
      return;
    }

    try {
      _iframeElement!.contentWindow?.postMessage(<String, dynamic>{
        'action': 'vrm_command',
        'command': command,
      }, '*');
      print('[VRM] VRM command sent: $command');
    } catch (e) {
      print('[VRM] Error sending VRM command: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _viewId = 'vrm-iframe-${widget.url.hashCode}';

    // Register view factory once
    try {
      ui.platformViewRegistry.registerViewFactory(_viewId!, (int viewIdInt) {
        _iframeElement = html.IFrameElement()
          ..src = widget.url
          ..style.border = '0'
          ..style.width = '100%'
          ..style.height = '100%'
          ..allow =
              'camera; microphone; autoplay; clipboard-read; clipboard-write';

        // Add onLoad listener to ensure iframe is ready
        _iframeElement!.onLoad.listen((_) {
          print('[VRM] Iframe loaded and ready for commands');
        });

        return _iframeElement!;
      });
    } catch (e) {
      print('[VRM] Error registering view factory: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return HtmlElementView(viewType: _viewId!);
  }
}
