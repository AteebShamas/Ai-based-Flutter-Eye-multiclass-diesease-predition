export 'walle_model_viewer_view_stub.dart'
    if (dart.library.html) 'walle_model_viewer_view_web.dart';
