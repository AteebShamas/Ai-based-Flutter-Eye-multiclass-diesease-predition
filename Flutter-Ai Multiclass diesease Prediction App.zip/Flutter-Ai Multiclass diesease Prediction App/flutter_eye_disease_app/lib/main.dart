import 'dart:io';
import 'dart:convert';
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'theme_provider.dart';
import 'widgets/vrm_viewer_widget.dart';
import 'widgets/chat_with_vrm_widget.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ReminderNotificationService.instance.initialize();
  runApp(const VisDectApp());
}

String normalizeApiBaseUrl(String rawUrl) {
  final trimmed = rawUrl.trim();
  if (trimmed.isEmpty) {
    return trimmed;
  }

  final parsed = Uri.tryParse(trimmed);
  if (parsed == null) {
    return trimmed;
  }

  final host = parsed.host.toLowerCase();

  if (kIsWeb) {
    if (host == '10.0.2.2') {
      return parsed.replace(host: '127.0.0.1').toString();
    }
    return trimmed;
  }

  if (defaultTargetPlatform != TargetPlatform.android) {
    return trimmed;
  }

  if (host != '127.0.0.1' && host != 'localhost') {
    return trimmed;
  }

  final updated = parsed.replace(host: '10.0.2.2');
  return updated.toString();
}

String formatLocalDateTime(DateTime value) {
  final local = value.toLocal();
  final month = local.month.toString().padLeft(2, '0');
  final day = local.day.toString().padLeft(2, '0');
  final hour = local.hour.toString().padLeft(2, '0');
  final minute = local.minute.toString().padLeft(2, '0');
  return '${local.year}-$month-$day $hour:$minute';
}

String formatReportDate(DateTime value) {
  final local = value.toLocal();
  final month = local.month.toString().padLeft(2, '0');
  final day = local.day.toString().padLeft(2, '0');
  return '${local.year}-$month-$day';
}

String buildClinicalReportFilename(String diseaseLabel, DateTime diagnoseDate) {
  final safeDisease = diseaseLabel
      .trim()
      .replaceAll(RegExp(r'[^\w\-]+'), '_')
      .replaceAll(RegExp(r'_+'), '_')
      .replaceAll(RegExp(r'^_|_$'), '');
  return '${safeDisease.isEmpty ? 'Report' : safeDisease}_${formatReportDate(diagnoseDate)}.pdf';
}

Rect? _shareOriginForContext(BuildContext context) {
  final renderObject = context.findRenderObject();
  if (renderObject is! RenderBox || !renderObject.hasSize) {
    return null;
  }
  return renderObject.localToGlobal(Offset.zero) & renderObject.size;
}

enum ConfidenceTier { high, moderate, low }

ConfidenceTier getConfidenceTier(double confidence) {
  if (confidence >= 0.85) {
    return ConfidenceTier.high;
  }
  if (confidence >= 0.65) {
    return ConfidenceTier.moderate;
  }
  return ConfidenceTier.low;
}

class VisDectApp extends StatefulWidget {
  const VisDectApp({super.key});

  @override
  State<VisDectApp> createState() => _VisDectAppState();
}

class _VisDectAppState extends State<VisDectApp> {
  static const String _defaultApiBaseUrl = kIsWeb
      ? 'http://127.0.0.1:8000'
      : 'http://127.0.0.1:8000';

  bool _isBootstrapping = true;
  String _apiBaseUrl = _defaultApiBaseUrl;
  AuthSession? _session;
  late ThemeProvider _themeProvider;

  @override
  void initState() {
    super.initState();
    _themeProvider = ThemeProvider();
    _loadLanguage();
    _bootstrap();
  }

  Future<void> _loadLanguage() async {}

  Future<void> _bootstrap() async {
    final prefs = await SharedPreferences.getInstance();
    var savedApiUrl = normalizeApiBaseUrl(
      prefs.getString('api_base_url') ?? _defaultApiBaseUrl,
    );

    // Migrate older saved web defaults (port 5000) to the current backend port 8000
    if (kIsWeb && savedApiUrl.contains(':5000')) {
      savedApiUrl = savedApiUrl.replaceAll(':5000', ':8000');
    }
    final savedToken = prefs.getString('auth_token');

    await prefs.setString('api_base_url', savedApiUrl);

    AuthSession? restoredSession;
    if (savedToken != null && savedToken.isNotEmpty) {
      final apiClient = ApiClient(baseUrl: savedApiUrl, token: savedToken);
      try {
        final user = await apiClient.getMe();
        restoredSession = AuthSession(token: savedToken, user: user);
      } catch (_) {
        await prefs.remove('auth_token');
        await prefs.remove('user_id');
        await prefs.remove('user_full_name');
        await prefs.remove('user_email');
      }
    }

    if (!mounted) {
      return;
    }
    setState(() {
      _apiBaseUrl = savedApiUrl;
      _session = restoredSession;
      _isBootstrapping = false;
    });
  }

  Future<void> _handleAuthenticated(
    AuthResponse response,
    String apiBaseUrl,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_base_url', apiBaseUrl);
    await prefs.setString('auth_token', response.accessToken);
    await prefs.setInt('user_id', response.user.id);
    await prefs.setString('user_full_name', response.user.fullName);
    await prefs.setString('user_email', response.user.email);

    if (!mounted) {
      return;
    }
    setState(() {
      _apiBaseUrl = apiBaseUrl;
      _session = AuthSession(token: response.accessToken, user: response.user);
    });
  }

  Future<void> _handleLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('user_id');
    await prefs.remove('user_full_name');
    await prefs.remove('user_email');

    if (!mounted) {
      return;
    }
    setState(() {
      _session = null;
    });
  }

  Future<void> _updateApiBaseUrl(String apiBaseUrl) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_base_url', apiBaseUrl);
    if (!mounted) {
      return;
    }
    setState(() {
      _apiBaseUrl = apiBaseUrl;
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget home;
    if (_isBootstrapping) {
      home = const _SplashScreen();
    } else if (_session == null) {
      home = AuthScreen(
        initialApiBaseUrl: _apiBaseUrl,
        onAuthenticated: _handleAuthenticated,
      );
    } else {
      home = DashboardScreen(
        apiBaseUrl: _apiBaseUrl,
        session: _session!,
        onLogout: _handleLogout,
        onApiBaseUrlChanged: _updateApiBaseUrl,
        themeProvider: _themeProvider,
      );
    }

    final shellHome = AnimatedSwitcher(
      duration: const Duration(milliseconds: 520),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      transitionBuilder: (Widget child, Animation<double> animation) {
        final slide = Tween<Offset>(
          begin: const Offset(0, 0.06),
          end: Offset.zero,
        ).animate(animation);
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(position: slide, child: child),
        );
      },
      child: KeyedSubtree(
        key: ValueKey<String>(
          _isBootstrapping
              ? 'boot'
              : _session == null
              ? 'auth'
              : 'dash',
        ),
        child: home,
      ),
    );

    return AnimatedBuilder(
      animation: _themeProvider,
      builder: (BuildContext context, Widget? child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'VisDect',
          theme: _themeProvider.getLightTheme(),
          darkTheme: _themeProvider.getDarkTheme(),
          themeMode: _themeProvider.isDarkMode
              ? ThemeMode.dark
              : ThemeMode.light,
          home: shellHome,
        );
      },
    );
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[
              Color(0xFFE8F8FB),
              Color(0xFFD6EEF2),
              Color(0xFFF4F7FF),
            ],
          ),
        ),
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0.85, end: 1),
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeOutBack,
            builder: (BuildContext context, double value, Widget? child) {
              return Transform.scale(
                scale: value,
                child: Opacity(opacity: value.clamp(0, 1), child: child),
              );
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        blurRadius: 30,
                        offset: const Offset(0, 12),
                        color: Colors.teal.withValues(alpha: 0.22),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.visibility,
                    size: 42,
                    color: Color(0xFF0E7490),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'VisDect',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.9,
                  ),
                ),
                const SizedBox(height: 14),
                const SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(strokeWidth: 2.8),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({
    super.key,
    required this.initialApiBaseUrl,
    required this.onAuthenticated,
  });

  final String initialApiBaseUrl;
  final Future<void> Function(AuthResponse response, String apiBaseUrl)
  onAuthenticated;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final TextEditingController _apiUrlController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _isRegisterMode = false;
  bool _isSubmitting = false;
  bool _obscurePassword = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _apiUrlController.text = widget.initialApiBaseUrl;
  }

  @override
  void dispose() {
    _apiUrlController.dispose();
    _fullNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final apiBaseUrl = normalizeApiBaseUrl(_apiUrlController.text);
    final fullName = _fullNameController.text.trim();
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (!apiBaseUrl.startsWith('http')) {
      setState(() {
        _error = 'API URL must start with http or https.';
      });
      return;
    }
    if (_isRegisterMode && fullName.length < 2) {
      setState(() {
        _error = 'Please enter a valid full name.';
      });
      return;
    }
    if (!email.contains('@')) {
      setState(() {
        _error = 'Please enter a valid email address.';
      });
      return;
    }
    if (password.length < 6) {
      setState(() {
        _error = 'Password must be at least 6 characters.';
      });
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
      _apiUrlController.text = apiBaseUrl;
    });

    try {
      final apiClient = ApiClient(baseUrl: apiBaseUrl);
      final response = _isRegisterMode
          ? await apiClient.register(
              fullName: fullName,
              email: email,
              password: password,
            )
          : await apiClient.login(email: email, password: password);

      await widget.onAuthenticated(response, apiBaseUrl);
    } catch (e) {
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[
              Color(0xFFE8F4F8),
              Color(0xFFE5F1F5),
              Color(0xFFF4FAFF),
            ],
          ),
        ),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -120,
              right: -60,
              child: Container(
                width: 280,
                height: 280,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF0E7490).withValues(alpha: 0.14),
                ),
              ),
            ),
            Positioned(
              bottom: -80,
              left: -40,
              child: Container(
                width: 220,
                height: 220,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF0F766E).withValues(alpha: 0.12),
                ),
              ),
            ),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 470),
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0.92, end: 1),
                      duration: const Duration(milliseconds: 650),
                      curve: Curves.easeOutCubic,
                      builder:
                          (BuildContext context, double value, Widget? child) {
                            return Transform.translate(
                              offset: Offset(0, (1 - value) * 42),
                              child: Opacity(
                                opacity: value.clamp(0, 1),
                                child: child,
                              ),
                            );
                          },
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(22),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'VisDect',
                                style: GoogleFonts.spaceGrotesk(
                                  fontSize: 34,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: -1.1,
                                ),
                              ),
                              const SizedBox(height: 8),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 280),
                                transitionBuilder:
                                    (
                                      Widget child,
                                      Animation<double> animation,
                                    ) {
                                      return FadeTransition(
                                        opacity: animation,
                                        child: SlideTransition(
                                          position: Tween<Offset>(
                                            begin: const Offset(0, 0.15),
                                            end: Offset.zero,
                                          ).animate(animation),
                                          child: child,
                                        ),
                                      );
                                    },
                                child: Text(
                                  _isRegisterMode
                                      ? 'Create an account to save patient prediction history.'
                                      : 'Sign in to continue diagnosis and history tracking.',
                                  key: ValueKey<bool>(_isRegisterMode),
                                ),
                              ),
                              const SizedBox(height: 18),
                              TextField(
                                controller: _apiUrlController,
                                enabled: !_isSubmitting,
                                decoration: InputDecoration(
                                  labelText: 'Backend API URL',
                                  helperText: kIsWeb
                                      ? 'Web: http://127.0.0.1:8000'
                                      : 'Phone/Emulator: http://192.168.1.6:8000',
                                  prefixIcon: const Icon(Icons.link_outlined),
                                ),
                              ),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 280),
                                child: _isRegisterMode
                                    ? Padding(
                                        key: const ValueKey<String>('fullName'),
                                        padding: const EdgeInsets.only(top: 12),
                                        child: TextField(
                                          controller: _fullNameController,
                                          enabled: !_isSubmitting,
                                          decoration: const InputDecoration(
                                            labelText: 'Full Name',
                                            prefixIcon: Icon(
                                              Icons.person_outline,
                                            ),
                                          ),
                                        ),
                                      )
                                    : const SizedBox.shrink(
                                        key: ValueKey<String>('noFullName'),
                                      ),
                              ),
                              const SizedBox(height: 12),
                              TextField(
                                controller: _emailController,
                                enabled: !_isSubmitting,
                                keyboardType: TextInputType.emailAddress,
                                decoration: const InputDecoration(
                                  labelText: 'Email',
                                  prefixIcon: Icon(Icons.alternate_email),
                                ),
                              ),
                              const SizedBox(height: 12),
                              TextField(
                                controller: _passwordController,
                                enabled: !_isSubmitting,
                                obscureText: _obscurePassword,
                                decoration: InputDecoration(
                                  labelText: 'Password',
                                  prefixIcon: const Icon(Icons.lock_outline),
                                  suffixIcon: IconButton(
                                    onPressed: _isSubmitting
                                        ? null
                                        : () {
                                            setState(() {
                                              _obscurePassword =
                                                  !_obscurePassword;
                                            });
                                          },
                                    icon: Icon(
                                      _obscurePassword
                                          ? Icons.visibility_off_outlined
                                          : Icons.visibility_outlined,
                                    ),
                                  ),
                                ),
                              ),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 220),
                                child: _error == null
                                    ? const SizedBox(height: 0)
                                    : Padding(
                                        key: ValueKey<String>(_error!),
                                        padding: const EdgeInsets.only(top: 10),
                                        child: Container(
                                          width: double.infinity,
                                          padding: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                            color: Theme.of(
                                              context,
                                            ).colorScheme.errorContainer,
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                          child: Text(
                                            _error!,
                                            style: TextStyle(
                                              color: Theme.of(
                                                context,
                                              ).colorScheme.onErrorContainer,
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                              const SizedBox(height: 14),
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton.icon(
                                  onPressed: _isSubmitting ? null : _submit,
                                  icon: _isSubmitting
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : Icon(
                                          _isRegisterMode
                                              ? Icons.person_add_alt_1
                                              : Icons.login,
                                        ),
                                  label: Text(
                                    _isSubmitting
                                        ? 'Please wait...'
                                        : _isRegisterMode
                                        ? 'Create Account'
                                        : 'Sign In',
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Align(
                                alignment: Alignment.center,
                                child: TextButton(
                                  onPressed: _isSubmitting
                                      ? null
                                      : () {
                                          setState(() {
                                            _isRegisterMode = !_isRegisterMode;
                                            _error = null;
                                          });
                                        },
                                  child: Text(
                                    _isRegisterMode
                                        ? 'Already have an account? Sign in'
                                        : 'No account yet? Create one',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.apiBaseUrl,
    required this.session,
    required this.onLogout,
    required this.onApiBaseUrlChanged,
    required this.themeProvider,
  });

  final String apiBaseUrl;
  final AuthSession session;
  final Future<void> Function() onLogout;
  final Future<void> Function(String apiBaseUrl) onApiBaseUrlChanged;
  final ThemeProvider themeProvider;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tabIndex = 0;
  int _historyRefreshSeed = 0;
  late ApiClient _apiClient;

  @override
  void initState() {
    super.initState();
    _apiClient = ApiClient(
      baseUrl: widget.apiBaseUrl,
      token: widget.session.token,
    );
  }

  @override
  void didUpdateWidget(covariant DashboardScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.apiBaseUrl != oldWidget.apiBaseUrl ||
        widget.session.token != oldWidget.session.token) {
      _apiClient = ApiClient(
        baseUrl: widget.apiBaseUrl,
        token: widget.session.token,
      );
    }
  }

  Future<void> _editApiUrl() async {
    final controller = TextEditingController(text: widget.apiBaseUrl);
    final result = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Update API URL'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(
              hintText: 'https://your-backend.example.com',
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.of(context).pop(controller.text.trim()),
              child: const Text('Save'),
            ),
          ],
        );
      },
    );

    if (result == null || result.isEmpty || !result.startsWith('http')) {
      return;
    }
    await widget.onApiBaseUrlChanged(normalizeApiBaseUrl(result));
  }

  @override
  Widget build(BuildContext context) {
    final titles = <String>['Diagnosis', 'History', 'Reminders', '3D', 'Chat'];
    final pages = <Widget>[
      DiagnosisView(
        apiClient: _apiClient,
        user: widget.session.user,
        onPredictionStored: () {
          setState(() {
            _historyRefreshSeed++;
          });
        },
      ),
      HistoryView(apiClient: _apiClient, refreshSeed: _historyRefreshSeed),
      const ReminderView(),
      const Eye3DViewScreen(),
      ChatWithVrmWidget(
        apiBaseUrl: widget.apiBaseUrl,
        userToken: widget.session.token,
        diseaseContext: null,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: AnimatedSwitcher(
          duration: const Duration(milliseconds: 260),
          transitionBuilder: (Widget child, Animation<double> animation) {
            return FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.25),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              ),
            );
          },
          child: Text(
            titles[_tabIndex],
            key: ValueKey<int>(_tabIndex),
            style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700),
          ),
        ),
        actions: <Widget>[
          IconButton(
            onPressed: _editApiUrl,
            tooltip: 'API URL',
            icon: const Icon(Icons.cloud_sync_outlined),
          ),
          IconButton(
            onPressed: () => widget.onLogout(),
            tooltip: 'Logout',
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: Stack(
        children: List<Widget>.generate(pages.length, (int index) {
          final selected = _tabIndex == index;
          return IgnorePointer(
            ignoring: !selected,
            child: AnimatedOpacity(
              opacity: selected ? 1 : 0,
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOut,
              child: AnimatedSlide(
                duration: const Duration(milliseconds: 280),
                curve: Curves.easeOutCubic,
                offset: selected ? Offset.zero : const Offset(0.03, 0),
                child: pages[index],
              ),
            ),
          );
        }),
      ),
      bottomNavigationBar: NavigationBar(
        height: 68,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        backgroundColor: Theme.of(
          context,
        ).colorScheme.surface.withValues(alpha: 0.98),
        surfaceTintColor: Colors.transparent,
        elevation: 8,
        selectedIndex: _tabIndex,
        onDestinationSelected: (int index) {
          setState(() {
            _tabIndex = index;
          });
        },
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.visibility_outlined),
            selectedIcon: Icon(Icons.visibility),
            label: 'Diagnose',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_active_outlined),
            selectedIcon: Icon(Icons.notifications_active),
            label: 'Reminders',
          ),
          NavigationDestination(
            icon: Icon(Icons.view_in_ar_outlined),
            selectedIcon: Icon(Icons.view_in_ar),
            label: '3D',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_outlined),
            selectedIcon: Icon(Icons.chat),
            label: 'Chat',
          ),
        ],
      ),
    );
  }
}

class Eye3DViewScreen extends StatefulWidget {
  const Eye3DViewScreen({super.key});

  @override
  State<Eye3DViewScreen> createState() => _Eye3DViewScreenState();
}

class _Eye3DViewScreenState extends State<Eye3DViewScreen>
    with SingleTickerProviderStateMixin {
  static const String _eyeViewerAsset = 'assets/web/eye_viewer.html';

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFFEAF7FA), Color(0xFFF2F9FD)],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              'Realistic Human Eye',
                              style: GoogleFonts.spaceGrotesk(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Photorealistic 3D eyeball with iris, cornea & sclera — drag to rotate, scroll to zoom in.',
                        style: GoogleFonts.inter(
                          fontSize: 13,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: kIsWeb
                      ? const Center(
                          child: Text(
                            'Use the desktop or Android app for the 3D eye view',
                          ),
                        )
                      : const VRMViewerWidget(
                          assetPath: _eyeViewerAsset,
                          bridgeGroup: VRMViewerWidget.eyeBridgeGroup,
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DiagnosisView extends StatefulWidget {
  const DiagnosisView({
    super.key,
    required this.apiClient,
    required this.user,
    required this.onPredictionStored,
  });

  final ApiClient apiClient;
  final UserProfile user;
  final VoidCallback onPredictionStored;

  @override
  State<DiagnosisView> createState() => _DiagnosisViewState();
}

class _DiagnosisViewState extends State<DiagnosisView> {
  final ImagePicker _picker = ImagePicker();
  XFile? _selectedImage;
  Uint8List? _selectedImageBytes;
  bool _isPredicting = false;
  String _predictingStage = 'Analyzing OCT image...';
  String? _error;
  PredictionResponse? _result;

  Future<void> _pickImage(ImageSource source) async {
    final image = await _picker.pickImage(source: source);
    if (image == null) {
      return;
    }
    final imageBytes = await image.readAsBytes();
    setState(() {
      _selectedImage = image;
      _selectedImageBytes = imageBytes;
      _error = null;
      _result = null;
    });
  }

  Future<void> _predict() async {
    if (_selectedImage == null || _selectedImageBytes == null) {
      setState(() {
        _error = 'Please capture or select an OCT image.';
      });
      return;
    }

    setState(() {
      _isPredicting = true;
      _predictingStage = 'Uploading image...';
      _error = null;
      _result = null;
    });

    try {
      setState(() {
        _predictingStage = 'Running AI model...';
      });
      final response = await widget.apiClient.predictImage(
        imageBytes: _selectedImageBytes!,
        fileName: _selectedImage!.name,
      );
      setState(() {
        _predictingStage = 'Saving prediction...';
        _result = response;
      });
      widget.onPredictionStored();
    } catch (e) {
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      setState(() {
        _isPredicting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFFEAF7FA),
            Color(0xFFDFF2F5),
            Color(0xFFF1F8FE),
          ],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0.93, end: 1),
                duration: const Duration(milliseconds: 420),
                curve: Curves.easeOutCubic,
                builder: (BuildContext context, double value, Widget? child) {
                  return Transform.translate(
                    offset: Offset(0, (1 - value) * 28),
                    child: Opacity(opacity: value.clamp(0, 1), child: child),
                  );
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Welcome, ${widget.user.fullName}',
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.8,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.75),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Capture or upload an OCT scan, then run prediction to get disease class and prevention guidance.',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _isPredicting
                                  ? null
                                  : () => _pickImage(ImageSource.gallery),
                              icon: const Icon(Icons.photo_library_outlined),
                              label: const Text('Gallery'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _isPredicting
                                  ? null
                                  : () => _pickImage(ImageSource.camera),
                              icon: const Icon(Icons.photo_camera_outlined),
                              label: const Text('Camera'),
                            ),
                          ),
                        ],
                      ),
                      if (_selectedImage != null) ...<Widget>[
                        const SizedBox(height: 12),
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 280),
                          transitionBuilder:
                              (Widget child, Animation<double> animation) {
                                return FadeTransition(
                                  opacity: animation,
                                  child: ScaleTransition(
                                    scale: Tween<double>(
                                      begin: 0.96,
                                      end: 1,
                                    ).animate(animation),
                                    child: child,
                                  ),
                                );
                              },
                          child: ClipRRect(
                            key: ValueKey<String>(_selectedImage!.path),
                            borderRadius: BorderRadius.circular(14),
                            child: Image.memory(
                              _selectedImageBytes!,
                              width: double.infinity,
                              height: 230,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _isPredicting ? null : _predict,
                          icon: _isPredicting
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.analytics_outlined),
                          label: Text(
                            _isPredicting ? 'Analyzing...' : 'Predict Disease',
                          ),
                        ),
                      ),
                      if (_isPredicting) ...<Widget>[
                        const SizedBox(height: 8),
                        Text(_predictingStage),
                        const SizedBox(height: 8),
                        const LinearProgressIndicator(minHeight: 6),
                      ],
                      if (_error != null) ...<Widget>[
                        const SizedBox(height: 10),
                        Text(
                          _error!,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.error,
                          ),
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: _isPredicting ? null : _predict,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Retry'),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 320),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeIn,
                transitionBuilder: (Widget child, Animation<double> animation) {
                  return FadeTransition(
                    opacity: animation,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.08),
                        end: Offset.zero,
                      ).animate(animation),
                      child: child,
                    ),
                  );
                },
                child: _result == null
                    ? const SizedBox.shrink(key: ValueKey<String>('noResult'))
                    : _ResultCard(
                        key: ValueKey<int>(_result!.historyId),
                        response: _result!,
                        imageBytes: _selectedImageBytes,
                      ),
              ),
              const SizedBox(height: 10),
              Text(
                'Medical disclaimer: This app supports decision-making and does not replace diagnosis by a licensed ophthalmologist.',
                style: TextStyle(
                  fontSize: 12,
                  color: const Color(0xFF355070).withValues(alpha: 0.9),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HistoryView extends StatefulWidget {
  const HistoryView({
    super.key,
    required this.apiClient,
    required this.refreshSeed,
  });

  final ApiClient apiClient;
  final int refreshSeed;

  @override
  State<HistoryView> createState() => _HistoryViewState();
}

class _HistoryViewState extends State<HistoryView> {
  bool _isLoading = true;
  String? _error;
  List<HistoryItem> _items = <HistoryItem>[];
  String _query = '';
  String _selectedClass = 'All';
  DateTimeRange? _selectedRange;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void didUpdateWidget(covariant HistoryView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshSeed != oldWidget.refreshSeed) {
      _loadHistory();
    }
  }

  Future<void> _loadHistory() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final items = await widget.apiClient.fetchHistory(limit: 100);
      if (!mounted) {
        return;
      }
      setState(() {
        _items = items;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String _formatDate(String value) {
    final parsed = DateTime.tryParse(value);
    if (parsed == null) {
      return value;
    }
    return formatLocalDateTime(parsed);
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final initial =
        _selectedRange ??
        DateTimeRange(start: now.subtract(const Duration(days: 30)), end: now);
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 2),
      initialDateRange: initial,
    );
    if (picked == null) {
      return;
    }
    setState(() {
      _selectedRange = picked;
    });
  }

  List<HistoryItem> _filteredItems() {
    return _items.where((HistoryItem item) {
      final matchesClass =
          _selectedClass == 'All' ||
          item.predictionLabel.toUpperCase() == _selectedClass;
      final query = _query.trim().toLowerCase();
      final matchesQuery =
          query.isEmpty ||
          item.imageName.toLowerCase().contains(query) ||
          item.predictionLabel.toLowerCase().contains(query);

      bool matchesDate = true;
      final parsed = DateTime.tryParse(item.createdAt);
      if (_selectedRange != null && parsed != null) {
        final localDate = parsed.toLocal();
        final start = DateTime(
          _selectedRange!.start.year,
          _selectedRange!.start.month,
          _selectedRange!.start.day,
        );
        final end = DateTime(
          _selectedRange!.end.year,
          _selectedRange!.end.month,
          _selectedRange!.end.day,
          23,
          59,
          59,
        );
        matchesDate = !localDate.isBefore(start) && !localDate.isAfter(end);
      }

      return matchesClass && matchesQuery && matchesDate;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    final filteredItems = _filteredItems();

    return RefreshIndicator(
      onRefresh: _loadHistory,
      child: _items.isEmpty
          ? ListView(
              padding: const EdgeInsets.all(18),
              children: <Widget>[
                const SizedBox(height: 120),
                _AnimatedEmptyStateCard(
                  icon: Icons.history,
                  title: 'No History Yet',
                  message:
                      _error ??
                      'No prediction history yet. Run your first diagnosis.',
                ),
              ],
            )
          : ListView(
              padding: const EdgeInsets.all(14),
              children: <Widget>[
                TextField(
                  onChanged: (String value) {
                    setState(() {
                      _query = value;
                    });
                  },
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    labelText: 'Search by image or class',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        initialValue: _selectedClass,
                        decoration: const InputDecoration(
                          labelText: 'Class',
                          border: OutlineInputBorder(),
                        ),
                        items:
                            const <String>[
                                  'All',
                                  'CNV',
                                  'DME',
                                  'DRUSEN',
                                  'NORMAL',
                                ]
                                .map(
                                  (String value) => DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  ),
                                )
                                .toList(),
                        onChanged: (String? value) {
                          if (value == null) {
                            return;
                          }
                          setState(() {
                            _selectedClass = value;
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _pickDateRange,
                        icon: const Icon(Icons.date_range),
                        label: Text(
                          _selectedRange == null
                              ? 'Date Range'
                              : '${_selectedRange!.start.month}/${_selectedRange!.start.day} - ${_selectedRange!.end.month}/${_selectedRange!.end.day}',
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                if (_selectedRange != null)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () {
                        setState(() {
                          _selectedRange = null;
                        });
                      },
                      icon: const Icon(Icons.clear),
                      label: const Text('Clear date filter'),
                    ),
                  ),
                if (filteredItems.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(
                      child: Text('No history matches your filters.'),
                    ),
                  )
                else
                  ...filteredItems.asMap().entries.map((entry) {
                    final index = entry.key;
                    final item = entry.value;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: TweenAnimationBuilder<double>(
                        tween: Tween<double>(begin: 0.92, end: 1),
                        duration: Duration(milliseconds: 240 + (index * 70)),
                        curve: Curves.easeOutCubic,
                        builder:
                            (
                              BuildContext context,
                              double value,
                              Widget? child,
                            ) {
                              return Transform.translate(
                                offset: Offset(0, (1 - value) * 26),
                                child: Opacity(
                                  opacity: value.clamp(0, 1),
                                  child: child,
                                ),
                              );
                            },
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Text(
                                        item.predictionLabel,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(
                                          0xFFDDF2F4,
                                        ).withValues(alpha: 0.9),
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      child: Text(
                                        '${(item.confidence * 100).toStringAsFixed(1)}%',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text('Image: ${item.imageName}'),
                                const SizedBox(height: 3),
                                Text('Date: ${_formatDate(item.createdAt)}'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({
    super.key,
    required this.response,
    required this.imageBytes,
  });

  final PredictionResponse response;
  final Uint8List? imageBytes;

  List<String> _followUpChecklist(String rawLabel, int months) {
    final label = rawLabel.toUpperCase();

    if (label == 'CNV') {
      switch (months) {
        case 1:
          return <String>[
            'Review urgent symptoms: distortion, central blur, dark spot, flashes or floaters.',
            'Repeat OCT and compare subretinal or intraretinal fluid from baseline.',
            'Check visual acuity and treatment response after recent therapy.',
            'Confirm anti-VEGF schedule and next retina specialist visit date.',
          ];
        case 3:
          return <String>[
            'Repeat OCT and visual acuity for response trend: improved, stable, or worsening.',
            'Assess recurrence risk and need for continuing anti-VEGF interval.',
            'Review adherence to specialist plan and emergency warning signs.',
            'Adjust follow-up frequency based on OCT activity and symptom burden.',
          ];
        case 6:
          return <String>[
            'Comprehensive retina reassessment with OCT progression review.',
            'Check long-term treatment burden and recurrence profile.',
            'Update maintenance strategy with retina specialist guidance.',
            'Define next follow-up interval, often sooner if active CNV persists.',
          ];
      }
    }

    if (label == 'DME') {
      switch (months) {
        case 1:
          return <String>[
            'Review visual symptoms and any sudden reduction in central vision.',
            'Repeat OCT for retinal thickness and fluid response.',
            'Check blood sugar and blood pressure control status.',
            'Confirm retina and diabetes care plan with medication adherence.',
          ];
        case 3:
          return <String>[
            'Compare OCT trend and visual acuity with month-1 follow-up.',
            'Reassess edema activity and response to anti-VEGF or steroid strategy.',
            'Review HbA1c and systemic risk factors impacting macular edema.',
            'Decide continuation or escalation plan with specialist input.',
          ];
        case 6:
          return <String>[
            'Perform long-term edema stability review with OCT and vision testing.',
            'Document recurrence risk and treatment interval sustainability.',
            'Reinforce diabetes, blood pressure, and lifestyle control goals.',
            'Set next retina follow-up timing based on disease stability.',
          ];
      }
    }

    if (label == 'DRUSEN') {
      switch (months) {
        case 1:
          return <String>[
            'Screen for new distortion, central blur, or dark spots using symptom check.',
            'Establish baseline monitoring with OCT and visual acuity as advised.',
            'Discuss smoking cessation, UV protection, and antioxidant-rich diet.',
            'Start home monitoring habit, such as Amsler grid checks.',
          ];
        case 3:
          return <String>[
            'Re-evaluate symptoms and compare visual function against baseline.',
            'Repeat OCT if clinically advised to check early progression signs.',
            'Review nutrition and preventive habit adherence.',
            'Confirm whether AREDS2 is appropriate with ophthalmologist guidance.',
          ];
        case 6:
          return <String>[
            'Perform stability review for drusen burden and visual function.',
            'Repeat OCT and retinal exam as recommended for AMD surveillance.',
            'Update prevention plan and reinforce red-flag symptom awareness.',
            'Set next review interval, typically 6 to 12 months if stable.',
          ];
      }
    }

    switch (months) {
      case 1:
        return <String>[
          'Check for any new visual symptoms since last assessment.',
          'Review visual acuity and basic retinal status when needed.',
          'Reinforce preventive habits: sleep, hydration, nutrition, and UV protection.',
          'Escalate early if symptoms develop before next planned visit.',
        ];
      case 3:
        return <String>[
          'Perform routine symptom and visual function review.',
          'Confirm stable retinal status and absence of warning signs.',
          'Continue healthy lifestyle and risk-factor control practices.',
          'Adjust next follow-up timing if any new symptoms appear.',
        ];
      case 6:
        return <String>[
          'Conduct periodic retina check to confirm continued normal findings.',
          'Review long-term eye health habits and screen-time hygiene.',
          'Reinforce early reporting if blur, distortion, or blind spots occur.',
          'Plan next routine check according to clinician advice.',
        ];
      default:
        return <String>[
          'Follow specialist advice for personalized retinal follow-up.',
        ];
    }
  }

  Future<void> _showFollowUpPlan(BuildContext context, int months) async {
    final diseaseLabel = response.predictionLabel.toUpperCase();
    final points = _followUpChecklist(diseaseLabel, months);

    await showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('$months-month follow-up: $diseaseLabel'),
          content: SizedBox(
            width: 420,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text(
                    'Clinical checklist',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  ...points.map(
                    (String point) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text('• '),
                          Expanded(child: Text(point)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: <Widget>[
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _exportPdf(BuildContext context) async {
    final pdf = pw.Document();
    pw.MemoryImage? memoryImage;

    final diagnoseDate =
        DateTime.tryParse(response.savedAt)?.toLocal() ?? DateTime.now();
    final generatedAt = formatLocalDateTime(DateTime.now());
    final diagnoseDateLabel = formatLocalDateTime(diagnoseDate);
    final reportId =
        'VD-${formatReportDate(diagnoseDate).replaceAll('-', '')}-${response.historyId}';
    final confidencePct = (response.confidence * 100).toStringAsFixed(1);
    final tier = getConfidenceTier(response.confidence);
    final tierLabel = switch (tier) {
      ConfidenceTier.high => 'High confidence',
      ConfidenceTier.moderate => 'Moderate confidence',
      ConfidenceTier.low => 'Low confidence — specialist review advised',
    };
    final diseaseLabel = response.predictionLabel.toUpperCase();
    final filename =
        buildClinicalReportFilename(response.predictionLabel, diagnoseDate);

    if (imageBytes != null) {
      memoryImage = pw.MemoryImage(imageBytes!);
    }

    pdf.addPage(
      pw.Page(
        pageTheme: pw.PageTheme(
          margin: const pw.EdgeInsets.fromLTRB(36, 34, 36, 34),
          theme: pw.ThemeData.withFont(
            base: pw.Font.helvetica(),
            bold: pw.Font.helveticaBold(),
          ),
        ),
        build: (pw.Context context) {
          pw.TextStyle h1 = pw.TextStyle(
            fontSize: 18,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.black,
          );
          pw.TextStyle label = pw.TextStyle(
            fontSize: 9,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.black,
          );
          pw.TextStyle value = const pw.TextStyle(
            fontSize: 10,
            color: PdfColors.black,
          );
          pw.TextStyle small = const pw.TextStyle(
            fontSize: 8.5,
            color: PdfColors.black,
          );

          pw.Widget kv(String k, String v) {
            return pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 4),
              child: pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: <pw.Widget>[
                  pw.SizedBox(
                    width: 120,
                    child: pw.Text(k, style: label),
                  ),
                  pw.Expanded(child: pw.Text(v, style: value)),
                ],
              ),
            );
          }

          final probabilityRows = response.classProbabilities.entries.toList()
            ..sort((a, b) => b.value.compareTo(a.value));
          final top3 = probabilityRows.take(3).toList();

          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: <pw.Widget>[
              pw.Text('VisDect Clinical Report', style: h1),
              pw.SizedBox(height: 6),
              kv('Report ID', reportId),
              kv('Diagnosis date', diagnoseDateLabel),
              kv('Generated', generatedAt),
              kv('Record #', '${response.historyId}'),
              kv('Modality', 'OCT Fundus Scan'),
              pw.SizedBox(height: 10),
              kv('Primary finding', diseaseLabel),
              kv('Model confidence', '$confidencePct% ($tierLabel)'),
              pw.SizedBox(height: 10),
              pw.Text('Recommendation', style: label),
              pw.SizedBox(height: 4),
              pw.Text(response.recommendationTitle, style: value),
              pw.SizedBox(height: 6),
              ...response.recommendationPoints.take(4).map(
                (point) => pw.Padding(
                  padding: const pw.EdgeInsets.only(bottom: 3),
                  child: pw.Text('- $point', style: value),
                ),
              ),
              pw.SizedBox(height: 10),
              pw.Text('Top probabilities', style: label),
              pw.SizedBox(height: 4),
              ...top3.map(
                (entry) => pw.Padding(
                  padding: const pw.EdgeInsets.only(bottom: 2),
                  child: pw.Text(
                    '${entry.key.toUpperCase()}: ${(entry.value * 100).toStringAsFixed(1)}%',
                    style: value,
                  ),
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Text('Submitted eye image', style: label),
              pw.SizedBox(height: 6),
              if (memoryImage != null)
                pw.Center(
                  child: pw.Image(
                    memoryImage,
                    height: 260,
                    fit: pw.BoxFit.contain,
                  ),
                )
              else
                pw.Text('No image provided.', style: value),
              pw.Spacer(),
              pw.Text(
                'AI-generated decision-support document. Not a medical diagnosis. Confirm with a licensed ophthalmologist.',
                style: small,
              ),
            ],
          );
        },
      ),
    );

    final shareOrigin = _shareOriginForContext(context);

    try {
      final pdfBytes = await pdf.save();
      final documentsDir = await getApplicationDocumentsDirectory();
      final reportsDir = Directory(
        '${documentsDir.path}${Platform.pathSeparator}VisDect Reports',
      );
      await reportsDir.create(recursive: true);

      final reportPath =
          '${reportsDir.path}${Platform.pathSeparator}$filename';
      final reportFile = File(reportPath);
      await reportFile.writeAsBytes(pdfBytes, flush: true);

      final normalizedPath = reportFile.path.replaceAll('/', r'\');
      final pdfFile = XFile(
        normalizedPath,
        mimeType: 'application/pdf',
        name: filename,
      );

      // Do not pass ShareParams.text — WhatsApp/desktop share often sends only
      // the text and drops the PDF attachment when both are provided.
      await SharePlus.instance.share(
        ShareParams(
          files: <XFile>[pdfFile],
          fileNameOverrides: <String>[filename],
          title: '$diseaseLabel Clinical Report — ${formatReportDate(diagnoseDate)}',
          sharePositionOrigin: shareOrigin,
        ),
      );

      if (!context.mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('PDF ready: $filename\nSaved in VisDect Reports'),
        ),
      );
    } catch (error) {
      if (!context.mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not share PDF: $error')),
      );
    }
  }

  Color _tierColor(ConfidenceTier tier) {
    switch (tier) {
      case ConfidenceTier.high:
        return const Color(0xFF2E7D32);
      case ConfidenceTier.moderate:
        return const Color(0xFFEF6C00);
      case ConfidenceTier.low:
        return const Color(0xFFC62828);
    }
  }

  String _tierLabel(ConfidenceTier tier) {
    switch (tier) {
      case ConfidenceTier.high:
        return 'High confidence';
      case ConfidenceTier.moderate:
        return 'Moderate confidence';
      case ConfidenceTier.low:
        return 'Low confidence';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tier = getConfidenceTier(response.confidence);
    final probabilityEntries = response.classProbabilities.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[Color(0xFFFFFFFF), Color(0xFFF7FCFD)],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              blurRadius: 28,
              offset: const Offset(0, 10),
              color: Colors.teal.withValues(alpha: 0.12),
            ),
          ],
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    'Prediction: ${response.predictionLabel}',
                    style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => _exportPdf(context),
                  tooltip: 'Share PDF report',
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                Chip(
                  avatar: Icon(Icons.shield_outlined, color: _tierColor(tier)),
                  label: Text(_tierLabel(tier)),
                ),
                Chip(
                  label: Text(
                    'Confidence ${(response.confidence * 100).toStringAsFixed(2)}%',
                  ),
                ),
              ],
            ),
            if (tier == ConfidenceTier.low) ...<Widget>[
              const SizedBox(height: 8),
              Text(
                'Low-confidence prediction. Please confirm with specialist review before making decisions.',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                OutlinedButton.icon(
                  onPressed: () => _showFollowUpPlan(context, 1),
                  icon: const Icon(Icons.event_repeat),
                  label: const Text('1 month follow-up'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _showFollowUpPlan(context, 3),
                  icon: const Icon(Icons.event_repeat),
                  label: const Text('3 months follow-up'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _showFollowUpPlan(context, 6),
                  icon: const Icon(Icons.event_repeat),
                  label: const Text('6 months follow-up'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Saved at: ${formatLocalDateTime(DateTime.tryParse(response.savedAt) ?? DateTime.now())}',
              style: TextStyle(color: Colors.black.withValues(alpha: 0.62)),
            ),
            const Divider(height: 24),
            const Text(
              'Class Probabilities',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            ...probabilityEntries.asMap().entries.map((entryWithIndex) {
              final index = entryWithIndex.key;
              final entry = entryWithIndex.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '${entry.key}: ${(entry.value * 100).toStringAsFixed(1)}%',
                    ),
                    const SizedBox(height: 4),
                    TweenAnimationBuilder<double>(
                      tween: Tween<double>(
                        begin: 0,
                        end: entry.value.clamp(0, 1),
                      ),
                      duration: Duration(milliseconds: 420 + (index * 130)),
                      curve: Curves.easeOutCubic,
                      builder:
                          (
                            BuildContext context,
                            double animatedValue,
                            Widget? child,
                          ) {
                            return LinearProgressIndicator(
                              value: animatedValue,
                              minHeight: 8,
                              borderRadius: BorderRadius.circular(7),
                            );
                          },
                    ),
                  ],
                ),
              );
            }),
            const Divider(height: 24),
            Text(
              response.recommendationTitle,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            ...response.recommendationPoints.map(
              (String point) => Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text('• '),
                    Expanded(child: Text(point)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FollowUpReminder {
  FollowUpReminder({
    required this.id,
    required this.title,
    required this.note,
    required this.scheduledAt,
    required this.createdAt,
  });

  factory FollowUpReminder.fromJson(Map<String, dynamic> json) {
    return FollowUpReminder(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? 'Follow-up reminder',
      note: json['note'] as String? ?? '',
      scheduledAt:
          DateTime.tryParse(json['scheduled_at'] as String? ?? '') ??
          DateTime.now(),
      createdAt:
          DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  final String id;
  final String title;
  final String note;
  final DateTime scheduledAt;
  final DateTime createdAt;

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'note': note,
      'scheduled_at': scheduledAt.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }
}

class ReminderRepository {
  static const String _storageKey = 'follow_up_reminders';

  static Future<List<FollowUpReminder>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      return <FollowUpReminder>[];
    }

    final decoded = jsonDecode(raw) as List<dynamic>;
    final reminders = decoded
        .map(
          (dynamic item) => FollowUpReminder.fromJson(
            (item as Map<String, dynamic>?) ?? <String, dynamic>{},
          ),
        )
        .toList();

    reminders.sort(
      (FollowUpReminder a, FollowUpReminder b) =>
          a.scheduledAt.compareTo(b.scheduledAt),
    );
    return reminders;
  }

  static Future<void> save(List<FollowUpReminder> reminders) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(
      reminders.map((FollowUpReminder r) => r.toJson()).toList(),
    );
    await prefs.setString(_storageKey, encoded);
  }

  static Future<void> add(FollowUpReminder reminder) async {
    final reminders = await load();
    reminders.add(reminder);
    await save(reminders);
  }

  static Future<void> remove(String reminderId) async {
    final reminders = await load();
    reminders.removeWhere(
      (FollowUpReminder reminder) => reminder.id == reminderId,
    );
    await save(reminders);
  }
}

class ReminderNotificationService {
  ReminderNotificationService._();

  static final ReminderNotificationService instance =
      ReminderNotificationService._();
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) {
      return;
    }

    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );
    const initSettings = InitializationSettings(android: androidSettings);
    await _plugin.initialize(initSettings);

    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    await androidPlugin?.requestNotificationsPermission();

    _initialized = true;
  }

  Future<void> schedule(FollowUpReminder reminder) async {
    await initialize();

    const androidDetails = AndroidNotificationDetails(
      'retina_scout_followup',
      'Retina follow-up reminders',
      channelDescription: 'Reminders for follow-up retinal checkups',
      importance: Importance.max,
      priority: Priority.high,
    );

    // Use immediate notification if scheduled time has already passed.
    if (reminder.scheduledAt.isBefore(DateTime.now())) {
      await _plugin.show(
        reminder.id.hashCode & 0x7fffffff,
        reminder.title,
        reminder.note,
        const NotificationDetails(android: androidDetails),
      );
      return;
    }

    await _plugin.zonedSchedule(
      reminder.id.hashCode & 0x7fffffff,
      reminder.title,
      '${reminder.note} at ${formatLocalDateTime(reminder.scheduledAt)}',
      _dateTimeToTz(reminder.scheduledAt),
      const NotificationDetails(android: androidDetails),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  tz.TZDateTime _dateTimeToTz(DateTime dateTime) {
    tz.initializeTimeZones();
    return tz.TZDateTime.from(dateTime, tz.local);
  }

  Future<void> cancel(String reminderId) async {
    await _plugin.cancel(reminderId.hashCode & 0x7fffffff);
  }
}

class ReminderView extends StatefulWidget {
  const ReminderView({super.key});

  @override
  State<ReminderView> createState() => _ReminderViewState();
}

class _ReminderViewState extends State<ReminderView> {
  bool _isLoading = true;
  List<FollowUpReminder> _reminders = <FollowUpReminder>[];

  @override
  void initState() {
    super.initState();
    _loadReminders();
  }

  Future<void> _loadReminders() async {
    final reminders = await ReminderRepository.load();
    if (!mounted) {
      return;
    }
    setState(() {
      _reminders = reminders;
      _isLoading = false;
    });
  }

  Future<void> _addReminder() async {
    final noteController = TextEditingController();
    final now = DateTime.now();
    DateTime pickedDate = now.add(const Duration(days: 30));
    TimeOfDay pickedTime = const TimeOfDay(hour: 9, minute: 0);

    final created = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setLocalState) {
            return AlertDialog(
              title: const Text('Add follow-up reminder'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextField(
                    controller: noteController,
                    decoration: const InputDecoration(
                      labelText: 'Reminder note',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final date = await showDatePicker(
                        context: context,
                        firstDate: now,
                        lastDate: DateTime(now.year + 2),
                        initialDate: pickedDate,
                      );
                      if (date == null) {
                        return;
                      }
                      setLocalState(() {
                        pickedDate = date;
                      });
                    },
                    icon: const Icon(Icons.date_range),
                    label: Text(
                      'Date: ${pickedDate.month}/${pickedDate.day}/${pickedDate.year}',
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: pickedTime,
                      );
                      if (time == null) {
                        return;
                      }
                      setLocalState(() {
                        pickedTime = time;
                      });
                    },
                    icon: const Icon(Icons.access_time),
                    label: Text(
                      'Time: ${pickedTime.hour.toString().padLeft(2, '0')}:${pickedTime.minute.toString().padLeft(2, '0')}',
                    ),
                  ),
                ],
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    if (created != true) {
      return;
    }

    final scheduledAt = DateTime(
      pickedDate.year,
      pickedDate.month,
      pickedDate.day,
      pickedTime.hour,
      pickedTime.minute,
    );
    final reminder = FollowUpReminder(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: 'Retina checkup reminder',
      note: noteController.text.trim().isEmpty
          ? 'Time for your retinal follow-up check.'
          : noteController.text.trim(),
      scheduledAt: scheduledAt,
      createdAt: DateTime.now(),
    );

    await ReminderRepository.add(reminder);
    await ReminderNotificationService.instance.schedule(reminder);
    await _loadReminders();
  }

  Future<void> _removeReminder(FollowUpReminder reminder) async {
    await ReminderRepository.remove(reminder.id);
    await ReminderNotificationService.instance.cancel(reminder.id);
    await _loadReminders();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _loadReminders,
        child: _reminders.isEmpty
            ? ListView(
                padding: const EdgeInsets.all(18),
                children: <Widget>[
                  const SizedBox(height: 120),
                  const _AnimatedEmptyStateCard(
                    icon: Icons.notifications_none,
                    title: 'No Reminders Yet',
                    message:
                        'Create follow-up reminders to track retinal care on schedule.',
                  ),
                ],
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: _reminders.length,
                separatorBuilder: (_, int index) => const SizedBox(height: 10),
                itemBuilder: (BuildContext context, int index) {
                  final reminder = _reminders[index];
                  return TweenAnimationBuilder<double>(
                    tween: Tween<double>(begin: 0.9, end: 1),
                    duration: Duration(milliseconds: 260 + (index * 80)),
                    curve: Curves.easeOutCubic,
                    builder:
                        (BuildContext context, double value, Widget? child) {
                          return Transform.translate(
                            offset: Offset(0, (1 - value) * 24),
                            child: Opacity(
                              opacity: value.clamp(0, 1),
                              child: child,
                            ),
                          );
                        },
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.event_note_outlined),
                        title: Text(reminder.title),
                        subtitle: Text(
                          '${reminder.note}\n${formatLocalDateTime(reminder.scheduledAt)}',
                        ),
                        isThreeLine: true,
                        trailing: IconButton(
                          onPressed: () => _removeReminder(reminder),
                          icon: const Icon(Icons.delete_outline),
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addReminder,
        icon: const Icon(Icons.add_alert_outlined),
        label: const Text('Add Reminder'),
      ),
    );
  }
}

class _AnimatedEmptyStateCard extends StatelessWidget {
  const _AnimatedEmptyStateCard({
    required this.icon,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.9, end: 1),
      duration: const Duration(milliseconds: 580),
      curve: Curves.easeOutCubic,
      builder: (BuildContext context, double value, Widget? child) {
        return Transform.translate(
          offset: Offset(0, (1 - value) * 24),
          child: Opacity(opacity: value.clamp(0, 1), child: child),
        );
      },
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: <Widget>[
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0.96, end: 1),
                duration: const Duration(milliseconds: 880),
                curve: Curves.easeOutBack,
                builder: (BuildContext context, double value, Widget? child) {
                  return Transform.scale(scale: value, child: child);
                },
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFE3F2F6),
                    border: Border.all(
                      color: const Color(0xFF0E7490).withValues(alpha: 0.16),
                    ),
                  ),
                  child: Icon(icon, size: 36, color: const Color(0xFF0E7490)),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: GoogleFonts.spaceGrotesk(
                  fontSize: 21,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

class PredictionResponse {
  PredictionResponse({
    required this.historyId,
    required this.predictionLabel,
    required this.confidence,
    required this.classProbabilities,
    required this.recommendationTitle,
    required this.recommendationPoints,
    required this.savedAt,
  });

  factory PredictionResponse.fromJson(Map<String, dynamic> json) {
    final rawProbabilities =
        (json['class_probabilities'] as Map<String, dynamic>?) ??
        <String, dynamic>{};

    return PredictionResponse(
      historyId: (json['history_id'] as num?)?.toInt() ?? 0,
      predictionLabel: json['prediction_label'] as String? ?? 'Unknown',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0,
      classProbabilities: rawProbabilities.map(
        (String key, dynamic value) =>
            MapEntry(key, (value as num?)?.toDouble() ?? 0),
      ),
      recommendationTitle:
          json['recommendation_title'] as String? ?? 'Recommendation',
      recommendationPoints:
          ((json['recommendation_points'] as List<dynamic>?) ?? <dynamic>[])
              .map((dynamic point) => point.toString())
              .toList(),
      savedAt: json['saved_at'] as String? ?? '',
    );
  }

  final int historyId;
  final String predictionLabel;
  final double confidence;
  final Map<String, double> classProbabilities;
  final String recommendationTitle;
  final List<String> recommendationPoints;
  final String savedAt;
}

class HistoryItem {
  HistoryItem({
    required this.id,
    required this.imageName,
    required this.predictionLabel,
    required this.confidence,
    required this.createdAt,
  });

  factory HistoryItem.fromJson(Map<String, dynamic> json) {
    return HistoryItem(
      id: (json['id'] as num?)?.toInt() ?? 0,
      imageName: json['image_name'] as String? ?? 'Unknown image',
      predictionLabel: json['prediction_label'] as String? ?? 'Unknown',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0,
      createdAt: json['created_at'] as String? ?? '',
    );
  }

  final int id;
  final String imageName;
  final String predictionLabel;
  final double confidence;
  final String createdAt;
}

class UserProfile {
  UserProfile({required this.id, required this.fullName, required this.email});

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: (json['id'] as num?)?.toInt() ?? 0,
      fullName: json['full_name'] as String? ?? 'User',
      email: json['email'] as String? ?? '',
    );
  }

  final int id;
  final String fullName;
  final String email;
}

class AuthResponse {
  AuthResponse({
    required this.accessToken,
    required this.expiresIn,
    required this.user,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    return AuthResponse(
      accessToken: json['access_token'] as String? ?? '',
      expiresIn: (json['expires_in'] as num?)?.toInt() ?? 0,
      user: UserProfile.fromJson(
        (json['user'] as Map<String, dynamic>?) ?? <String, dynamic>{},
      ),
    );
  }

  final String accessToken;
  final int expiresIn;
  final UserProfile user;
}

class AuthSession {
  AuthSession({required this.token, required this.user});

  final String token;
  final UserProfile user;
}

class ApiException implements Exception {
  ApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class ApiClient {
  ApiClient({required this.baseUrl, this.token});

  final String baseUrl;
  final String? token;
  static const Duration _requestTimeout = Duration(seconds: 25);

  String get _normalizedBaseUrl {
    return baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
  }

  Uri _uri(String path) {
    return Uri.parse('$_normalizedBaseUrl$path');
  }

  String _extractError(String rawBody) {
    try {
      final decoded = jsonDecode(rawBody) as Map<String, dynamic>;
      final detail = decoded['detail'];
      if (detail is String && detail.isNotEmpty) {
        return detail;
      }
      return rawBody;
    } catch (_) {
      return rawBody;
    }
  }

  Map<String, String> _authHeaders() {
    final accessToken = token;
    if (accessToken == null || accessToken.isEmpty) {
      throw ApiException('You are not logged in. Please sign in again.');
    }
    return <String, String>{
      'Authorization': 'Bearer $accessToken',
      'Content-Type': 'application/json',
    };
  }

  Future<T> _runSafe<T>(Future<T> Function() action) async {
    try {
      return await action();
    } on TimeoutException {
      throw ApiException(
        'Request timed out. Check your connection and backend URL, then retry.',
      );
    } on http.ClientException {
      throw ApiException(
        'Network error while contacting backend. Please retry.',
      );
    }
  }

  Future<AuthResponse> register({
    required String fullName,
    required String email,
    required String password,
  }) async {
    return _runSafe(() async {
      final response = await http
          .post(
            _uri('/auth/register'),
            headers: <String, String>{'Content-Type': 'application/json'},
            body: jsonEncode(<String, String>{
              'full_name': fullName,
              'email': email,
              'password': password,
            }),
          )
          .timeout(_requestTimeout);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw ApiException(_extractError(response.body));
      }

      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      return AuthResponse.fromJson(decoded);
    });
  }

  Future<AuthResponse> login({
    required String email,
    required String password,
  }) async {
    return _runSafe(() async {
      final response = await http
          .post(
            _uri('/auth/login'),
            headers: <String, String>{'Content-Type': 'application/json'},
            body: jsonEncode(<String, String>{
              'email': email,
              'password': password,
            }),
          )
          .timeout(_requestTimeout);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw ApiException(_extractError(response.body));
      }

      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      return AuthResponse.fromJson(decoded);
    });
  }

  Future<UserProfile> getMe() async {
    return _runSafe(() async {
      final response = await http
          .get(_uri('/me'), headers: _authHeaders())
          .timeout(_requestTimeout);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw ApiException(_extractError(response.body));
      }

      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      return UserProfile.fromJson(
        (decoded['user'] as Map<String, dynamic>?) ?? <String, dynamic>{},
      );
    });
  }

  Future<PredictionResponse> predictImage({
    required Uint8List imageBytes,
    required String fileName,
  }) async {
    return _runSafe(() async {
      final request = http.MultipartRequest('POST', _uri('/predict'))
        ..headers.addAll(_authHeaders())
        ..files.add(
          http.MultipartFile.fromBytes('file', imageBytes, filename: fileName),
        );

      final streamed = await request.send().timeout(_requestTimeout);
      final body = await streamed.stream.bytesToString().timeout(
        _requestTimeout,
      );

      if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
        throw ApiException(_extractError(body));
      }

      final decoded = jsonDecode(body) as Map<String, dynamic>;
      return PredictionResponse.fromJson(decoded);
    });
  }

  Future<List<HistoryItem>> fetchHistory({int limit = 50}) async {
    return _runSafe(() async {
      final response = await http
          .get(_uri('/history?limit=$limit'), headers: _authHeaders())
          .timeout(_requestTimeout);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw ApiException(_extractError(response.body));
      }

      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      final rawItems = (decoded['items'] as List<dynamic>?) ?? <dynamic>[];

      return rawItems
          .map(
            (dynamic item) => HistoryItem.fromJson(
              (item as Map<String, dynamic>?) ?? <String, dynamic>{},
            ),
          )
          .toList();
    });
  }
}
