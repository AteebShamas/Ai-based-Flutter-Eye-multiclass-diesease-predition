import 'dart:html' as html;
import 'dart:ui_web' as ui;

import 'package:flutter/material.dart';

class WalleModelViewerWebContainer extends StatefulWidget {
  const WalleModelViewerWebContainer({super.key, required this.modelSource});

  final String modelSource;

  @override
  State<WalleModelViewerWebContainer> createState() =>
      _WalleModelViewerWebContainerState();
}

class _WalleModelViewerWebContainerState
    extends State<WalleModelViewerWebContainer> {
  static const String _viewType = 'walle-model-viewer-iframe';
  static bool _viewFactoryRegistered = false;

  @override
  void initState() {
    super.initState();
    _registerViewFactory();
  }

  void _registerViewFactory() {
    if (_viewFactoryRegistered) {
      return;
    }

    ui.platformViewRegistry.registerViewFactory(_viewType, (int viewId) {
      final iframe = html.IFrameElement()
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.display = 'block'
        ..allow = 'autoplay; fullscreen; xr-spatial-tracking'
        ..srcdoc = _buildHtml(widget.modelSource);
      return iframe;
    });

    _viewFactoryRegistered = true;
  }

  String _buildHtml(String modelSource) {
    final modelUrl = _resolveWebModelSource(modelSource);
    final modelLabel = modelSource.trim().isEmpty ? 'Robot' : modelSource;
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
  <base href="/" />
  <style>
    html, body {
      margin: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background:
        radial-gradient(circle at 50% 20%, rgba(14, 116, 144, 0.28), transparent 38%),
        linear-gradient(135deg, #0f172a 0%, #111827 45%, #1f2937 100%);
      font-family: Inter, system-ui, sans-serif;
      color: #e2e8f0;
    }
    .stage {
      position: relative;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      padding: 18px;
    }
    .glow {
      position: absolute;
      inset: 14px;
      border-radius: 28px;
      border: 1px solid rgba(125, 211, 252, 0.16);
      box-shadow: inset 0 0 44px rgba(56, 189, 248, 0.08);
      pointer-events: none;
    }
    model-viewer {
      width: 100%;
      height: 100%;
      min-height: 260px;
      --poster-color: transparent;
      background: transparent;
    }
    .hud {
      position: absolute;
      left: 20px;
      right: 20px;
      bottom: 18px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      pointer-events: none;
    }
    .tag {
      padding: 8px 12px;
      border-radius: 999px;
      background: rgba(15, 23, 42, 0.72);
      border: 1px solid rgba(148, 163, 184, 0.24);
      backdrop-filter: blur(10px);
      font-size: 11px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    .status {
      padding: 8px 12px;
      border-radius: 999px;
      background: rgba(14, 116, 144, 0.16);
      border: 1px solid rgba(45, 212, 191, 0.28);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
  </style>
  <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
</head>
<body>
  <div class="stage">
    <div class="glow"></div>
    <model-viewer
      id="viewer"
      src="$modelUrl"
      camera-controls
      auto-rotate
      interaction-prompt="none"
      shadow-intensity="1"
      exposure="1.05"
      camera-orbit="35deg 70deg 2.6m"
      field-of-view="25deg"
      environment-image="neutral"
      loading="eager"
      ar="true">
    </model-viewer>
    <div class="hud">
      <div class="tag">$modelLabel</div>
      <div class="status">ready</div>
    </div>
  </div>
</body>
</html>
''';
  }

  String _resolveWebModelSource(String modelSource) {
    final trimmed = modelSource.trim();
    if (trimmed.isEmpty) {
      return '/3d%20model/sci-fi_humanoid_robot.glb';
    }

    final uri = Uri.tryParse(trimmed);
    if (uri != null && uri.hasScheme) {
      return trimmed;
    }

    if (trimmed.startsWith('/assets/')) {
      return trimmed.replaceAll(' ', '%20');
    }

    return '/${Uri.encodeFull(trimmed)}';
  }

  @override
  Widget build(BuildContext context) {
    return HtmlElementView(viewType: _viewType);
  }
}
