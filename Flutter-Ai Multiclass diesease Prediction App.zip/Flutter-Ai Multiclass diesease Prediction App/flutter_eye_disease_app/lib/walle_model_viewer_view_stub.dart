import 'package:flutter/material.dart';

class WalleModelViewerWebContainer extends StatelessWidget {
  const WalleModelViewerWebContainer({super.key, required this.modelSource});

  final String modelSource;

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}
