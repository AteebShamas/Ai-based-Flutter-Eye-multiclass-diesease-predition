# Wall-E AI Chat Companion for Flutter Mobile
## Copilot Implementation Prompt (Production-Ready)

---

## **PROJECT OVERVIEW**

**Goal:** Build a mobile Flutter app featuring Wall-E (a rigged VRM 3D robot) as an interactive AI chat companion with:
- Real-time animated expressions and body motion
- Speech synthesis (TTS) with mouth sync
- AI-powered conversation using Groq/DeepSeek LLM
- Integration with Eye App's existing architecture
- Mobile-optimized 3D rendering and animation

**Scope:** Wall-E Chat Module for Eye App
- **Platform:** Flutter (iOS, Android)
- **3D Engine:** Three.js (via WebView) OR native Flutter 3D (Flame 3D / custom OpenGL)
- **LLM Backend:** Groq, DeepSeek, or Claude API
- **TTS:** Google TTS, VOICEVOX, Kokoro TTS, or ElevenLabs
- **Animation System:** VRM rigging with blendshape binding, viseme sync, procedural motion

---

## **ARCHITECTURE & INTEGRATION**

### **Overall System Flow**
```
User Input (Text/Voice)
    ↓
[Chat Screen UI]
    ↓
[LLM Handler] → Groq/DeepSeek API → AI Response
    ↓
[Response Parser] → Emotion Detection → Animation Queue
    ↓
[3D Renderer] → VRM Model Update (Blendshapes, Bones)
    ↓
[TTS Handler] → Audio Generation + Viseme Timeline
    ↓
[Animation Loop] → Mouth Sync + Facial Expressions + Body Motion
    ↓
[Audio Playback] → Speaker Output
```

### **Integration with Eye App**
- **Auth Reuse:** Leverage existing auth tokens from Eye App (FastAPI backend)
- **API Client Extension:** Extend `ApiClient` to include `/chat/*` endpoints
- **Shared UI Theme:** Use Eye App's color scheme and navigation patterns
- **Database:** Extend SQLite to store chat history per user
- **Navigation:** Add Wall-E tab to `DashboardScreen` alongside Diagnosis, History, Reminders, 3D Anatomy

### **Backend Extension** (api_server.py)
Add new endpoints to FastAPI backend:
```python
POST /chat/message
  # Input: user_message, user_id, conversation_id
  # Uses LLM (Groq/DeepSeek) to generate response
  # Returns: ai_response, emotion_tag, animation_cues

POST /chat/tts
  # Input: text, voice_id, language
  # Returns: audio_url or base64 audio + viseme_timeline

GET /chat/history/{user_id}
  # Returns: past conversations
```

---

## **TECH STACK (MOBILE)**

### **Core Framework**
- **Flutter 3.x+** (Dart)
- **Provider or Riverpod** for state management
- **GetIt** for dependency injection

### **3D Rendering Options** (Choose One)

#### **Option A: Three.js via WebView** (Recommended for quick iteration)
- `webview_flutter` 4.x+
- `three.js` CDN (r128+)
- `@pixiv/three-vrm` loader
- HTML/JavaScript bridge for animation control
- **Pros:** Exact parity with Mikasa web app; easy to port code
- **Cons:** WebView memory overhead on mobile

#### **Option B: Native Flutter 3D** (Advanced, better performance)
- `flutter_gl` for OpenGL rendering
- `model_viewer` or custom VRM loader
- Dart math libraries (vector3, quaternion)
- **Pros:** Better performance, no WebView overhead
- **Cons:** Need to rewrite 3D pipeline in Dart

**Recommendation for this phase:** Use **Option A (WebView)** for speed, then optimize to Option B post-launch.

### **Chat & Language Models**
- `groq` SDK (Dart wrapper or HTTP)
- `anthropic` SDK (if using Claude)
- `google_generative_ai` (Dart SDK for Gemini)
- Real-time streaming for chat responses

### **Text-to-Speech**
- `google_cloud_text_to_speech` (cloud-based, high quality)
- `tflite_audio` (offline option)
- `flutter_tts` (fallback)
- Custom VOICEVOX/Kokoro integration (self-hosted or API)

### **Audio & Media**
- `just_audio` for playback
- `audio_waveforms` for visualization
- `speech_to_text` for voice input

### **State & Data**
- `sqflite` (extend Eye App's SQLite for chat history)
- `shared_preferences` (cache conversation context)
- `hive` (optional: fast local DB for offline mode)

### **Utilities**
- `http` or `dio` (HTTP client)
- `json_serializable` (JSON parsing)
- `intl` (date/time formatting)
- `uuid` (unique conversation IDs)

---

## **FILE STRUCTURE**

```
flutter_eye_disease_app/
├── lib/
│   ├── main.dart (App entry)
│   ├── models/
│   │   ├── chat_message.dart
│   │   ├── vrm_animation_state.dart
│   │   ├── emotion_enum.dart
│   │   └── viseme_data.dart
│   ├── services/
│   │   ├── chat_service.dart (LLM integration)
│   │   ├── tts_service.dart (Text-to-Speech)
│   │   ├── vrm_animation_service.dart (Animation logic)
│   │   ├── audio_service.dart (Playback & streaming)
│   │   └── vision_service.dart (Optional: MediaPipe face tracking)
│   ├── providers/
│   │   ├── chat_provider.dart
│   │   ├── vrm_animation_provider.dart
│   │   └── audio_provider.dart
│   ├── screens/
│   │   ├── walle_chat_screen.dart (Main UI)
│   │   └── chat_history_screen.dart
│   ├── widgets/
│   │   ├── vrm_viewer_widget.dart (WebView wrapper)
│   │   ├── chat_message_bubble.dart
│   │   ├── audio_waveform_display.dart
│   │   └── animation_controls_panel.dart
│   ├── utils/
│   │   ├── vrm_animation_utils.dart
│   │   ├── emotion_parser.dart
│   │   └── viseme_timeline_builder.dart
│   └── config/
│       ├── api_config.dart
│       ├── llm_config.dart
│       └── tts_config.dart
├── assets/
│   ├── models/
│   │   └── walle.vrm (Wall-E VRM file)
│   ├── web/
│   │   ├── vrm_viewer.html
│   │   ├── vrm_viewer.js
│   │   └── three.js libs/
│   └── fonts/
├── pubspec.yaml
└── README.md
```

---

## **DETAILED IMPLEMENTATION GUIDE**

### **1. VRM Model Loading & Rendering**

#### **1.1 WebView Setup (vrm_viewer_widget.dart)**
```dart
class VRMViewerWidget extends StatefulWidget {
  @override
  State<VRMViewerWidget> createState() => _VRMViewerWidgetState();
}

class _VRMViewerWidgetState extends State<VRMViewerWidget> {
  late WebViewController _webController;

  @override
  void initState() {
    super.initState();
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF1a1a1a))
      ..loadHtmlString(_getHtmlContent());
  }

  String _getHtmlContent() {
    return '''
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { margin: 0; overflow: hidden; background: #1a1a1a; }
        canvas { display: block; }
      </style>
    </head>
    <body>
      <canvas id="canvas"></canvas>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/@pixiv/three-vrm/lib/three-vrm.js"></script>
      <script>
        // VRM Loader & Animation System
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('canvas'), antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;

        let vrm = null;

        // Load Wall-E VRM
        const loader = new THREE.GLTFLoader();
        loader.load('/assets/models/walle.vrm', (gltf) => {
          THREE.VRMUtils.removeUnnecessaryJoints(gltf.scene);
          THREE.VRM.from(gltf).then((loadedVRM) => {
            vrm = loadedVRM;
            scene.add(vrm.scene);
            animate();
          });
        });

        // Global animation state
        window.vrmState = {
          emotion: 'NEUTRAL',
          mouthOpen: 0,
          blendshapes: {},
          headRotation: { x: 0, y: 0, z: 0 },
          eyeGaze: { x: 0, y: 0 }
        };

        // Expose methods for Dart to call
        window.setEmotion = function(emotion) {
          window.vrmState.emotion = emotion;
        };

        window.updateBlendshape = function(name, value) {
          window.vrmState.blendshapes[name] = value;
          if (vrm) {
            vrm.blendShapeProxy.setValue(name, value);
          }
        };

        window.updateViseme = function(visemeName, intensity) {
          // Map viseme to blendshape
          const blendshapeMap = {
            'A': 'A',
            'E': 'E',
            'I': 'I',
            'O': 'O',
            'U': 'U',
            'M': 'M'
          };
          if (vrm) {
            vrm.blendShapeProxy.setValue(blendshapeMap[visemeName], intensity);
          }
        };

        window.updateHeadRotation = function(x, y, z) {
          if (vrm) {
            vrm.scene.getObjectByName('Head').rotation.set(x, y, z);
          }
        };

        function animate() {
          requestAnimationFrame(animate);
          if (vrm) {
            vrm.update(1 / 60);
          }
          renderer.render(scene, camera);
        }

        window.addEventListener('resize', () => {
          camera.aspect = window.innerWidth / window.innerHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(window.innerWidth, window.innerHeight);
        });
      </script>
    </body>
    </html>
    ''';
  }

  @override
  Widget build(BuildContext context) {
    return WebViewWidget(controller: _webController);
  }
}
```

#### **1.2 Animation Service (vrm_animation_service.dart)**
```dart
class VRMAnimationService {
  late WebViewController _webController;

  VRMAnimationService(this._webController);

  // Apply emotion to blendshapes
  Future<void> setEmotion(Emotion emotion) async {
    final blendshapeMap = _emotionToBlendshapeMap(emotion);
    for (final entry in blendshapeMap.entries) {
      await updateBlendshape(entry.key, entry.value);
    }
  }

  // Update individual blendshape
  Future<void> updateBlendshape(String name, double value) async {
    await _webController.runJavaScript(
      'window.updateBlendshape("$name", $value);'
    );
  }

  // Update viseme for mouth sync
  Future<void> updateViseme(String visemeName, double intensity) async {
    await _webController.runJavaScript(
      'window.updateViseme("$visemeName", $intensity);'
    );
  }

  // Head rotation (thinking, nodding)
  Future<void> updateHeadRotation({
    required double x,
    required double y,
    required double z,
  }) async {
    await _webController.runJavaScript(
      'window.updateHeadRotation($x, $y, $z);'
    );
  }

  Map<String, double> _emotionToBlendshapeMap(Emotion emotion) {
    switch (emotion) {
      case Emotion.happy:
        return {'Joy': 1.0, 'Smile': 0.8};
      case Emotion.sad:
        return {'Sorrow': 0.9, 'Sadness': 0.7};
      case Emotion.angry:
        return {'Angry': 1.0, 'Intimidate': 0.6};
      case Emotion.thinking:
        return {'Neutral': 0.5};
      case Emotion.neutral:
      default:
        return {'Neutral': 1.0};
    }
  }
}
```

---

### **2. Chat & LLM Integration**

#### **2.1 Chat Service (chat_service.dart)**
```dart
class ChatService {
  final ApiClient apiClient;
  final GroqService groqService;

  ChatService({required this.apiClient, required this.groqService});

  Future<ChatResponse> sendMessage(String userMessage, String conversationId) async {
    try {
      // Call LLM backend endpoint
      final response = await apiClient.post(
        '/chat/message',
        data: {
          'user_message': userMessage,
          'conversation_id': conversationId,
          'user_id': getCurrentUserId(),
        },
      );

      final aiResponse = response.data['ai_response'];
      final emotionTag = response.data['emotion_tag'] ?? 'NEUTRAL';
      final animationCues = response.data['animation_cues'] ?? [];

      return ChatResponse(
        message: aiResponse,
        emotion: Emotion.fromString(emotionTag),
        animationCues: animationCues,
      );
    } catch (e) {
      print('Error calling LLM: $e');
      rethrow;
    }
  }

  // Real-time streaming (optional)
  Stream<String> streamChatResponse(String userMessage) {
    return groqService.streamCompletion(userMessage);
  }
}
```

#### **2.2 Groq Integration**
```dart
class GroqService {
  final String apiKey;
  static const String apiUrl = 'https://api.groq.com/openai/v1/chat/completions';

  GroqService({required this.apiKey});

  Future<String> sendMessage(String message) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'mixtral-8x7b-32768',
        'messages': [
          {
            'role': 'user',
            'content': message,
          }
        ],
        'temperature': 0.7,
        'max_tokens': 512,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'];
    } else {
      throw Exception('Groq API error: ${response.statusCode}');
    }
  }

  Stream<String> streamCompletion(String message) async* {
    // Implement streaming with event source parsing
  }
}
```

---

### **3. Text-to-Speech & Viseme Timeline**

#### **3.1 TTS Service (tts_service.dart)**
```dart
class TTSService {
  final ApiClient apiClient;

  TTSService({required this.apiClient});

  Future<TTSResponse> synthesize(String text) async {
    try {
      final response = await apiClient.post(
        '/chat/tts',
        data: {
          'text': text,
          'voice_id': 'walle_en',
          'language': 'en-US',
        },
      );

      return TTSResponse(
        audioUrl: response.data['audio_url'],
        visemeTimeline: _parseVisemeTimeline(response.data['viseme_timeline']),
        duration: response.data['duration'],
      );
    } catch (e) {
      print('TTS error: $e');
      rethrow;
    }
  }

  List<VisemeFrame> _parseVisemeTimeline(List<dynamic> timeline) {
    return timeline.map((frame) {
      return VisemeFrame(
        time: frame['time'],
        viseme: frame['viseme'],
        intensity: (frame['intensity'] as num).toDouble(),
      );
    }).toList();
  }
}

class VisemeFrame {
  final double time;
  final String viseme;
  final double intensity;

  VisemeFrame({
    required this.time,
    required this.viseme,
    required this.intensity,
  });
}
```

#### **3.2 Viseme Timeline Synchronization**
```dart
class VisemeSyncEngine {
  final VRMAnimationService animationService;
  final AudioPlayer audioPlayer;

  VisemeSyncEngine({
    required this.animationService,
    required this.audioPlayer,
  });

  Future<void> syncVisemes(
    Duration audioStartTime,
    List<VisemeFrame> visemeTimeline,
  ) async {
    final currentPosition = audioPlayer.position;
    final elapsedTime = currentPosition.inMilliseconds / 1000.0;

    for (final frame in visemeTimeline) {
      if (frame.time >= elapsedTime && frame.time < elapsedTime + 0.05) {
        await animationService.updateViseme(frame.viseme, frame.intensity);
      }
    }
  }
}
```

---

### **4. Real-Time Animation Loop**

#### **4.1 Animation Controller (vrm_animation_provider.dart)**
```dart
class VRMAnimationProvider extends StateNotifier<VRMAnimationState> {
  final VRMAnimationService animationService;
  final VisemeSyncEngine visemeSyncEngine;
  final AudioPlayer audioPlayer;

  late Timer _animationLoopTimer;

  VRMAnimationProvider({
    required this.animationService,
    required this.visemeSyncEngine,
    required this.audioPlayer,
  }) : super(VRMAnimationState.initial()) {
    _startAnimationLoop();
  }

  void _startAnimationLoop() {
    _animationLoopTimer = Timer.periodic(Duration(milliseconds: 16), (_) async {
      // ~60 FPS animation loop

      // 1. Update emotion blendshapes
      if (state.targetEmotion != state.currentEmotion) {
        final interpolatedEmotion = _lerpEmotion(
          state.currentEmotion,
          state.targetEmotion,
          0.1, // Smoothing factor
        );
        await animationService.setEmotion(interpolatedEmotion);
        state = state.copyWith(currentEmotion: interpolatedEmotion);
      }

      // 2. Sync visemes to audio
      if (audioPlayer.playing) {
        await visemeSyncEngine.syncVisemes(
          audioPlayer.position,
          state.visemeTimeline,
        );
      }

      // 3. Procedural idle animations
      if (!audioPlayer.playing) {
        await _updateIdleAnimation();
      }

      // 4. Micro-expressions (blinks, head sway)
      await _updateMicroExpressions();
    });
  }

  Future<void> _updateIdleAnimation() async {
    // Gentle head sway, shoulder rotation, idle blinks
    final time = DateTime.now().millisecondsSinceEpoch / 1000.0;
    final swayAngle = sin(time * 0.5) * 0.1;
    await animationService.updateHeadRotation(x: 0, y: swayAngle, z: 0);
  }

  Future<void> _updateMicroExpressions() async {
    // Random blinks, eye movements
  }

  @override
  void dispose() {
    _animationLoopTimer.cancel();
    super.dispose();
  }
}
```

---

### **5. Chat UI (walle_chat_screen.dart)**

```dart
class WallEChatScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chatState = ref.watch(chatProvider);
    final animationState = ref.watch(vrmAnimationProvider);
    final audioState = ref.watch(audioProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Wall-E Chat'),
        centerTitle: true,
        backgroundColor: Colors.grey[900],
      ),
      body: Column(
        children: [
          // VRM Viewer (60% of screen)
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.black,
              child: VRMViewerWidget(),
            ),
          ),

          // Chat Interface (40% of screen)
          Expanded(
            flex: 2,
            child: Column(
              children: [
                // Chat Messages
                Expanded(
                  child: ListView.builder(
                    itemCount: chatState.messages.length,
                    itemBuilder: (context, index) {
                      final msg = chatState.messages[index];
                      return ChatMessageBubble(
                        message: msg,
                        isUser: msg.role == 'user',
                      );
                    },
                  ),
                ),

                // Input Area
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _messageController,
                          decoration: InputDecoration(
                            hintText: 'Message Wall-E...',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: const Icon(Icons.send),
                        onPressed: () => _sendMessage(ref),
                      ),
                      IconButton(
                        icon: Icon(
                          audioState.isListening
                              ? Icons.mic
                              : Icons.mic_none,
                        ),
                        onPressed: () => _toggleVoiceInput(ref),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _sendMessage(WidgetRef ref) async {
    final message = _messageController.text;
    if (message.isEmpty) return;

    final chatNotifier = ref.read(chatProvider.notifier);
    final animationNotifier = ref.read(vrmAnimationProvider.notifier);
    final audioNotifier = ref.read(audioProvider.notifier);

    // 1. Add user message
    chatNotifier.addMessage(ChatMessage(role: 'user', content: message));
    _messageController.clear();

    // 2. Get AI response
    try {
      final response = await chatNotifier.sendMessage(message);

      // 3. Set emotion & animation cues
      await animationNotifier.setTargetEmotion(response.emotion);

      // 4. Synthesize TTS
      final ttsResponse = await audioNotifier.synthesize(response.message);

      // 5. Store viseme timeline
      animationNotifier.setVisemeTimeline(ttsResponse.visemeTimeline);

      // 6. Play audio
      await audioNotifier.play(ttsResponse.audioUrl);

      // 7. Add AI message
      chatNotifier.addMessage(ChatMessage(role: 'assistant', content: response.message));
    } catch (e) {
      print('Error: $e');
    }
  }
}
```

---

### **6. Backend Extensions (api_server.py)**

Add these endpoints to FastAPI backend:

```python
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import json
import requests

router = APIRouter(prefix="/chat", tags=["chat"])

class ChatMessageRequest(BaseModel):
    user_message: str
    conversation_id: str
    user_id: str

class ChatMessageResponse(BaseModel):
    ai_response: str
    emotion_tag: str
    animation_cues: list

class TTSRequest(BaseModel):
    text: str
    voice_id: str = "walle_en"
    language: str = "en-US"

@router.post("/message", response_model=ChatMessageResponse)
async def chat_message(request: ChatMessageRequest):
    """
    Process user message via LLM and return AI response with emotion tags.
    """
    # Call Groq API
    groq_response = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        },
        json={
            "model": "mixtral-8x7b-32768",
            "messages": [
                {"role": "system", "content": "You are Wall-E, a friendly robot companion. Keep responses concise and conversational."},
                {"role": "user", "content": request.user_message}
            ],
            "temperature": 0.7,
            "max_tokens": 256
        }
    )

    ai_response = groq_response.json()["choices"][0]["message"]["content"]

    # Detect emotion from response
    emotion = detect_emotion_from_text(ai_response)

    # Generate animation cues
    animation_cues = extract_animation_cues(ai_response)

    # Save to chat history
    save_chat_message(request.user_id, request.conversation_id, request.user_message, ai_response)

    return ChatMessageResponse(
        ai_response=ai_response,
        emotion_tag=emotion,
        animation_cues=animation_cues
    )

@router.post("/tts")
async def text_to_speech(request: TTSRequest):
    """
    Convert text to speech with viseme timeline.
    """
    # Use Google TTS or self-hosted VOICEVOX
    audio_bytes, viseme_timeline = synthesize_with_visemes(
        request.text,
        request.voice_id
    )

    # Save audio and return
    audio_url = save_audio_file(audio_bytes)

    return {
        "audio_url": audio_url,
        "viseme_timeline": viseme_timeline,
        "duration": calculate_audio_duration(audio_bytes)
    }

@router.get("/history/{user_id}")
async def get_chat_history(user_id: str):
    """Retrieve chat history."""
    messages = get_user_chat_history(user_id)
    return {"messages": messages}

def detect_emotion_from_text(text: str) -> str:
    """Simple emotion detection using keyword matching."""
    keywords = {
        "happy": ["happy", "great", "love", "awesome", "amazing"],
        "sad": ["sad", "sorry", "bad", "terrible"],
        "angry": ["angry", "frustrated", "hate"],
        "thinking": ["hmm", "let me think", "interesting"]
    }
    
    text_lower = text.lower()
    for emotion, words in keywords.items():
        if any(word in text_lower for word in words):
            return emotion
    
    return "neutral"

def extract_animation_cues(text: str) -> list:
    """Extract animation cues from response."""
    return []  # Implement custom logic

def synthesize_with_visemes(text: str, voice_id: str) -> tuple:
    """Generate audio and viseme timeline."""
    # Use Google Cloud TTS or custom VOICEVOX API
    # Return: (audio_bytes, viseme_timeline)
    pass
```

---

## **DEVELOPMENT ROADMAP**

### **Phase 1: Core Setup (Week 1)**
- [ ] Set up Flutter project with dependencies
- [ ] Create WebView wrapper for Three.js/VRM
- [ ] Load Wall-E VRM model and basic rendering
- [ ] Test VRM blendshape manipulation from Dart

### **Phase 2: Animation System (Week 2)**
- [ ] Implement emotion-to-blendshape mapping
- [ ] Build VRM animation service with smooth interpolation
- [ ] Add idle animations (blinks, head sway, subtle motion)
- [ ] Implement micro-expressions

### **Phase 3: Chat Integration (Week 3)**
- [ ] Integrate Groq API for LLM responses
- [ ] Build chat UI and message history
- [ ] Implement emotion detection from responses
- [ ] Add animation triggers based on responses

### **Phase 4: TTS & Viseme Sync (Week 4)**
- [ ] Integrate Google TTS or VOICEVOX
- [ ] Generate viseme timelines from audio
- [ ] Implement real-time mouth-sync animation
- [ ] Sync audio playback with visemes

### **Phase 5: Polish & Testing (Week 5)**
- [ ] Mobile UI/UX refinement
- [ ] Performance optimization (WebView memory, animation smoothness)
- [ ] Test on physical devices (iOS/Android)
- [ ] Integrate with Eye App navigation

### **Phase 6: Deployment (Week 6)**
- [ ] Build APK/IPA packages
- [ ] Test on App Store / Google Play guidelines
- [ ] Deploy to staging environment

---

## **KEY IMPLEMENTATION TIPS**

1. **WebView Memory:** Monitor WebView memory usage; consider reloading model on low memory warnings.
2. **Animation Smoothness:** Use requestAnimationFrame (60 FPS) in JavaScript; limit Dart-JS communication to <16ms.
3. **Audio Sync:** Maintain audio playback state synchronized with animation loop using `audioPlayer.position`.
4. **Emotion Blending:** Lerp between emotions smoothly (0.1 factor) to avoid jarring transitions.
5. **Offline Mode:** Cache conversation context and TTS audio locally for offline capability.
6. **Voice Input:** Use `speech_to_text` package; handle microphone permissions gracefully.
7. **Privacy:** Store chat history locally by default; only sync encrypted history to backend if user opts in.

---

## **DEPENDENCIES SUMMARY**

Add to `pubspec.yaml`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  webview_flutter: ^4.0.0
  provider: ^6.0.0
  riverpod: ^2.0.0
  http: ^1.1.0
  just_audio: ^0.9.0
  speech_to_text: ^6.0.0
  uuid: ^3.0.0
  shared_preferences: ^2.0.0
  sqflite: ^2.2.0
  intl: ^0.18.0
  google_cloud_text_to_speech: (or custom TTS SDK)

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^2.0.0
```

---

## **TESTING CHECKLIST**

- [ ] VRM model loads without errors
- [ ] Blendshapes respond to Dart calls
- [ ] Chat messages stream without lag
- [ ] TTS audio generated and plays correctly
- [ ] Viseme timeline syncs to audio playback
- [ ] Emotions trigger correct facial expressions
- [ ] Idle animations run smoothly
- [ ] Chat history persists across app restarts
- [ ] Performance acceptable on mid-range devices

---

## **DEPLOYMENT CHECKLIST**

- [ ] API endpoints tested with Postman
- [ ] Groq/DeepSeek API keys secured in environment variables
- [ ] TTS service tested with various texts
- [ ] Flutter app builds for Android and iOS
- [ ] WebView permissions granted in Android manifest
- [ ] CORS configured on backend
- [ ] Error handling for network failures
- [ ] User authentication integrated with Eye App
- [ ] Chat history database migrated

---

**This prompt is ready for your copilot. Use it to generate modular, production-ready code with step-by-step guidance. Good luck building Wall-E! 🤖**
