# WALL-E Chat & VRM Integration - Complete Setup Guide

## What's Been Integrated

### 1. **Backend (api_server.py)**
- ✅ Deepseek LLM integration with API key: `sk-b0560ef270f24f35a50aee49b9262b19`
- ✅ Deepseek chat endpoint at `/api/chat` (tries Deepseek first, falls back to Groq)
- ✅ Emotion detection from chat responses
- ✅ VRM command generation for animations
- ✅ Chat history stored in SQLite database

### 2. **Frontend - Flutter Web**
- ✅ **Chat UI Widget** (`chat_with_vrm_widget.dart`)
  - Message display with user/AI separation
  - Real-time message streaming
  - Emotion display with intensity
  - Chat history persistence via SharedPreferences
  
- ✅ **VRM Viewer with Blink Support** (`vrm_viewer_embedded_with_blink.dart`)
  - Embedded iframe viewer on web
  - PostMessage communication for blink commands
  - Eye detection and animation
  
- ✅ **VRM HTML Viewer** (`vrm_viewer.html`)
  - PostMessage listener for blink commands
  - Eye material detection
  - Blink animation with intensity control
  - Emotion-based blink patterns

### 3. **Frontend - Flutter Mobile (Android)**
- ✅ Same Chat UI works on mobile
- ✅ VRM viewer via WebView (local asset loading)
- ✅ Chat history saved locally
- ✅ API connectivity to backend

### 4. **Navigation Integration**
- ✅ New "Chat" tab added to main navigation (5 total tabs)
- ✅ Accessible from dashboard after login
- ✅ Responsive layout (mobile: vertical stack, desktop: side-by-side)

## How to Use

### Prerequisites
1. **Backend Running**: Start the FastAPI server
   ```bash
   python api_server.py
   ```
   Default: `http://localhost:8000`

2. **Static Server**: Serve web assets (VRM models, JavaScript libraries)
   ```bash
   cd flutter_eye_disease_app/assets/web
   # Python 3:
   python -m http.server 8080
   ```

3. **Flutter App**: Run on web or mobile
   ```bash
   # Web
   flutter run -d chrome
   
   # Mobile (Android)
   flutter run
   ```

### Test Flow

#### **On Web Browser**
1. Navigate to Flutter app URL (usually `http://localhost:51423`)
2. Login with existing credentials
3. Click the "Chat" tab (4th tab)
4. Type a message and press Send
5. **Watch the VRM eyes blink** when WALL-E responds
6. Repeat for different emotions (sadness, excitement, concern, etc.)

#### **On Android Mobile**
1. Build and run APK: `flutter build apk --release`
2. Install on device or emulator
3. Login
4. Navigate to Chat tab
5. Type messages - VRM should blink in response

## API Endpoints

### Chat Endpoint
**POST** `/api/chat`

Request:
```json
{
  "message": "How can I prevent eye disease?",
  "disease_context": "CNV-high",
  "session_id": null
}
```

Response:
```json
{
  "user_message": "How can I prevent eye disease?",
  "ai_response": "Great question! Here are some preventive measures...",
  "emotion": "happy",
  "emotion_intensity": 0.75,
  "vrm_command": {
    "animation_state": "speaking",
    "emotion": "happy",
    "blink_pattern": "relaxed",
    "eye_direction": "forward",
    "mouth_action": "neutral"
  },
  "timestamp": "2024-01-XX...",
  "source": "deepseek"
}
```

## Eye Blinking Animation

### Trigger Mechanism
1. User sends message via chat UI
2. Backend (Deepseek) responds
3. Response emotion is detected (happy, concerned, excited, etc.)
4. VRM command with emotion is sent back
5. Flutter app receives and detects emotion_intensity
6. **PostMessage is sent to iframe**: `{ action: 'blink', intensity: 0-1, pattern: emotion, duration: ms }`
7. VRM viewer.html receives message
8. Eye materials are located in 3D model
9. Opacity is reduced for blink duration (eye-closing effect)
10. Opacity is restored (eye-opening effect)

### Emotion-Based Blink Patterns
- **happy**: Quick blink (50ms), 1-2 blinks
- **excited**: Rapid blinks (100-150ms), 3-4 blinks  
- **concerned**: Slower blink (200ms), 1-2 blinks
- **confused**: Medium blink (150ms), 2 blinks
- **sadness**: Slow blink (250ms), 1 blink
- **neutral**: Normal blink (100ms), 1 blink

## Features

### Chat UI
- ✅ Auto-scrolling message list
- ✅ Message bubbles (user blue, AI gray)
- ✅ Emotion display below AI messages
- ✅ Clear chat history option
- ✅ Connection status indicator
- ✅ Loading indicator during API calls
- ✅ Input validation (empty message check)

### VRM Viewer
- ✅ Auto-framing camera (fits any model size)
- ✅ Manual rotation via mouse/touch drag
- ✅ Front-facing orientation (Math.PI/2 rotation)
- ✅ Eye blink animation on chat response
- ✅ Status overlay showing model load status
- ✅ Support for .VRM and .GLB formats

### Responsive Design
- **Desktop** (>800px): Side-by-side layout
  - 50% VRM viewer (left)
  - 50% Chat UI (right)
- **Mobile** (<800px): Vertical stack
  - 40% VRM viewer (top)
  - 60% Chat UI (bottom)

## Troubleshooting

### VRM Eyes Not Blinking
1. Check browser console for postMessage errors
2. Verify iframe is loaded: Look for "VRM loaded: /3d model/walle.vrm" message
3. Check that eye materials exist in model (try searching for "eye" in mesh names)
4. Ensure response emotion is detected: Check "emotion" field in chat response

### Blank VRM Viewer
1. Verify static server is running on port 8080
2. Check VRM file exists at: `flutter_eye_disease_app/3d model/walle.vrm`
3. Check browser console for 404 errors on asset files
4. Try accessing directly: `http://localhost:8080/assets/web/vrm_viewer.html?model=/3d%20model/walle.vrm`

### Chat Not Connecting
1. Verify backend is running: `curl http://localhost:8000/health`
2. Check API URL is correct in app (Settings if available)
3. Verify authentication token is valid
4. Check browser/app network tab for API request details

### Mobile APK Not Working
1. Build APK: `flutter build apk --release`
2. Ensure backend is accessible from mobile device:
   - Use device IP if running on same network
   - Or use emulator with `10.0.2.2` for localhost
3. Check logcat: `adb logcat | grep flutter`
4. Verify permissions in `android/app/build.gradle`

## File Structure

```
flutter_eye_disease_app/
├── lib/
│   ├── main.dart (updated: added Chat tab)
│   ├── widgets/
│   │   ├── chat_with_vrm_widget.dart (NEW)
│   │   ├── vrm_viewer_embedded_with_blink.dart (NEW)
│   │   └── vrm_viewer_widget.dart
│   └── ...
├── assets/
│   └── web/
│       ├── vrm_viewer.html (updated: added blink support)
│       ├── lib/
│       │   ├── three.module.js
│       │   ├── GLTFLoader.js
│       │   ├── OrbitControls.js
│       │   └── three-vrm.module.min.js
│       └── ...
└── ...

api_server.py (updated: added Deepseek integration)
```

## Next Steps (Optional)

1. **Customize Blink Patterns**
   - Edit blink duration and intensity mappings in vrm_viewer.html
   - Adjust eye material detection logic
   
2. **Add Hand Gestures**
   - Implement gesture animation from VRMCommand in viewer
   
3. **Voice Chat**
   - Add speech-to-text input
   - Add text-to-speech output with lip-sync
   
4. **Save Chat History**
   - Already saved locally, but consider cloud sync
   
5. **Theme Customization**
   - Adjust VRM background color
   - Customize chat bubble colors based on emotion

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review Flutter console output for errors
3. Check browser DevTools console for JavaScript errors
4. Check API server logs for backend issues

---
**Integration Status**: ✅ Complete
**Last Updated**: 2024
**Deepseek API Key**: Configured
**Backend**: Ready
**Frontend**: Ready
**Mobile Support**: Ready
