# WALL-E Chatbot - Quick Start Testing Guide

## Prerequisites
- Python 3.10+
- Flutter SDK latest version
- Android SDK for Android testing (or iOS SDK for iOS)
- Grok API Key (from xAI platform)

## Backend Setup

### 1. Start Python API Server
```bash
cd c:\Users\USer\Desktop\Human_Eye_Disease_Prediction

# Set Grok API key (required for AI responses)
set GROK_API_KEY=your_grok_api_key_here

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Run API server
uvicorn api_server:app --host 0.0.0.0 --port 5000 --reload
```

The API server will start at `http://localhost:5000`

### 2. Verify API is Running
```bash
# In another terminal, test the health endpoint
curl http://localhost:5000/health

# Should respond with:
# {"status": "ok"}
```

## Flutter App Setup

### 1. Get Dependencies
```bash
cd flutter_eye_disease_app
flutter pub get
```

### 2. Run the App

#### On Android Emulator
```bash
flutter run -d emulator
```

#### On Physical Device
```bash
# First, connect your device
flutter devices  # List connected devices
flutter run -d <device_id>
```

#### On Web (for quick testing)
```bash
flutter run -d web
```

## Testing the Chat Feature

### 1. Login/Register
- Create an account or login with existing credentials
- Navigate to "Ask VisDect" tab (5th tab in dashboard)

### 2. Text Chat Test
**Test Case 1: Basic Question**
- Type: "What is CNV?"
- Expected: WALL-E responds with information about Choroidal Neovascularization
- Avatar state changes to: Thinking → Speaking

**Test Case 2: Medical Question**
- Type: "Tell me about diabetic macular edema treatment"
- Expected: Detailed response about DME treatment options
- Audio plays automatically

**Test Case 3: General Eye Health**
- Type: "What foods are good for eye health?"
- Expected: Nutritional advice for eye health

### 3. Voice Chat Test
**Test Case 4: Speech Recognition**
- Click microphone button
- Say: "What is Drusen?"
- Expected: Text appears in input field and message is sent
- WALL-E responds with information about Drusen

### 4. Avatar Animation Test
**Test Case 5: State Changes**
1. Type a message and observe:
   - ✅ IDLE state (before sending)
   - ✅ THINKING state (while waiting for response)
   - ✅ SPEAKING state (while reading response)
   - ✅ Avatar animations change
   - ✅ Eyes blink at appropriate times
   - ✅ Mouth moves when speaking

### 5. UI Enhancement Test
**Test Case 6: Message Features**
- Type a message and send it
- Long-press your message bubble
- Expected: See "Copy" option
- Long-press AI response
- Expected: See "Copy" and "Read Aloud" options

**Test Case 7: Clear Conversation**
- Click delete icon in header
- Confirm clearing
- Expected: All messages removed, welcome message appears

**Test Case 8: Timestamps**
- Send multiple messages over time
- Expected: Each message shows time in HH:MM format

### 6. Error Handling Test
**Test Case 9: Offline Mode**
- Turn off internet connection
- Try to send a message
- Expected: Error message appears and shows fallback response

**Test Case 10: Slow Network**
- Send a long message on slow network
- Expected: Timeout message or fallback response (within 30 seconds)

## API Endpoint Testing

### Manual API Test with curl
```bash
# Get Bearer token first (from login response)

# Test chat endpoint
curl -X POST http://localhost:5000/api/chat \
  -H "Authorization: Bearer <YOUR_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"message": "What is CNV?"}'

# Expected response:
{
  "user_message": "What is CNV?",
  "ai_response": "CNV (Choroidal Neovascularization) is...",
  "timestamp": "2024-01-01T12:00:00Z",
  "source": "grok"
}
```

## Debugging

### Enable Debug Logging
Add to `main.dart` or use Flutter DevTools:
```bash
flutter run -d <device_id> --verbose
```

### Common Issues & Solutions

**Issue: Chat not connecting**
- Solution: Check API URL in Settings tab matches your server
- Verify: `http://127.0.0.1:5000` for local testing

**Issue: Voice recognition not working**
- Solution: Ensure microphone permissions granted in Settings
- On Android: Go to App Settings → Permissions → Microphone

**Issue: Audio not playing**
- Solution: Check device volume is not muted
- Verify: TTS language is set to English

**Issue: Avatar not animating**
- Solution: This is expected if VRM model not configured
- Fallback avatar should display and animate

## Performance Benchmarks

| Operation | Expected Time | Notes |
|-----------|---------------|-------|
| App startup | < 5 seconds | First time slower |
| Login | 1-2 seconds | Network dependent |
| First chat message | 3-5 seconds | API initialization |
| Subsequent messages | 1-2 seconds | Average response time |
| TTS response | 2-10 seconds | Depends on response length |
| Voice input | 5-10 seconds | Plus processing time |

## Configuration Checklist

- [ ] GROK_API_KEY environment variable set
- [ ] API server running on correct port
- [ ] Flutter app pointing to correct API URL
- [ ] Microphone permissions granted (Android)
- [ ] Network connectivity verified
- [ ] Model file exists (if using VRM)
- [ ] Database initialized (check retina_app.db exists)

## Next Steps

1. ✅ All features implemented and tested
2. ✅ Documentation created
3. Ready for:
   - [ ] Production deployment
   - [ ] Performance optimization
   - [ ] User feedback integration
   - [ ] Additional language support

## Support Resources

- **Grok API**: https://console.x.ai/api
- **Flutter Docs**: https://flutter.dev/docs
- **FastAPI Docs**: http://localhost:5000/docs (when running)

---

**Status**: ✅ FULLY IMPLEMENTED & TESTED
**Last Updated**: May 2, 2026
