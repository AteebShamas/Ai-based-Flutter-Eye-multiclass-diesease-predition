﻿import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import tempfile
import time
from datetime import datetime, timezone
from typing import Any
import re
from enum import Enum

# Use legacy Keras so older saved models with slash-named layers can deserialize.
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")

# TensorFlow 2.19 with tf_keras 2.21 expects the protobuf 6 runtime, but some
# code paths still call the older GetPrototype API. Bridge that gap here so the
# backend can start cleanly with the matching protobuf runtime.
try:
    from google.protobuf import message_factory as _message_factory

    if not hasattr(_message_factory.MessageFactory, "GetPrototype"):
        def _get_prototype(self, message_descriptor):
            return _message_factory.GetMessageClass(message_descriptor)

        _message_factory.MessageFactory.GetPrototype = _get_prototype  # type: ignore[attr-defined]
except Exception:
    pass

import numpy as np
import tensorflow as tf
import httpx
import uvicorn
from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, UploadFile, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from enum import Enum

# General Chatbot Configuration
MODEL_PATH = os.getenv("MODEL_PATH", "Trained_Model.h5")
DB_PATH = os.getenv("DB_PATH", "retina_app.db")
TOKEN_SECRET = os.getenv("TOKEN_SECRET", "wall-e-chatbot-dev-secret")
TOKEN_TTL_SECONDS = int(os.getenv("TOKEN_TTL_SECONDS", "604800"))
GROQ_API_KEY = os.getenv("GROQ_API_KEY", os.getenv("GROK_API_KEY", "")).strip()
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# Deepseek LLM Configuration
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "sk-b0560ef270f24f35a50aee49b9262b19").strip()
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_MODEL = "deepseek-chat"


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=6, max_length=128)


class LoginRequest(BaseModel):
    email: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=6, max_length=128)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    disease_context: str | None = None
    session_id: str | None = None
    memory_context: str | None = None


class TTSRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class EmotionState(str, Enum):
    """Six primary emotional states for WALL-E."""
    HAPPY = "happy"
    EXCITED = "excited"
    CONCERNED = "concerned"
    CONFUSED = "confused"
    SADNESS = "sadness"
    NEUTRAL = "neutral"


class AnimationState(str, Enum):
    """VRM animation states."""
    IDLE = "idle"
    LISTENING = "listening"
    PROCESSING = "processing"
    SPEAKING = "speaking"
    THINKING = "thinking"
    ERROR = "error"


class VRMCommand(BaseModel):
    """Command sent to VRM for animation control."""
    animation_state: str  # AnimationState
    emotion: str  # EmotionState
    blink_pattern: str  # 'relaxed', 'attentive', 'engaged', 'thinking', 'excited'
    eye_direction: str  # 'forward', 'up', 'down', 'side'
    mouth_action: str  # 'neutral', 'smile', 'frown', 'phoneme_index'
    gesture: str | None = None  # optional hand/body gesture


# Emotion Detection Configuration (General Purpose)
EMOTION_KEYWORDS = {
    "happy": {
        "keywords": ["great", "wonderful", "excellent", "good", "positive", "love", "awesome", "best", "perfect", "thank you"],
        "intensity_multiplier": 0.8,
    },
    "excited": {
        "keywords": ["amazing", "fantastic", "incredible", "wow", "exciting", "awesome", "remarkable", "brilliant"],
        "intensity_multiplier": 1.0,
    },
    "concerned": {
        "keywords": ["worried", "problem", "help", "issue", "difficult", "challenge", "trouble", "struggle"],
        "intensity_multiplier": 0.9,
    },
    "confused": {
        "keywords": ["what", "how", "why", "confuse", "unclear", "explain", "understand", "question"],
        "intensity_multiplier": 0.6,
    },
    "sadness": {
        "keywords": ["sorry", "sad", "bad", "unfortunately", "loss", "unfortunate", "unhappy", "miss"],
        "intensity_multiplier": 0.7,
    },
}

# Blink patterns for different states
BLINK_PATTERNS = {
    "relaxed": {"interval": (4, 6), "duration": 150, "speed_profile": "natural"},
    "attentive": {"interval": (5, 8), "duration": 200, "speed_profile": "deliberate"},
    "engaged": {"interval": (6, 10), "duration": 120, "speed_profile": "quick"},
    "thinking": {"interval": (8, 12), "duration": 225, "speed_profile": "slow"},
    "excited": {"interval": (1, 2), "duration": 100, "speed_profile": "rapid", "blink_count": 4},
}


# Emotion Detection Configuration
EMOTION_KEYWORDS = {
    EmotionState.HAPPY: {
        "keywords": ["great", "wonderful", "excellent", "good", "positive", "healthy", "normal", "clear", "success", "perfect"],
        "intensity_multiplier": 0.8,
    },
    EmotionState.EXCITED: {
        "keywords": ["amazing", "fantastic", "incredible", "breakthrough", "exciting", "wonderful", "remarkable"],
        "intensity_multiplier": 1.0,
    },
    EmotionState.CONCERNED: {
        "keywords": ["serious", "urgent", "concerning", "difficult", "challenge", "disease", "severe", "advanced", "complicated"],
        "intensity_multiplier": 0.9,
    },
    EmotionState.CONFUSED: {
        "keywords": ["complex", "unusual", "interesting", "question", "unclear", "ambiguous", "different"],
        "intensity_multiplier": 0.6,
    },
    EmotionState.SADNESS: {
        "keywords": ["unfortunately", "limited", "difficult", "suffering", "loss", "unfortunate", "struggle", "hard"],
        "intensity_multiplier": 0.7,
    },
}

DISEASE_SEVERITY = {
    "CNV": {"severity": "high", "emotion": EmotionState.CONCERNED, "urgency": "urgent"},
    "DME": {"severity": "high", "emotion": EmotionState.CONCERNED, "urgency": "urgent"},
    "DRUSEN": {"severity": "medium", "emotion": EmotionState.HAPPY, "urgency": "followup"},
    "NORMAL": {"severity": "low", "emotion": EmotionState.HAPPY, "urgency": "none"},
}

CLASS_NAMES = ["CNV", "DME", "DRUSEN", "NORMAL"]

RECOMMENDATIONS: dict[str, dict[str, Any]] = {
    "CNV": {
        "title": "Choroidal Neovascularization",
        "points": [
            "Immediate retina specialist follow-up is recommended.",
            "Anti-VEGF therapy is commonly used to slow vision loss.",
            "Regular OCT monitoring is important to track response.",
        ],
    },
    "DME": {
        "title": "Diabetic Macular Edema",
        "points": [
            "Coordinate care with both a retina specialist and diabetes care provider.",
            "Anti-VEGF injections are often first-line treatment.",
            "Blood sugar and blood pressure control matter for long-term stability.",
        ],
    },
    "DRUSEN": {
        "title": "Drusen / Early AMD",
        "points": [
            "Discuss AREDS2 supplements with your eye doctor if appropriate.",
            "Monitor for progression with routine OCT or retinal exams.",
            "Lifestyle changes like smoking cessation and UV protection help.",
        ],
    },
    "NORMAL": {
        "title": "Normal Retina",
        "points": [
            "Continue routine eye checkups as advised by your doctor.",
            "Maintain good eye health habits and monitor for new symptoms.",
            "Return for review if vision changes appear.",
        ],
    },
}

# Blink patterns for different states
BLINK_PATTERNS = {
    "relaxed": {"interval": (4, 6), "duration": 150, "speed_profile": "natural"},
    "attentive": {"interval": (5, 8), "duration": 200, "speed_profile": "deliberate"},
    "engaged": {"interval": (6, 10), "duration": 120, "speed_profile": "quick"},
    "thinking": {"interval": (8, 12), "duration": 225, "speed_profile": "slow"},
    "excited": {"interval": (1, 2), "duration": 100, "speed_profile": "rapid", "blink_count": 4},
}

# General knowledge base for fallback responses
KNOWLEDGE_BASE = {
    "greeting": {
        "keywords": ["hello", "hi", "hey", "greet", "morning", "afternoon", "evening"],
        "responses": [
            "Hey there! I'm WALL-E. How can I help you today?",
            "Hello! Great to see you. What's on your mind?",
            "Hi! How are you doing today?",
            "Hey! I'm here to chat about anything you'd like!",
        ]
    },
    "help": {
        "keywords": ["help", "assist", "support", "guidance"],
        "responses": [
            "I'm here to help! Feel free to ask me anything or just chat with me.",
            "Happy to assist! What would you like to know?",
            "I'm ready to help. What do you need?",
        ]
    },
    "how_are_you": {
        "keywords": ["how are you", "how do you", "how\'s it", "how\'ve you"],
        "responses": [
            "I'm doing great, thanks for asking! How about you?",
            "I'm feeling good! Ready to chat with you. How are you?",
            "All good here! What about you?",
        ]
    },
    "name": {
        "keywords": ["what\'s your name", "who are you", "name", "who"],
        "responses": [
            "I'm WALL-E, your friendly AI chatbot! Pleased to meet you.",
            "I'm WALL-E! Nice to meet you.",
            "You can call me WALL-E. Happy to chat!",
        ]
    },
    "thanks": {
        "keywords": ["thank", "thanks", "appreciate"],
        "responses": [
            "You're welcome! Always happy to help.",
            "My pleasure! Let me know if you need anything else.",
            "Glad I could help! Anything else?",
        ]
    }
}


def _is_medical_chat_message(user_message: str) -> bool:
    message_lower = user_message.lower().strip()
    medical_keywords = [
        "cnv",
        "choroidal neovascularization",
        "dme",
        "diabetic macular edema",
        "drusen",
        "amd",
        "retina",
        "retinal",
        "eye disease",
        "vision loss",
        "treatment",
        "injection",
        "laser",
        "follow up",
        "monitoring",
        "oct",
        "supplement",
        "nutrition",
    ]
    return any(keyword in message_lower for keyword in medical_keywords)


def _detect_emotion(text: str) -> tuple[str, float]:
    """Detect emotion from text using keyword analysis.
    
    Returns: (emotion_name, intensity_0_to_1)
    """
    text_lower = text.lower()
    emotion_scores = {}
    
    for emotion, config in EMOTION_KEYWORDS.items():
        score = 0
        for keyword in config["keywords"]:
            if keyword in text_lower:
                score += 1
        emotion_scores[emotion] = score * config["intensity_multiplier"]
    
    if not any(emotion_scores.values()):
        return "neutral", 0.3
    
    detected_emotion = max(emotion_scores, key=emotion_scores.get)
    intensity = min(emotion_scores[detected_emotion] / 5.0, 1.0)  # Normalize to 0-1
    
    return detected_emotion, intensity


def _get_blink_pattern_for_state(animation_state: str) -> str:
    """Get appropriate blink pattern for animation state."""
    state_to_pattern = {
        "idle": "relaxed",
        "listening": "attentive",
        "processing": "thinking",
        "speaking": "engaged",
        "thinking": "thinking",
        "error": "relaxed",
    }
    return state_to_pattern.get(animation_state, "relaxed")


def _generate_vrm_command(
    animation_state: str,
    emotion: str,
    gesture: str | None = None,
) -> dict[str, Any]:
    """Generate VRM animation command based on state and emotion."""
    blink_pattern = _get_blink_pattern_for_state(animation_state)
    
    # Determine eye direction based on state
    eye_direction_map = {
        "thinking": "up",
        "listening": "forward",
        "speaking": "forward",
        "processing": "up",
        "idle": "forward",
        "error": "down",
    }
    
    # Determine mouth action based on state
    mouth_action_map = {
        "speaking": "phoneme_index",
        "thinking": "neutral",
        "listening": "neutral",
        "idle": "neutral",
    }
    
    # Smile based on emotion
    if emotion in ["happy", "excited"]:
        mouth_action = "smile"
    elif emotion in ["sadness", "concerned"]:
        mouth_action = "frown"
    else:
        mouth_action = mouth_action_map.get(animation_state, "neutral")
    
    return {
        "animation_state": animation_state,
        "emotion": emotion,
        "blink_pattern": blink_pattern,
        "eye_direction": eye_direction_map.get(animation_state, "forward"),
        "mouth_action": mouth_action,
        "gesture": gesture,
    }


def _enhance_response_with_disease_context(
    response: str,
    disease_context: str | None,
) -> str:
    """Enhance AI response with disease-specific context."""
    if not disease_context:
        return response
    
    disease = disease_context.split("-")[0].strip().upper()
    
    if disease not in DISEASE_SEVERITY:
        return response
    
    # Add disease-specific prefix if not already in response
    if disease not in response.upper():
        disease_name = {
            "CNV": "Choroidal Neovascularization",
            "DME": "Diabetic Macular Edema",
            "DRUSEN": "Drusen (Early AMD)",
            "NORMAL": "Normal Retina"
        }.get(disease, disease)
        response = f"Regarding your {disease_name}: {response}"
    
    return response


def _get_general_chat_response(user_message: str) -> str:
    message_lower = user_message.lower().strip()

    if any(greeting in message_lower for greeting in ["hi", "hello", "hey", "yo"]):
        return "Hi there! I'm WALL-E. What would you like to chat about today?"

    if any(phrase in message_lower for phrase in ["how are you", "how r you", "how's it going", "what's up"]):
        return "I'm doing great! I'm here and ready to chat about anything you'd like."

    if any(phrase in message_lower for phrase in ["thank you", "thanks", "thx"]):
        return "You're welcome! Happy to help. What else can I do for you?"

    if any(phrase in message_lower for phrase in ["bye", "goodbye", "see you"]):
        return "Bye! Feel free to come back anytime you want to chat!"

    if any(phrase in message_lower for phrase in ["who are you", "what are you", "your name", "introduce"]):
        return "I'm WALL-E, your friendly AI chat companion! I love having conversations about anything."

    if message_lower.endswith("?"):
        return "That's a great question! Tell me more about it so I can give you a helpful answer."

    return "I'm all ears! Tell me more - I'm happy to discuss whatever is on your mind!"


async def _get_ai_chat_response_groq(
    user_message: str,
    disease_context: str | None = None,
    memory_context: str | None = None,
) -> tuple[str, str, float] | None:
    """Get response from Groq API with emotional intelligence and disease context.
    
    Returns: (response_text, detected_emotion, emotion_intensity) or None if failed
    """
    if not GROQ_API_KEY:
        return None

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            disease_guidance = ""
            if disease_context:
                disease = disease_context.split("-")[0].strip().upper()
                if disease in DISEASE_SEVERITY:
                    severity = DISEASE_SEVERITY[disease]
                    disease_guidance = f"\nThe user's eye scan shows: {disease_context}. Adjust your tone to match {severity['emotion']} but also provide hope and actionable next steps."

            memory_guidance = ""
            if memory_context:
                memory_guidance = f"\nConversation memory to remember and use when relevant:\n{memory_context.strip()}"
            
            system_prompt = f"""{_WALL_E_CHAT_RULES}{memory_guidance}{disease_guidance}"""

            response = await client.post(
                GROQ_API_URL,
                headers={
                    "Authorization": f"Bearer {GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": "llama-3.3-70b-versatile",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message},
                    ],
                    "temperature": 0.55,
                    "max_tokens": 220,
                },
            )

            if response.status_code == 200:
                data = response.json()
                if "choices" in data and len(data["choices"]) > 0:
                    choice = data["choices"][0]
                    response_text = _finalize_chat_response(
                        choice["message"]["content"].strip()
                    )
                    emotion, intensity = _detect_emotion(response_text)
                    return response_text, emotion, intensity
    except Exception as e:
        print(f"Groq API error: {e}")
        # Fall back to local response generation.
        pass

    return None


async def _get_ai_chat_response_deepseek(
    user_message: str,
    disease_context: str | None = None,
    memory_context: str | None = None,
) -> tuple[str, str, float] | None:
    """Get response from Deepseek API with emotional intelligence and disease context.
    
    Returns: (response_text, detected_emotion, emotion_intensity) or None if failed
    """
    if not DEEPSEEK_API_KEY:
        return None

    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            disease_guidance = ""
            memory_guidance = ""
            if disease_context:
                disease = disease_context.split("-")[0].strip().upper()
                if disease in DISEASE_SEVERITY:
                    severity = DISEASE_SEVERITY[disease]
                    disease_guidance = f"\nThe user's eye scan shows: {disease_context}. Adjust your tone to match {severity['emotion']} but also provide hope and actionable next steps."
            if memory_context:
                memory_guidance = f"\nConversation memory to remember and use when relevant:\n{memory_context.strip()}"
            
            system_prompt = f"""{_WALL_E_CHAT_RULES}{memory_guidance}{disease_guidance}"""

            response = await client.post(
                DEEPSEEK_API_URL,
                headers={
                    "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": DEEPSEEK_MODEL,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message},
                    ],
                    "temperature": 0.55,
                    "max_tokens": 220,
                },
            )

            if response.status_code == 200:
                data = response.json()
                if "choices" in data and len(data["choices"]) > 0:
                    choice = data["choices"][0]
                    response_text = _finalize_chat_response(
                        choice["message"]["content"].strip()
                    )
                    emotion, intensity = _detect_emotion(response_text)
                    return response_text, emotion, intensity
    except Exception as e:
        print(f"Deepseek API error: {e}")
        # Fall back to Groq or local response generation
        pass

    return None


async def _get_ai_chat_response(
    user_message: str,
    disease_context: str | None = None,
    memory_context: str | None = None,
) -> tuple[str, str, float]:
    """Generate a conversational response with medical fallback and emotion detection.
    
    Returns: (response_text, emotion, intensity)
    """
    try:
        # Try Deepseek first
        result = await _get_ai_chat_response_deepseek(user_message, disease_context, memory_context)

        # Fall back to Groq if Deepseek fails
        if not result:
            result = await _get_ai_chat_response_groq(user_message, disease_context, memory_context)

        if result:
            response_text, emotion, intensity = result
            response_text = _finalize_chat_response(
                _enhance_response_with_disease_context(response_text, disease_context)
            )
            return response_text, emotion, intensity
    except Exception as e:
        print(f"LLM call failed: {e}")

    message_lower = user_message.lower().strip()
    emotion, intensity = _detect_emotion(user_message)

    if _is_greeting_message(message_lower):
        best_match = None
        best_score = 0

        for category, data in KNOWLEDGE_BASE.items():
            for keyword in data.get("keywords", []):
                if keyword in message_lower:
                    score = len(keyword)
                    if score > best_score:
                        best_score = score
                        best_match = category

        if best_match and best_score > 0:
            import random
            responses = KNOWLEDGE_BASE[best_match]["responses"]
            response_text = _finalize_chat_response(random.choice(responses))
            return response_text, emotion, intensity

        response_text = _finalize_chat_response(
            "I'm WALL-E! Ask me about eye health, your scan, or anything on your mind."
        )
        return response_text, emotion, intensity

    response_text = _finalize_chat_response(_get_general_chat_response(message_lower))
    return response_text, emotion, intensity


def _normalize_response(text: str) -> str:
    """Clean whitespace while preserving semantic content."""
    cleaned = re.sub(r"[ \t]+", " ", text).strip()
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned


def _finalize_chat_response(text: str, max_chars: int = 380) -> str:
    """Keep replies concise, complete, and never ending with '...' or half sentences."""
    cleaned = _normalize_response(text)
    if not cleaned:
        return cleaned

    cleaned = re.sub(r"(\.\.\.|…)+\s*$", "", cleaned).strip()
    cleaned = re.sub(r"[,;:\-–—]\s*$", "", cleaned).strip()

    if cleaned and cleaned[-1] not in ".!?":
        parts = re.split(r"(?<=[.!?])\s+", cleaned)
        complete = [p for p in parts if p and p[-1] in ".!?"]
        if complete:
            cleaned = " ".join(complete).strip()
        elif len(cleaned.split()) >= 6:
            cleaned = cleaned.rstrip(",;:") + "."

    if len(cleaned) > max_chars:
        chunk = cleaned[:max_chars]
        last_stop = max(chunk.rfind("."), chunk.rfind("!"), chunk.rfind("?"))
        if last_stop >= 48:
            cleaned = chunk[: last_stop + 1].strip()
        else:
            cleaned = chunk.rstrip(",;:- ") + "."

    return cleaned.strip()


_WALL_E_CHAT_RULES = """
You are WALL-E, a warm, empathetic AI assistant for eye health and general chat.
Answer in 2 to 4 short, complete sentences. Be concise and direct — no filler, no long paragraphs.
Cover the key point first, then one brief supporting detail if needed.
Always finish with proper punctuation. Never end with "..." or an incomplete sentence.
For CNV, DME, DRUSEN, or eye symptoms: plain language, educational only (not a diagnosis).
Stay friendly and natural."""


app = FastAPI(title="Human Eye Disease Prediction API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model: tf.keras.Model | None = None


def _looks_like_image_bytes(image_bytes: bytes) -> bool:
    """Best-effort image signature check for common formats."""
    if len(image_bytes) < 12:
        return False

    signatures = (
        b"\xFF\xD8\xFF",  # JPEG
        b"\x89PNG\r\n\x1a\n",  # PNG
        b"GIF87a",  # GIF
        b"GIF89a",  # GIF
        b"BM",  # BMP
        b"II*\x00",  # TIFF (little-endian)
        b"MM\x00*",  # TIFF (big-endian)
    )
    if any(image_bytes.startswith(sig) for sig in signatures):
        return True

    # WEBP: RIFF....WEBP
    if image_bytes.startswith(b"RIFF") and image_bytes[8:12] == b"WEBP":
        return True

    return False


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_email(email: str) -> str:
    return email.strip().lower()


def _b64url_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("utf-8").rstrip("=")


def _b64url_decode(value: str) -> bytes:
    padding = "=" * ((4 - len(value) % 4) % 4)
    return base64.urlsafe_b64decode(f"{value}{padding}".encode("utf-8"))


def _hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260000)
    return f"{salt.hex()}:{digest.hex()}"


def _verify_password(password: str, hashed_value: str) -> bool:
    try:
        salt_hex, digest_hex = hashed_value.split(":", maxsplit=1)
    except ValueError:
        return False
    salt = bytes.fromhex(salt_hex)
    expected_digest = bytes.fromhex(digest_hex)
    candidate_digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260000)
    return hmac.compare_digest(candidate_digest, expected_digest)


def _create_access_token(user_id: int) -> str:
    payload = {
        "sub": user_id,
        "exp": int(time.time()) + TOKEN_TTL_SECONDS,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    signature = hmac.new(TOKEN_SECRET.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
    return f"{_b64url_encode(payload_bytes)}.{_b64url_encode(signature)}"


def _decode_access_token(token: str) -> dict[str, Any]:
    try:
        payload_part, signature_part = token.split(".", maxsplit=1)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail="Invalid token format.") from exc

    payload_bytes = _b64url_decode(payload_part)
    signature_bytes = _b64url_decode(signature_part)

    expected_signature = hmac.new(
        TOKEN_SECRET.encode("utf-8"),
        payload_bytes,
        hashlib.sha256,
    ).digest()

    if not hmac.compare_digest(signature_bytes, expected_signature):
        raise HTTPException(status_code=401, detail="Invalid token signature.")

    payload = json.loads(payload_bytes.decode("utf-8"))
    expiry = int(payload.get("exp", 0))
    if int(time.time()) >= expiry:
        raise HTTPException(status_code=401, detail="Token expired.")
    return payload


def _extract_bearer_token(authorization: str | None) -> str:
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")
    prefix = "Bearer "
    if not authorization.startswith(prefix):
        raise HTTPException(status_code=401, detail="Authorization header must use Bearer token.")
    return authorization[len(prefix) :].strip()


def _db_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def _init_db() -> None:
    with _db_connection() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS prediction_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                image_name TEXT NOT NULL,
                prediction_label TEXT NOT NULL,
                confidence REAL NOT NULL,
                class_probabilities TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )


@app.on_event("startup")
def startup() -> None:
    global model
    _init_db()
    if not os.path.exists(MODEL_PATH):
        print(f"[startup] Model file not found at: {MODEL_PATH}. Prediction endpoint will be unavailable.")
        model = None
        return

    try:
        model = tf.keras.models.load_model(MODEL_PATH, compile=False)
    except Exception as exc:
        # Keep API available for chat/auth even when model deserialization fails.
        print(f"[startup] Model load failed: {exc}")
        print("[startup] Continuing without prediction model. /predict will return an error until model is fixed.")
        model = None


def _predict_from_image_bytes(image_bytes: bytes) -> tuple[int, np.ndarray[Any, np.dtype[np.float32]]]:
    if model is None:
        raise RuntimeError("Model is not loaded. Check startup logs.")

    with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as temp_file:
        temp_file.write(image_bytes)
        temp_path = temp_file.name

    try:
        img = tf.keras.utils.load_img(temp_path, target_size=(224, 224))
        x = tf.keras.utils.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = tf.keras.applications.mobilenet_v3.preprocess_input(x)
        predictions = model.predict(x, verbose=0)
        index = int(np.argmax(predictions[0]))
        probabilities = predictions[0].astype(np.float32)
        return index, probabilities
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def _serialize_user(user_row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": int(user_row["id"]),
        "full_name": str(user_row["full_name"]),
        "email": str(user_row["email"]),
    }


def get_current_user(authorization: str | None = Header(default=None)) -> sqlite3.Row:
    token = _extract_bearer_token(authorization)
    payload = _decode_access_token(token)
    user_id = int(payload.get("sub", 0))
    if user_id <= 0:
        raise HTTPException(status_code=401, detail="Invalid token subject.")

    with _db_connection() as connection:
        user_row = connection.execute(
            "SELECT id, full_name, email FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
    if user_row is None:
        raise HTTPException(status_code=401, detail="User no longer exists.")
    return user_row


@app.get("/")
def root() -> dict[str, Any]:
    return {
        "message": "Eye Disease Prediction API is running.",
        "usage": {
            "register": "POST /auth/register",
            "login": "POST /auth/login",
            "predict": "POST /predict (Bearer token required)",
            "history": "GET /history (Bearer token required)",
        },
    }


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/auth/register")
def register(payload: RegisterRequest) -> dict[str, Any]:
    normalized_email = _normalize_email(payload.email)
    password_hash = _hash_password(payload.password)
    created_at = _utc_now_iso()

    try:
        with _db_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO users (full_name, email, password_hash, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (payload.full_name.strip(), normalized_email, password_hash, created_at),
            )
            user_id = int(cursor.lastrowid)
            user_row = connection.execute(
                "SELECT id, full_name, email FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
    except sqlite3.IntegrityError as exc:
        raise HTTPException(status_code=400, detail="Email is already registered.") from exc

    if user_row is None:
        raise HTTPException(status_code=500, detail="Failed to load created user.")

    token = _create_access_token(int(user_row["id"]))
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": TOKEN_TTL_SECONDS,
        "user": _serialize_user(user_row),
    }


@app.post("/auth/login")
def login(payload: LoginRequest) -> dict[str, Any]:
    normalized_email = _normalize_email(payload.email)
    with _db_connection() as connection:
        user_row = connection.execute(
            "SELECT id, full_name, email, password_hash FROM users WHERE email = ?",
            (normalized_email,),
        ).fetchone()

    if user_row is None or not _verify_password(payload.password, str(user_row["password_hash"])):
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    token = _create_access_token(int(user_row["id"]))
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": TOKEN_TTL_SECONDS,
        "user": {
            "id": int(user_row["id"]),
            "full_name": str(user_row["full_name"]),
            "email": str(user_row["email"]),
        },
    }


@app.get("/me")
def me(user: sqlite3.Row = Depends(get_current_user)) -> dict[str, Any]:
    return {"user": _serialize_user(user)}


@app.post("/predict")
async def predict(
    file: UploadFile = File(...),
    user: sqlite3.Row = Depends(get_current_user),
) -> dict[str, Any]:
    content_type = (file.content_type or "").lower().strip()
    if content_type and not content_type.startswith("image/"):
        # Some mobile clients send generic octet-stream for valid images.
        generic_binary_types = {"application/octet-stream", "binary/octet-stream"}
        if content_type not in generic_binary_types:
            raise HTTPException(status_code=400, detail="Uploaded file must be an image.")

    image_bytes = await file.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if not _looks_like_image_bytes(image_bytes):
        raise HTTPException(status_code=400, detail="Uploaded file is not a recognized image format.")

    try:
        class_index, probabilities = _predict_from_image_bytes(image_bytes)
    except (ValueError, OSError, tf.errors.InvalidArgumentError) as exc:
        raise HTTPException(status_code=400, detail=f"Uploaded file is not a valid image: {exc}") from exc
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=500, detail=f"Prediction failed: {exc}") from exc

    label = CLASS_NAMES[class_index]
    recommendation = RECOMMENDATIONS[label]
    confidence = float(probabilities[class_index])
    class_probabilities = {
        class_name: float(probabilities[idx]) for idx, class_name in enumerate(CLASS_NAMES)
    }

    created_at = _utc_now_iso()
    image_name = file.filename or "uploaded_image.jpg"

    with _db_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO prediction_history (
                user_id,
                image_name,
                prediction_label,
                confidence,
                class_probabilities,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                int(user["id"]),
                image_name,
                label,
                confidence,
                json.dumps(class_probabilities),
                created_at,
            ),
        )
        prediction_id = int(cursor.lastrowid)

    return {
        "history_id": prediction_id,
        "prediction_index": class_index,
        "prediction_label": label,
        "confidence": confidence,
        "class_probabilities": class_probabilities,
        "recommendation_title": recommendation["title"],
        "recommendation_points": recommendation["points"],
        "saved_at": created_at,
    }


@app.get("/history")
def history(
    limit: int = Query(default=50, ge=1, le=200),
    user: sqlite3.Row = Depends(get_current_user),
) -> dict[str, Any]:
    with _db_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, image_name, prediction_label, confidence, class_probabilities, created_at
            FROM prediction_history
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (int(user["id"]), limit),
        ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        try:
            probabilities = json.loads(str(row["class_probabilities"]))
        except json.JSONDecodeError:
            probabilities = {}

        items.append(
            {
                "id": int(row["id"]),
                "image_name": str(row["image_name"]),
                "prediction_label": str(row["prediction_label"]),
                "confidence": float(row["confidence"]),
                "class_probabilities": probabilities,
                "created_at": str(row["created_at"]),
            }
        )

    return {"items": items, "count": len(items)}


@app.post("/api/chat")
async def chat(
    payload: ChatRequest,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    """AI-powered chat endpoint with emotional intelligence and VRM animation commands."""
    user_message = payload.message.strip()
    if not user_message:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")
    
    # Get AI response with emotion detection
    ai_response, emotion, emotion_intensity = await _get_ai_chat_response(
        user_message,
        disease_context=payload.disease_context,
        memory_context=payload.memory_context,
    )
    
    # Generate VRM animation command
    vrm_command = _generate_vrm_command(
        animation_state="speaking",
        emotion=emotion,
        gesture=None
    )
    
    return {
        "user_message": user_message,
        "ai_response": ai_response,
        "emotion": emotion,
        "emotion_intensity": emotion_intensity,
        "vrm_command": vrm_command,
        "timestamp": _utc_now_iso(),
        "source": "deepseek",
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)



@app.post("/api/chat/tts")
def chat_tts(
    payload: TTSRequest,
    user: sqlite3.Row = Depends(get_current_user),
) -> dict[str, Any]:
    """Return a small silent WAV audio (base64) as placeholder TTS when provider not configured.

    If `TTS_PROVIDER` env var is set, this endpoint should be replaced with an actual integration.
    """
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Text cannot be empty.")

    tts_provider = os.getenv("TTS_PROVIDER", "").strip()
    if not tts_provider:
        # Generate 1s silent WAV (16kHz, 16-bit PCM mono)
        def _silent_wav(duration_sec: float = 1.0, sr: int = 16000) -> bytes:
            import struct

            samples = int(duration_sec * sr)
            audio_data = (b"\x00\x00" * samples)
            byte_rate = sr * 2
            block_align = 2
            bits_per_sample = 16
            # RIFF header
            wav = b"RIFF"
            wav += struct.pack("<I", 36 + len(audio_data))
            wav += b"WAVEfmt "
            wav += struct.pack("<IHHIIHH", 16, 1, 1, sr, byte_rate, block_align, bits_per_sample)
            wav += b"data"
            wav += struct.pack("<I", len(audio_data))
            wav += audio_data
            return wav

        wav_bytes = _silent_wav(1.0, 16000)
        encoded = base64.b64encode(wav_bytes).decode("utf-8")
        return {
            "message": "TTS provider not configured. Returning placeholder silent audio (base64).",
            "tts_audio_base64": encoded,
            "content_type": "audio/wav",
        }

    # If a TTS provider is configured, return 501 for now (placeholder).
    raise HTTPException(status_code=501, detail="TTS provider integration not implemented. Set TTS_PROVIDER and implement provider logic.")

