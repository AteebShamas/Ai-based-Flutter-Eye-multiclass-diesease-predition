#!/usr/bin/env python
"""Fix the corrupted api_server.py file"""

with open('api_server.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the stray orphaned line and old medical KB entries
content = content.replace(
    '''    },
            "Regular comprehensive eye exams every 1-2 years help detect changes early.",
        ]
    },''',
    '''    },'''
)

# Remove medical-specific knowledge base entries
content = content.replace(
    '''    "follow_up": {
        "keywords": ["follow up", "when next", "appointment", "check", "monitoring"],
        "responses": [
            "CNV typically requires follow-up every 1 month initially, then 3-6 months based on response.",
            "DME requires frequent monitoring every 3-4 weeks during treatment, then 1-3 months for maintenance.",
            "Drusen should be monitored every 6-12 months with OCT imaging.",
            "Normal retinas generally require annual comprehensive eye exams.",
        ]
    },
    "treatment": {
        "keywords": ["treatment", "therapy", "medicine", "injection", "laser"],
        "responses": [
            "Anti-VEGF injections (ranibizumab, aflibercept, bevacizumab) are common retinal treatments that reduce abnormal vessel growth.",
            "Steroid injections or implants can reduce macular edema in DME and other conditions.",
            "Laser therapy may be used for certain conditions to seal leaking vessels or reduce edema.",
            "Medication compliance and timely follow-up visits are crucial for treatment success.",
            "Discuss potential side effects and treatment alternatives with your retina specialist.",
        ]
    },
    "diet": {
        "keywords": ["diet", "nutrition", "food", "vitamin", "supplement"],
        "responses": [
            "Eye-healthy foods include leafy greens (spinach, kale), fatty fish, nuts, and citrus fruits.",
            "Omega-3 fatty acids from salmon, mackerel, and walnuts support retinal health.",
            "Antioxidants like lutein and zeaxanthin may reduce AMD progression risk.",
            "Maintain a balanced diet with whole grains, lean proteins, and plenty of vegetables.",
            "Consult your doctor before starting eye supplements; AREDS2 formulation is evidence-based.",
        ]
    },''',
    ''','''
)

with open('api_server.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed api_server.py!")
