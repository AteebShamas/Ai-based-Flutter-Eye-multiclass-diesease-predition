# WALL-E Emotional Intelligence System - Implementation Guide

## Overview
This document describes the complete implementation of the WALL-E VRM emotional intelligence system, integrating Groq LLM, emotion detection, advanced animations, and real-time avatar state synchronization.

---

## Architecture

### 1. Backend System (FastAPI - api_server.py)

#### Emotion Detection Engine
**Location**: `api_server.py` lines 155-175

The backend implements a keyword-based emotion detection system that analyzes AI responses:

```python
EMOTION_KEYWORDS = {
    "happy": {"keywords": ["great", "wonderful", "excellent", ...], "intensity_multiplier": 0.8},
    "excited": {"keywords": ["amazing", "fantastic", "incredible", ...], "intensity_multiplier": 1.0},
    "concerned": {"keywords": ["serious", "urgent", "concerning", ...], "intensity_multiplier": 0.9},
    "confused": {"keywords": ["complex", "unusual", "interesting", ...], "intensity_multiplier": 0.6},
    "sadness": {"keywords": ["unfortunately", "limited", "struggle", ...], "intensity_multiplier": 0.7},
}
```

**Function**: `_detect_emotion(text) -> tuple[str, float]`
- Analyzes response text for emotion keywords
- Returns emotion name and intensity (0.0-1.0)
- Falls back to "neutral" if no keywords match

#### Disease Context Awareness
**Location**: `api_server.py` lines 177-195

Severity-based emotion mapping:

```python
DISEASE_SEVERITY = {
    "CNV": {"severity": "high", "emotion": "concerned", "urgency": "urgent"},
    "DME": {"severity": "high", "emotion": "concerned", "urgency": "urgent"},
    "DRUSEN": {"severity": "medium", "emotion": "happy", "urgency": "followup"},
    "NORMAL": {"severity": "low", "emotion": "happy", "urgency": "none"},
}
```

#### VRM Command Generation
**Location**: `api_server.py` lines 233-262

Generates animation commands based on state and emotion:

```python
def _generate_vrm_command(animation_state: str, emotion: str) -> dict:
    # Maps emotion to visual effects:
    # happy/excited → smile, eye widening
    # concerned/sadness → frown, eye softening
    # confused → eye movement tracking
```

#### Groq LLM Integration with Disease Context
**Location**: `api_server.py` lines 432-492

Enhanced system prompt that adapts to disease context:

```python
system_prompt = f"""You are WALL-E, a warm, empathetic, and highly emotionally intelligent AI assistant.
Your responses should express genuine emotion and understanding. 
If discussing serious conditions, show concern. If discussing positive outcomes, show enthusiasm.
[Disease context inserted here if applicable]
Keep responses concise, human, and helpful. Express warmth in every interaction."""
```

**Response Flow**:
1. User message received with optional disease_context parameter
2. System prompt enhanced with disease guidance
3. Groq LLM generates response
4. Emotion detected from response
5. VRM command generated with emotion + state
6. Response returned to Flutter with complete metadata

#### Chat Endpoint Response Format
**Endpoint**: `POST /api/chat`

**Request**:
```json
{
  "message": "What should I do about my CNV diagnosis?",
  "disease_context": "CNV - 89% confidence - Advanced Stage"
}
```

**Response**:
```json
{
  "user_message": "What should I do about my CNV diagnosis?",
  "ai_response": "Regarding your Choroidal Neovascularization: ...",
  "emotion": "concerned",
  "emotion_intensity": 0.85,
  "vrm_command": {
    "animation_state": "speaking",
    "emotion": "concerned",
    "blink_pattern": "attentive",
    "eye_direction": "forward",
    "mouth_action": "frown",
    "gesture": null
  },
  "timestamp": "2024-01-15T10:30:45.123Z",
  "source": "groq"
}
```

---

## Frontend Implementation (Flutter)

### 1. Data Models
**Location**: `lib/main.dart` & `lib/advanced_walle_chatbot.dart`

#### ChatResponse Model
```dart
class ChatResponse {
  final String userMessage;
  final String aiResponse;
  final String emotion;     // "happy" | "excited" | "concerned" | "confused" | "sadness"
  final double emotionIntensity; // 0.0 - 1.0
  final VRMCommand vrmCommand;
  final String timestamp;
}
```

#### VRMCommand Model
```dart
class VRMCommand {
  final String animationState;   // "idle" | "speaking" | "thinking" | "listening"
  final String emotion;          // emotion name
  final String blinkPattern;     // "relaxed" | "attentive" | "engaged" | "thinking"
  final String eyeDirection;     // "forward" | "up" | "down"
  final String mouthAction;      // "neutral" | "smile" | "frown" | "phoneme_index"
  final String? gesture;         // optional gesture name
}
```

### 2. Chat Message Flow
**Location**: `lib/advanced_walle_chatbot.dart`

#### State Management
```dart
String _currentState = 'idle';           // animation state
String _currentEmotion = 'neutral';       // detected emotion
double _currentEmotionIntensity = 0.0;    // emotion strength
```

#### Message Sending Process
```dart
Future<void> _sendMessage() async {
  // 1. Set thinking state
  setState(() {
    _currentState = 'thinking';
  });
  _syncAvatarState();
  
  // 2. Send message, receive ChatResponse with emotion
  final chatResponse = await widget.onSendMessage(message);
  
  // 3. Extract emotion and update state
  setState(() {
    _currentState = 'speaking';
    _currentEmotion = chatResponse.emotion;
    _currentEmotionIntensity = chatResponse.emotionIntensity;
  });
  _syncAvatarState();
  
  // 4. Speak response with emotion-informed animation
  await _flutterTts.speak(chatResponse.aiResponse);
}
```

#### WebView State Synchronization
```dart
void _syncAvatarState() {
  final stateData = {
    'state': _currentState,
    'emotion': _currentEmotion,
    'intensity': _currentEmotionIntensity,
  };
  await _avatarController.runJavaScript(
    'window.walleUpdateState(${jsonEncode(stateData)});'
  );
}
```

---

## VRM Web Viewer (walle_model_viewer_view_web.dart)

### 1. Emotion-Based Visual Effects

The WebView receives emotion data and applies CSS/JS effects:

#### Happy Emotion
- **Visual Effects**: 
  - Bright, expressive eyes (brightness +20%, saturation +30%)
  - Green/yellow glow (hue-rotate 180°)
  - Subtle upward body sway
  - "eyeHappySparkle" animation (2s cycle)
- **Blinking**: 2.5-4 second intervals (relaxed blinking)

#### Excited Emotion
- **Visual Effects**:
  - Maximum brightness (+30%, saturation +50%)
  - Red glow and rapid pupil pulsing
  - Fast, energetic body movement (2s sway)
  - Scale pulse animations (1.05 - 1.08)
- **Blinking**: 0.8-1.5 second intervals (rapid, frequent)
- **Exposure**: Elevated model brightness

#### Concerned Emotion
- **Visual Effects**:
  - Dimmer eyes (brightness -15%, saturation -20%)
  - Orange/amber glow (attentive)
  - Slower, cautious body movement (4s sway)
  - "eyeConcernedAttention" animation
- **Blinking**: 3.5-6 second intervals (slower, deliberate)
- **Exposure**: Reduced model brightness for empathy

#### Confused Emotion
- **Visual Effects**:
  - Slightly unfocused eyes (blur 0.5px)
  - Purple/violet glow
  - Head movement suggesting searching (3D rotation left/right)
  - Irregular motion pattern
- **Blinking**: 4-7 second intervals (thoughtful pauses)

#### Sadness Emotion
- **Visual Effects**:
  - Very dim eyes (brightness -25%, saturation -50%)
  - Blue glow
  - Downturned body posture
  - Slow, melancholic movement (5s sway)
- **Blinking**: 5-8 second intervals (slow, weary)
- **Exposure**: Minimal, somber lighting

### 2. JavaScript State Handler

**Location**: `advanced_walle_chatbot.dart` lines ~700-850

```javascript
window.walleUpdateState = function (stateData) {
  // Parse emotion and state data
  let state = stateData.state || 'idle';
  let emotion = stateData.emotion || 'neutral';
  let intensity = stateData.intensity || 0;
  
  // Update UI badge
  stateBadge.textContent = emotion + ' (' + state + ')';
  
  // Apply emotion effects (CSS classes)
  applyEmotionEffects(emotion, intensity);
  
  // Adjust model exposure based on state
  // Schedule emotion-aware blinking
  // Sync speaking blinks
}
```

### 3. Blinking Patterns

Emotion-specific blinking configuration:

```javascript
const emotionalDelays = {
  happy: [2500, 4000],       // Relaxed, natural intervals
  excited: [800, 1500],      // Rapid, frequent
  concerned: [3500, 6000],   // Slower, attentive
  confused: [4000, 7000],    // Long pauses between blinks
  sadness: [5000, 8000],     // Slow, weary
  neutral: [3800, 6200],     // Default natural rhythm
};
```

**Blink Duration**: ~140ms
**Blink Profile**: Smooth ease-in-out on close, instant open

---

## Testing the System

### 1. Test Happy Response
**Input**: Normal eye disease query with NORMAL result
**Expected Output**:
- Emotion: "happy"
- Intensity: 0.8+
- Visual: Bright green eyes, upward sway, natural blinking
- Status Badge: "happy (speaking)"

```bash
curl -X POST http://localhost:5000/api/chat \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Is my retina healthy?",
    "disease_context": "NORMAL - 99% confidence"
  }'
```

### 2. Test Concerned Response
**Input**: Serious condition diagnosis
**Expected Output**:
- Emotion: "concerned"
- Intensity: 0.85+
- Visual: Dimmer orange eyes, cautious sway, slower blinking
- Status Badge: "concerned (speaking)"

```bash
curl -X POST http://localhost:5000/api/chat \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What do I need to know about treatment?",
    "disease_context": "CNV - 89% confidence - Advanced"
  }'
```

### 3. Test Excited Response
**Input**: Breakthrough or positive development
**Expected Output**:
- Emotion: "excited"
- Intensity: 1.0
- Visual: Very bright red eyes, rapid pulse, fast energetic sway
- Status Badge: "excited (speaking)"
- Blinking: Rapid (0.8-1.5s intervals)

### 4. Test Confusion Response
**Input**: Complex or ambiguous situation
**Expected Output**:
- Emotion: "confused"
- Intensity: 0.6+
- Visual: Unfocused eyes, purple glow, head searching movement
- Status Badge: "confused (speaking)"
- Blinking: Long thoughtful pauses (4-7s)

### 5. Test Sadness Response
**Input**: Difficult prognosis or limitations
**Expected Output**:
- Emotion: "sadness"
- Intensity: 0.7+
- Visual: Very dim blue eyes, downturned posture, melancholic sway
- Status Badge: "sadness (speaking)"
- Blinking: Slow, weary (5-8s intervals)

---

## Animation States

### Idle State
- Body: Gentle floating (4.6s cycle, ±6px, ±1% scale)
- Eyes: Natural gaze with subtle pupil movement
- Blink: Natural rhythm (3.8-6.2s intervals)
- Emotion: Neutral

### Listening State
- Body: Forward lean, attentive posture
- Eyes: Bright, focused (brightness +8%, saturation +20%)
- Blink: Attentive rhythm (2.4-3.9s intervals)
- Emotion: From user context or neutral

### Thinking State  
- Body: Upward tilt, contemplative
- Eyes: Gazing upward (20-30° angle)
- Blink: Slow, staring (8-12s intervals with 10-15s holds)
- Emotion: Usually neutral, can be confused

### Speaking State
- Body: Forward engagement, natural sway (1.8s cycle)
- Eyes: Engaging with listener, bright
- Mouth: Moving with speech (if lip-sync enabled)
- Blink: Emotion-determined intervals
- Emotion: Detected from LLM response (happy, concerned, etc.)

### Error State
- Body: Downward tilt, apologetic posture
- Eyes: Downturned gaze
- Blink: Natural rhythm
- Emotion: Neutral or sadness

---

## Advanced Features (Planned/In Development)

### 1. Eye Tracking & Gaze System
- [ ] Pupil dilation based on emotion intensity
- [ ] Eye contact behavior during speaking
- [ ] Upward gaze during thinking
- [ ] Downward empathetic gaze for concern
- [ ] Side glances for confusion

### 2. Lip-Sync & Mouth Animation
- [ ] Phoneme extraction from TTS audio
- [ ] Vowel/consonant mouth shapes
- [ ] Jaw animation following mouth opening
- [ ] Baseline smile intensity based on emotion
- [ ] Real-time sync with audio playback (50-100ms granularity)

### 3. Advanced Blinking System
- [x] Emotion-aware intervals
- [x] Context-specific patterns
- [ ] Blink suppression for important information (15s holds)
- [ ] Double-blinks for confusion/surprise
- [ ] Rapid blinks for excitement
- [ ] Slow blinks for sleepiness/concern

### 4. Performance Optimization
- [ ] WebSocket binary compression for animation updates
- [ ] Model file compression with Draco codec
- [ ] Animation frame rate throttling
- [ ] Lazy-load emotion CSS classes
- [ ] Cache frequently used responses

### 5. Extended Disease Context
- [ ] Automatic disease severity classification
- [ ] Disease-specific response templates
- [ ] Treatment option recommendations with emotion
- [ ] Follow-up scheduling suggestions
- [ ] Medication side-effect awareness

---

## Configuration

### Groq API Configuration
**File**: `api_server.py`

```python
GROQ_API_KEY = os.getenv("GROQ_API_KEY", os.getenv("GROK_API_KEY", "")).strip()
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
```

**Environment Setup**:
```bash
export GROQ_API_KEY="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"
```

### Flutter Build Configuration
**File**: `pubspec.yaml`

```yaml
dependencies:
  flutter_tts: ^0.14.0
  speech_to_text: ^6.1.0
  webview_flutter: ^4.2.0
  google_fonts: ^5.1.0
```

---

## Deployment Checklist

- [x] Emotion detection keywords configured
- [x] Disease severity mapping established
- [x] VRM command generation implemented
- [x] Groq LLM integration with disease context
- [x] Flutter ChatResponse parsing
- [x] WebView emotion animation system
- [x] CSS emotion-specific styles (5 emotions × 5+ animations)
- [x] JavaScript state handler with emotion support
- [x] Blinking pattern scheduler
- [ ] E2E testing (emotion detection accuracy)
- [ ] Performance profiling (animation frame rate)
- [ ] User testing (emotion perception accuracy)
- [ ] Deployment documentation
- [ ] Monitoring & logging setup

---

## Performance Targets

| Metric | Target | Status |
|--------|--------|--------|
| User message → Backend | <100ms | ✅ WebSocket ready |
| Backend processing (Groq) | <500ms | 🔄 Depends on API |
| TTS generation | <2000ms | 🔄 External service |
| Audio playback start | <500ms | ✅ Pre-buffered |
| **Total latency** | **<4s** | 🔄 In progress |
| Animation frame rate | 60fps | ✅ CSS-based |
| Model loading time | <3s | ✅ Draco pending |

---

## Troubleshooting

### Emotion Not Detecting
**Issue**: `emotion` field always "neutral"
**Solution**: Check keyword lists in `EMOTION_KEYWORDS` contain response keywords

### Eyes Not Animating
**Issue**: VRM shows no emotion-based changes
**Solution**: Verify browser console for JS errors; check CSS emotion classes applied

### Blinking Too Frequent/Rare
**Issue**: Blink intervals don't match emotion
**Solution**: Adjust ranges in `emotionalDelays` object; check `scheduleBlinkForEmotionState()`

### Response Latency > 4s
**Issue**: Full pipeline takes too long
**Solution**: 
1. Enable WebSocket for streaming responses
2. Pre-generate TTS for common responses
3. Cache Groq responses for repeated queries

---

## References

- **Groq API Documentation**: https://console.groq.com/docs/speech-text
- **Model-Viewer.js**: https://modelviewer.dev/
- **VRM Specification**: https://vrm.dev/
- **Flutter WebView**: https://pub.dev/packages/webview_flutter
- **TTS Configuration**: https://pub.dev/packages/flutter_tts

---

## Next Steps

1. **Implement Eye Tracking**: Pupil dilation, gaze direction, eye contact
2. **Add Lip-Sync**: Phoneme extraction and mouth shape blending
3. **Performance Testing**: Profile animation frame rates and optimize
4. **User Feedback Loop**: Collect data on emotion perception accuracy
5. **Extended Testing**: Validate across all 6 emotional states and 5+ disease types

---

*Last Updated: 2024*
*System Status: Core Implementation Complete ✅ | Advanced Features In Progress 🔄*
