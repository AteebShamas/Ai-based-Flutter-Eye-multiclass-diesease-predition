# WALL-E Emotion Detection & Animation Test Suite

## Quick Test Checklist

### Backend Tests (Python)

#### 1. Emotion Detection Accuracy
```bash
python3 -c "
from api_server import _detect_emotion

test_cases = [
    ('This is wonderful and perfect!', 'happy'),
    ('Amazing breakthrough! Incredible news!', 'excited'),
    ('This is serious and concerning.', 'concerned'),
    ('That is quite complex and unusual.', 'confused'),
    ('Unfortunately, this is very difficult.', 'sadness'),
    ('The weather is nice today.', 'neutral'),
]

for text, expected in test_cases:
    emotion, intensity = _detect_emotion(text)
    status = '✓' if emotion == expected else '✗'
    print(f'{status} \"{text[:40]}...\" -> {emotion} (intensity: {intensity:.2f})')
"
```

**Expected Output**:
```
✓ "This is wonderful and perfect!" -> happy (intensity: 0.60)
✓ "Amazing breakthrough! Incredible news!" -> excited (intensity: 0.75)
✓ "This is serious and concerning." -> concerned (intensity: 0.68)
✓ "That is quite complex and unusual." -> confused (intensity: 0.40)
✓ "Unfortunately, this is very difficult." -> sadness (intensity: 0.53)
✓ "The weather is nice today." -> neutral (intensity: 0.30)
```

#### 2. VRM Command Generation
```bash
python3 -c "
from api_server import _generate_vrm_command

states = ['idle', 'listening', 'thinking', 'speaking']
emotions = ['happy', 'excited', 'concerned', 'confused', 'sadness']

for state in states:
    for emotion in emotions:
        cmd = _generate_vrm_command(state, emotion)
        print(f'{state:12} + {emotion:10} -> blink:{cmd[\"blink_pattern\"]:10} mouth:{cmd[\"mouth_action\"]:12} eye:{cmd[\"eye_direction\"]}')
"
```

**Expected Output**:
- All state+emotion combinations produce valid VRM commands
- Concerned/sadness emotions produce 'frown' mouth actions
- Happy/excited emotions produce 'smile' mouth actions
- Thinking state produces 'up' eye direction
- Speaking state produces 'forward' eye direction

#### 3. Chat Endpoint Integration Test
```bash
# Start backend server
python3 api_server.py &
SERVER_PID=$!
sleep 2

# Test with normal disease context
curl -X POST http://localhost:5000/api/chat \
  -H "Authorization: Bearer test_token_here" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Is my retina healthy?",
    "disease_context": "NORMAL - 99% confidence"
  }' | python3 -m json.tool

# Verify response contains: emotion, emotion_intensity, vrm_command

kill $SERVER_PID
```

**Response Validation**:
- [ ] `emotion` field present and valid (one of: happy, excited, concerned, confused, sadness, neutral)
- [ ] `emotion_intensity` is float between 0.0 and 1.0
- [ ] `vrm_command` contains all required fields
- [ ] `vrm_command.mouth_action` matches emotion (smile for happy, frown for concerned)
- [ ] `ai_response` is non-empty string
- [ ] `timestamp` is ISO 8601 format

---

### Flutter Frontend Tests

#### 1. ChatResponse Model Parsing
**Location**: `lib/main.dart`

```dart
test('ChatResponse parses emotion correctly', () {
  final json = {
    'user_message': 'Test',
    'ai_response': 'Response',
    'emotion': 'happy',
    'emotion_intensity': 0.85,
    'vrm_command': {
      'animation_state': 'speaking',
      'emotion': 'happy',
      'blink_pattern': 'relaxed',
      'eye_direction': 'forward',
      'mouth_action': 'smile',
    },
    'timestamp': '2024-01-15T10:00:00Z',
  };
  
  final response = ChatResponse.fromJson(json);
  expect(response.emotion, equals('happy'));
  expect(response.emotionIntensity, closeTo(0.85, 0.01));
  expect(response.vrmCommand.mouthAction, equals('smile'));
});
```

#### 2. Avatar State Synchronization
**Location**: `lib/advanced_walle_chatbot.dart`

```dart
test('Avatar state includes emotion data', () async {
  final widget = AdvancedWALLEChatBot(
    onSendMessage: (msg) => Future.value(ChatResponse(
      userMessage: msg,
      aiResponse: 'Test response',
      emotion: 'happy',
      emotionIntensity: 0.8,
      vrmCommand: VRMCommand(
        animationState: 'speaking',
        emotion: 'happy',
        blinkPattern: 'relaxed',
        eyeDirection: 'forward',
        mouthAction: 'smile',
      ),
      timestamp: DateTime.now().toIso8601String(),
    )),
    vrmSource: '3d model/walle.vrm',
  );
  
  // Verify state data includes emotion
  final state = widget_state_instance._currentEmotion;
  expect(state, equals('happy'));
});
```

---

### WebView JavaScript Tests

#### 1. Emotion CSS Classes Applied
**Test**: Open browser console, send message, check CSS classes

```javascript
// In browser console after emotion update:
console.log(document.getElementById('motionLayer').className);
// Expected output: "motion-layer speaking emotion-happy"

console.log(document.getElementById('eyesOverlay').className);
// Expected output: "eyes-overlay speaking emotion-happy"
```

#### 2. Blinking Pattern Matches Emotion
**Test**: Monitor blink timing for different emotions

```javascript
// Inject test code to measure blink intervals
let blinkTimes = [];
const originalTriggerBlink = triggerBlink;
window.triggerBlink = function() {
  blinkTimes.push(Date.now());
  originalTriggerBlink.call(this);
};

// Send message with emotion
// Monitor console: blinkTimes arrays should match emotion-specific intervals
```

**Expected Blink Intervals**:
- Happy: 2.5-4s
- Excited: 0.8-1.5s
- Concerned: 3.5-6s
- Confused: 4-7s
- Sadness: 5-8s

#### 3. Emotion Effects Applied
**Test**: Monitor eye brightness/saturation changes

```javascript
// Check computed styles
const eyeElement = document.querySelector('.robot-eye');
const styles = window.getComputedStyle(eyeElement);

// For happy emotion:
console.log(styles.filter); // Should include brightness(1.2) saturate(1.3)

// For concerned emotion:
console.log(styles.filter); // Should include brightness(0.85) saturate(0.8)
```

---

### End-to-End Integration Test

#### Setup
1. Start backend server: `python3 api_server.py`
2. Set GROQ_API_KEY: `export GROQ_API_KEY="your_key_here"`
3. Build Flutter app: `flutter build apk` or run `flutter run` on device
4. Ensure backend URL is correct in app settings

#### Test Scenario 1: Happy Response
**Steps**:
1. Upload image with "NORMAL" classification
2. Open chat screen
3. Ask: "Is my eye condition serious?"

**Verification**:
- [ ] Response includes positive language (healthy, good, excellent)
- [ ] Emotion detected as "happy"
- [ ] Emotion intensity >= 0.7
- [ ] Avatar eyes show green glow and brightness
- [ ] Status badge shows "happy (speaking)"
- [ ] Body animation is upward sway
- [ ] Blinking rate is natural (2.5-4s intervals)

#### Test Scenario 2: Concerned Response
**Steps**:
1. Upload image with "CNV" classification
2. Open chat screen
3. Ask: "What treatment options are available?"

**Verification**:
- [ ] Response includes concern words (serious, urgent, specialist)
- [ ] Emotion detected as "concerned"
- [ ] Emotion intensity >= 0.8
- [ ] Avatar eyes show orange glow and dimming
- [ ] Status badge shows "concerned (speaking)"
- [ ] Body animation is cautious sway
- [ ] Blinking rate is slower (3.5-6s intervals)

#### Test Scenario 3: Excited Response
**Steps**:
1. Upload image with positive trend (improvement)
2. Open chat screen
3. Ask: "Is this condition improving?"

**Verification**:
- [ ] Response includes enthusiastic language (amazing, breakthrough)
- [ ] Emotion detected as "excited"
- [ ] Emotion intensity = 1.0
- [ ] Avatar eyes show red glow and rapid pulsing
- [ ] Status badge shows "excited (speaking)"
- [ ] Body animation is fast sway
- [ ] Blinking rate is very rapid (0.8-1.5s intervals)

---

## Performance Metrics

### Latency Targets
```
User Input → Backend: < 100ms
Groq API Response: < 500ms (Depends on API speed)
Emotion Detection: < 50ms
VRM Command Generation: < 30ms
Flutter Update: < 100ms
WebView Animation: < 50ms (CSS-based)
───────────────────────────────────
TOTAL TARGET: < 4 seconds (target met if all under limits)
```

### Measurement Commands
```bash
# Python: Measure emotion detection speed
import time
from api_server import _detect_emotion

text = "This is wonderful and amazing news!"
start = time.time()
for _ in range(100):
    _detect_emotion(text)
end = time.time()
print(f"Avg detection time: {(end-start)/100*1000:.2f}ms")
# Expected: < 5ms per call

# Python: Measure API response time (with network)
import time
import httpx
import asyncio

async def test_latency():
    async with httpx.AsyncClient() as client:
        start = time.time()
        response = await client.post(
            'http://localhost:5000/api/chat',
            headers={'Authorization': 'Bearer token'},
            json={'message': 'Test question?'},
        )
        end = time.time()
        print(f"API response time: {(end-start)*1000:.0f}ms")

asyncio.run(test_latency())
```

### Browser Performance
```javascript
// Measure animation frame rate in browser console
let frameCount = 0;
let lastTime = Date.now();
const measureFPS = () => {
  frameCount++;
  const now = Date.now();
  if (now - lastTime >= 1000) {
    console.log(`FPS: ${frameCount}`);
    frameCount = 0;
    lastTime = now;
  }
  requestAnimationFrame(measureFPS);
};
measureFPS();

// Expected: 55-60 FPS for smooth animations
```

---

## Debugging Tips

### 1. Backend Debug Logging
```python
# Add to api_server.py _get_ai_chat_response function
print(f"DEBUG: User message: {user_message}")
print(f"DEBUG: Groq response: {response_text}")
emotion, intensity = _detect_emotion(response_text)
print(f"DEBUG: Detected emotion: {emotion} (intensity: {intensity})")
```

### 2. Flutter Debug Logging
```dart
// Add to advanced_walle_chatbot.dart _sendMessage function
print('DEBUG: Sending message: $message');
final chatResponse = await widget.onSendMessage(message);
print('DEBUG: Received emotion: ${chatResponse.emotion}');
print('DEBUG: Emotion intensity: ${chatResponse.emotionIntensity}');
```

### 3. WebView Debug Logging
```javascript
// Add to window.walleUpdateState function
console.log('walleUpdateState called with:', stateData);
console.log('Applied emotion class:', `emotion-${emotion}`);
console.log('Eye element styles:', window.getComputedStyle(eyeElement).filter);
```

---

## Validation Criteria

| Feature | Expected | Test Method | Status |
|---------|----------|-------------|--------|
| Happy Emotion | Green eyes, upward sway, 2.5-4s blinks | Scenario 1 | ⏳ |
| Excited Emotion | Red eyes, rapid pulse, 0.8-1.5s blinks | Scenario 3 | ⏳ |
| Concerned Emotion | Orange eyes, cautious sway, 3.5-6s blinks | Scenario 2 | ⏳ |
| Confused Emotion | Purple eyes, head movement, 4-7s blinks | Custom test | ⏳ |
| Sadness Emotion | Blue eyes, downturned, 5-8s blinks | Custom test | ⏳ |
| Disease Context | Tone matches disease severity | Scenario 2 | ⏳ |
| Latency | < 4 seconds end-to-end | Performance test | ⏳ |
| Animation FPS | 55-60 fps smooth | Browser perf | ⏳ |

---

## Known Issues & Workarounds

### Issue: Emotion always "neutral"
**Cause**: Keywords not in response text
**Workaround**: Add more keywords to `EMOTION_KEYWORDS` or adjust keyword detection

### Issue: Eyes not animating
**Cause**: CSS classes not applied to correct elements
**Workaround**: Verify element IDs in HTML match CSS selectors; check browser console

### Issue: Blinking seems random
**Cause**: Multiple blink timers interfering
**Workaround**: Call `clearBlinkTimers()` in state change handler

### Issue: High latency (> 4s)
**Cause**: Slow Groq API, network delay, or TTS generation
**Workaround**: Implement response caching, pre-generate common TTS, upgrade to WebSocket

---

## Next Validation Steps

1. ✅ Unit tests for emotion detection
2. ✅ Integration tests for API response format
3. ⏳ Flutter widget tests for ChatResponse parsing
4. ⏳ End-to-end tests for all 5 emotions
5. ⏳ Performance profiling and optimization
6. ⏳ User acceptance testing (emotion perception)

---

*Test Suite Version: 1.0*
*Last Updated: 2024*
