# Human Eye Disease Prediction

Short elevator pitch
- Visual diagnostics app that classifies retinal fundus images into CNV, DME, DRUSEN, or NORMAL using a trained TensorFlow model, provides result history, reminders, and a 3D anatomy viewer.

Quick demo steps (for presentation)
1. Ensure backend is running:
```powershell
.venv\Scripts\Activate.ps1
uvicorn api_server:app --host 0.0.0.0 --port 8000
```
2. Launch frontend (web):
```bash
cd flutter_eye_disease_app
flutter pub get
flutter run -d chrome
```
3. Register or use the provided test account, upload/select an eye image, press Diagnose, and show the returned label + confidence.

Core features
- Model inference: `/predict` runs Keras model and returns diagnosis + confidence.
- Authentication: register / login, token-based flows.
- Prediction history: persisted per-user in SQLite.
- Reminders: local scheduled notifications.
- 3D Anatomy Viewer: Sketchfab embed with reload control.
- Editable API base URL (for testing local/backends).

Backend (high level)
- File: `api_server.py`
- Stack: FastAPI, Uvicorn, TensorFlow/Keras, SQLite
- Endpoints:
  - `POST /auth/register` — create user
  - `POST /auth/login` — login, returns token
  - `GET /me` — current user
  - `POST /predict` — submit image, returns diagnosis
  - `GET /history` — fetch user history
- Notes: CORS enabled for web usage; model loaded on startup.

Frontend (high level)
- Entry: `flutter_eye_disease_app/lib/main.dart`
- Stack: Flutter, shared_preferences, webview_flutter, http
- Screens:
  - Auth screen (login/register, API URL)
  - Diagnosis (capture/select image, send to backend)
  - History (list past predictions)
  - Reminders (local notifications)
  - 3D Anatomy (Sketchfab/web fallback)

Model & Data
- Trained artifacts: `Trained_Model.h5` and `Trained_Model.keras`
- Dataset folder: `Dataset - train+val+test/` with classes `CNV`, `DME`, `DRUSEN`, `NORMAL`
- Training notebooks: `Training_model.ipynb`, `Model_Prediction.ipynb`

Run & Deploy notes
- Local dev: run backend then frontend as above.
- Containers / cloud: see `Dockerfile`, `render.yaml`, `railway.json` for deployment scaffolding.

Known issues & troubleshooting
- If web UI shows stale API URL, clear browser site storage or use the API URL dialog to save `http://127.0.0.1:8000`.
- If layout/rendering exceptions occur after large UI edits, run:
```bash
flutter clean
flutter pub get
flutter run -d chrome
```
- Backend errors: check console where `uvicorn` is running and verify the model loaded correctly.

Presentation slides (5-minute talk) — bullets
1. Title & Problem — explain retinal disease detection need (1 slide)
2. Solution Overview — app features & quick demo plan (1 slide)
3. Architecture — backend, frontend, model, data flow diagram (1 slide)
4. Demo — run through register, diagnose, show history, 3D viewer (1–2 slides)
5. Results & Next Steps — accuracy notes, limitations, future work (1 slide)

Speaker notes (per slide)
- Slide 1: "Introduce the problem: early detection of retinal pathologies helps treatment. We built a lightweight app to classify images into four categories."
- Slide 2: "Walk through user flow: register/login → capture/upload image → get diagnosis + confidence → save history or share report. Also mention reminders and 3D viewer."
- Slide 3: "Architecture: FastAPI backend serves model inference and stores history in SQLite; Flutter frontend consumes the endpoints. Model is a Keras model packaged with the repo."
- Slide 4: "Live demo instructions: start backend, run frontend on Chrome, use the app to diagnose one image. Show response JSON briefly and UI rendering."
- Slide 5: "Wrap up with model performance (mention how trained if you have metrics), limitations (edge cases, dataset biases), and next steps (more data, CI, mobile builds)."

If you want, I can:
- Add this `README.md` to the repo (done).
- Create a `PRESENTATION.md` slide notes file or generate a simple PowerPoint/Google Slides outline (tell me your preference).
- Produce a one-page PDF handout from the speaker notes.

Would you like a slide deck (PowerPoint) generated from these notes now?